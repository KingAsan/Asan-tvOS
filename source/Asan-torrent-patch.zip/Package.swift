// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "KinoCore",
    platforms: [.tvOS(.v17), .macOS(.v13)],
    products: [
        .library(name: "KinoCore", targets: ["KinoCore"]),
        .library(name: "RezkaKit", targets: ["RezkaKit"]),
        .library(name: "KinoArtwork", targets: ["KinoArtwork"]),
        .library(name: "AsanTorrent", targets: ["TorrentRuntime"])
    ],
    dependencies: [
        // Its manifest requires a Swift 6 toolchain (Xcode 16 or newer).
        .package(url: "https://github.com/scinfu/SwiftSoup.git", exact: "2.14.3"),
        .package(url: "https://github.com/kean/Nuke.git", exact: "13.2.0")
    ],
    targets: [
        .binaryTarget(name: "AsanTorrent", path: "Vendor/AsanTorrent.xcframework"),
        .target(name: "TorrentRuntime", dependencies: ["AsanTorrent", "KinoCore"], linkerSettings: [
            .linkedLibrary("c++"), .linkedFramework("CoreFoundation"), .linkedFramework("SystemConfiguration")
        ]),
        .target(name: "KinoCore"),
        .target(name: "KinoArtwork", dependencies: [
            .product(name: "Nuke", package: "Nuke"), .product(name: "NukeUI", package: "Nuke")
        ]),
        .target(name: "RezkaKit", dependencies: [
            "KinoCore", .product(name: "SwiftSoup", package: "SwiftSoup")
        ]),
        .testTarget(name: "KinoCoreTests", dependencies: ["KinoCore"]),
        .testTarget(name: "TorrentRuntimeTests", dependencies: ["TorrentRuntime", "KinoCore"]),
        .testTarget(name: "KinoArtworkTests", dependencies: ["KinoArtwork", .product(name: "Nuke", package: "Nuke")]),
        .testTarget(name: "RezkaKitTests", dependencies: ["RezkaKit", "KinoCore"])
    ]
)
