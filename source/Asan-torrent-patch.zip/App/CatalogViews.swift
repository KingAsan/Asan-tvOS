import SwiftUI
import KinoCore
import RezkaKit
import KinoArtwork

struct RootView: View {
    @EnvironmentObject private var model: AppModel
    @EnvironmentObject private var downloads: TorrentDownloadsModel
    @State private var searchQuery = ""
    var body: some View {
        Group {
            if #available(tvOS 18.0, *) { searchableTabs.tabViewStyle(.sidebarAdaptable) }
            else { legacyTabs }
        }
        .background { AsanBackdrop() }
        .overlay(alignment: .topTrailing) {
            #if DEBUG && targetEnvironment(simulator)
            if PreviewSupport.scene != nil { PreviewWatermark() }
            #endif
        }
        .fullScreenCover(item: $model.playback, onDismiss: model.playbackDidDismiss) { request in
            PlaybackScreen(request: request).environmentObject(model)
        }
        .fullScreenCover(item: $downloads.playback, onDismiss: {
            Task { await downloads.refresh() }
        }) { playback in
            TorrentLocalPlayer(playback: playback)
        }
        .sheet(item: $model.torrentDiscovery) { request in
            discoveryScreen(request)
        }
        .onChange(of: downloads.playback?.id) { _, id in
            if id != nil { model.cancelTorrentDiscovery() }
        }
        .alert(item: $model.notice) { notice in
            Alert(title: Text(notice.title), message: Text(notice.message), dismissButton: .default(Text("Понятно")))
        }
    }

    @ViewBuilder private func discoveryScreen(_ request: TorrentDiscoveryRequest) -> some View {
        #if DEBUG && targetEnvironment(simulator)
        if PreviewSupport.scene != nil {
            TorrentSearchScreen(media: request.entry.media, reference: request.entry.reference,
                preferredEpisodeID: request.episodeID, service: PreviewTorrentSearchService(scene: PreviewSupport.scene?.rawValue))
        } else {
            TorrentSearchScreen(media: request.entry.media, reference: request.entry.reference, preferredEpisodeID: request.episodeID)
        }
        #else
        TorrentSearchScreen(media: request.entry.media, reference: request.entry.reference, preferredEpisodeID: request.episodeID)
        #endif
    }

    @available(tvOS 18.0, *)
    private var searchableTabs: some View {
        TabView(selection: $model.selectedTab) {
            ForEach(AppTab.allCases, id: \.self) { tab in
                Tab(value: tab, role: tab == .search ? .search : nil) {
                    NavigationStack { destination(tab) }
                } label: {
                    Label(tab.title, systemImage: tab.symbol)
                }
            }
        }
        .searchable(text: $searchQuery, prompt: "Название фильма или сериала")
    }

    private var legacyTabs: some View {
        TabView(selection: $model.selectedTab) {
            ForEach(AppTab.allCases, id: \.self) { tab in
                NavigationStack { destination(tab) }
                    .tabItem { Label(tab.title, systemImage: tab.symbol) }.tag(tab)
            }
        }
    }

    @ViewBuilder private func destination(_ tab: AppTab) -> some View {
        switch tab {
        case .catalog: CatalogScreen()
        case .search:
            if #available(tvOS 18.0, *) { SearchScreen(query: $searchQuery) }
            else { SearchScreen() }
        case .favorites: SavedScreen(kind: .favorites)
        case .watchlist: SavedScreen(kind: .watchlist)
        case .history: HistoryScreen()
        case .downloads: TorrentDownloadsScreen()
        case .settings: SettingsScreen()
        }
    }
}

private enum CatalogSort: String, CaseIterable, Identifiable {
    case original = "Порядок Rezka", recent = "По году", rating = "По рейтингу", title = "По названию"
    var id: String { rawValue }
}

struct CatalogScreen: View {
    @EnvironmentObject private var model: AppModel
    @State private var sort = CatalogSort.original
    @State private var randomEntry: CatalogEntry?
    @State private var sortedEntries: [CatalogEntry] = []
    private func updateSorting() {
        switch sort {
        case .original: sortedEntries = model.entries
        case .recent: sortedEntries = model.entries.sorted { ($0.media.year ?? 0) > ($1.media.year ?? 0) }
        case .rating: sortedEntries = model.entries.sorted { (model.knownRating(for: $0) ?? -1) > (model.knownRating(for: $1) ?? -1) }
        case .title: sortedEntries = model.entries.sorted { $0.media.title.localizedStandardCompare($1.media.title) == .orderedAscending }
        }
    }
    var body: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 32) {
                HStack(alignment: .center, spacing: 24) {
                    VStack(alignment: .leading, spacing: 8) {
                        HStack(spacing: 16) { BrandMark(); Text("Медиатека").foregroundStyle(.secondary) }
                            .font(.system(size: 30, weight: .semibold))
                        Text(model.selectedCategory.title + " · \(model.entries.count)").font(.callout).foregroundStyle(.secondary)
                    }
                    Spacer()
                    if model.isRefreshing { ProgressView() }
                    Button { Task { await model.refresh() } } label: {
                        Image(systemName: "arrow.clockwise").accessibilityLabel("Обновить медиатеку")
                    }
                        .disabled(model.isRefreshing || !model.isConfigured || !model.account.isAuthenticated)
                }.focusSection()
                if model.isCheckingAccount && !model.account.isAuthenticated && model.entries.isEmpty {
                    ProgressView("Проверяем аккаунт Rezka…")
                } else if !model.isConfigured || (!model.account.isAuthenticated && !model.isCheckingAccount) {
                    EmptyLibraryView(symbol: "person.crop.circle", title: "Войти в Rezka",
                        message: model.accountError ?? "Войди в свой аккаунт rezka.fi, чтобы открыть каталог и пользоваться своей подпиской.") {
                        Button("Открыть вход") { model.selectedTab = .settings }
                    }
                } else {
                    if model.isCheckingAccount && !model.account.isAuthenticated {
                        HStack(spacing: 14) {
                            ProgressView().scaleEffect(0.7)
                            Text("Сохранённый каталог · проверяем аккаунт").font(.system(size: 20)).foregroundStyle(.secondary)
                            Spacer()
                        }.frame(height: 34)
                    }
                    HStack(spacing: 24) {
                        Menu {
                            ForEach(RezkaCategory.allCases) { category in
                                Button { model.selectedCategory = category } label: {
                                    if category == model.selectedCategory { Label(category.title, systemImage: "checkmark") }
                                    else { Text(category.title) }
                                }
                            }
                        } label: { Label(model.selectedCategory.title, systemImage: "line.3.horizontal.decrease") }
                        Menu {
                            ForEach(CatalogSort.allCases) { value in
                                Button { sort = value } label: {
                                    if value == sort { Label(value.rawValue, systemImage: "checkmark") }
                                    else { Text(value.rawValue) }
                                }
                            }
                        } label: { Label("Сортировка", systemImage: "arrow.up.arrow.down") }
                        Spacer()
                        Button { randomEntry = model.entries.randomElement() } label: {
                            Image(systemName: "shuffle").accessibilityLabel("Случайный фильм")
                        }.disabled(model.entries.isEmpty)
                    }.focusSection().disabled(!model.account.isAuthenticated)
                    if let error = model.catalogError {
                        VStack(alignment: .leading, spacing: 18) {
                            Label(error, systemImage: "exclamationmark.circle").font(.callout).foregroundStyle(.secondary)
                            Button("Проверить адрес Rezka") { model.selectedTab = .settings }
                        }
                    }
                    if model.selectedCategory == .all { ContinueWatchingRow().disabled(!model.account.isAuthenticated) }
                    MediaGrid(entries: sortedEntries).disabled(!model.account.isAuthenticated)
                    if model.entries.isEmpty && !model.isRefreshing && model.catalogError == nil {
                        Text("В этом разделе пока ничего нет.").foregroundStyle(.secondary)
                    }
                    if model.hasNextPage {
                        Button(model.isRefreshing ? "Загрузка…" : "Показать ещё") { Task { await model.loadNextPage() } }
                            .disabled(model.isRefreshing || !model.account.isAuthenticated)
                    }
                }
            }.padding(.horizontal, 48).padding(.top, 40).padding(.bottom, 70)
        }
        .background { AsanBackdrop() }
        .onAppear { updateSorting() }
        .onChange(of: model.entries) { _ in updateSorting() }
        .onChange(of: sort) { _ in updateSorting() }
        .onChange(of: model.selectedCategory) { _ in Task { await model.refresh() } }
        .navigationDestination(item: $randomEntry) { entry in MediaDetailsView(entry: entry) }
        .task(id: model.entries.count) {
            #if DEBUG && targetEnvironment(simulator)
            if let scene = PreviewSupport.scene,
               [.details, .voices, .qualities, .torrentSearch, .torrentSearchEmpty, .torrentSearchError,
                .introSettings].contains(scene), randomEntry == nil {
                randomEntry = model.entries.first
            }
            #endif
        }
    }
}

struct SearchScreen: View {
    @EnvironmentObject private var model: AppModel
    @State private var localQuery = ""
    @Binding private var tabQuery: String
    private let usesTabQuery: Bool

    init(query: Binding<String>? = nil) {
        if let query {
            _tabQuery = query
            usesTabQuery = true
        } else {
            _tabQuery = .constant("")
            usesTabQuery = false
        }
    }

    private var query: String { usesTabQuery ? tabQuery : localQuery }

    var body: some View {
        if usesTabQuery {
            searchContent
        } else {
            searchContent.searchable(text: $localQuery, prompt: "Название фильма или сериала")
        }
    }

    private var searchContent: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 30) {
                if !model.isConfigured || !model.account.isAuthenticated {
                    Text("Сначала войди в аккаунт Rezka в настройках.").foregroundStyle(.secondary)
                } else if model.isSearching && model.searchResults.isEmpty {
                    ProgressView("Ищем на Rezka…")
                } else if let error = model.searchError {
                    Text(error).foregroundStyle(.secondary)
                } else if query.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                    Text("Ищи фильмы, сериалы, мультфильмы и аниме в каталоге Rezka.").foregroundStyle(.secondary)
                } else if model.searchResults.isEmpty {
                    Text("Ничего не найдено. Попробуй другое название.").foregroundStyle(.secondary)
                }
                MediaGrid(entries: model.searchResults)
                if model.searchHasNextPage {
                    Button(model.isSearching ? "Загрузка…" : "Ещё результаты") { Task { await model.search(query, nextPage: true) } }
                        .disabled(model.isSearching)
                }
            }.padding(70)
        }
        .background { AsanBackdrop() }
        .task(id: query) {
            do {
                try await Task.sleep(for: .milliseconds(400))
                try Task.checkCancellation()
                await model.search(query)
            } catch { }
        }
    }
}

struct SavedScreen: View {
    enum Kind { case favorites, watchlist }
    let kind: Kind
    @EnvironmentObject private var model: AppModel
    private var saved: [SavedMedia] { kind == .favorites ? model.library.favorites : model.library.watchlist }
    var body: some View {
        ScrollView {
            if saved.isEmpty {
                EmptyLibraryView(symbol: kind == .favorites ? "heart" : "bookmark", title: "Здесь пока пусто",
                    message: "Открой карточку фильма или сериала и добавь его в этот список.") {
                    Button("Перейти в каталог") { model.selectedTab = .catalog }
                }.padding(70)
            } else { MediaGrid(entries: saved.map { model.entry(for: $0) }).padding(70) }
        }.navigationTitle(kind == .favorites ? "Избранное" : "Смотреть позже").background { AsanBackdrop() }
    }
}

struct HistoryScreen: View {
    @EnvironmentObject private var model: AppModel
    var body: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 26) {
                if model.library.history.isEmpty {
                    EmptyLibraryView(symbol: "clock", title: "Продолжим с того же места",
                        message: "Здесь появятся фильмы и серии, которые ты начал смотреть.") {
                        Button("Перейти в каталог") { model.selectedTab = .catalog }
                    }
                }
                ForEach(model.library.history.sorted { $0.updatedAt > $1.updatedAt }) { progress in
                    let entry = model.entry(for: progress)
                    HStack(spacing: 30) {
                        NavigationLink { MediaDetailsView(entry: entry) } label: {
                            HStack(spacing: 24) {
                                PosterArtwork(item: entry.media).frame(width: 95, height: 140)
                                VStack(alignment: .leading, spacing: 10) {
                                    Text(entry.media.title).font(.headline)
                                    if let id = progress.episodeID,
                                       let episode = entry.media.seasons.flatMap(\.episodes).first(where: { $0.id == id }) {
                                        Text(episode.title).font(.callout).foregroundStyle(.secondary)
                                    }
                                    Text(progress.isCompleted ? "Просмотрено" : "\(playbackTime(progress.position)) из \(playbackTime(progress.duration))")
                                        .font(.callout).foregroundStyle(.secondary)
                                    ProgressView(value: progress.fraction).frame(maxWidth: 650)
                                }
                                Spacer()
                            }.padding(18)
                        }.buttonStyle(.card)
                        Button(role: .destructive) { Task { await model.removeProgress(progress) } } label: {
                            Image(systemName: "trash").accessibilityLabel("Удалить из истории")
                        }
                    }
                }
            }.padding(70)
        }.navigationTitle("История просмотров").background { AsanBackdrop() }
    }
}

struct MediaGrid: View {
    let entries: [CatalogEntry]
    @FocusState private var focusedEntryID: String?
    @State private var lastFocusedEntryID: String?
    private let columns = [GridItem(.adaptive(minimum: 236, maximum: 300), spacing: 36)]
    var body: some View {
        LazyVGrid(columns: columns, alignment: .leading, spacing: 34) {
            ForEach(entries) { entry in
                NavigationLink { MediaDetailsView(entry: entry) } label: { PosterCard(entry: entry) }
                    .buttonStyle(.borderless)
                    .id(entry.id)
                    .focused($focusedEntryID, equals: entry.id)
                    .accessibilityIdentifier("media-card-" + entry.media.id)
            }
        }
        .padding(.vertical, 12).focusSection()
        .onChange(of: focusedEntryID) { _, value in
            if let value { lastFocusedEntryID = value }
        }
        .onAppear {
            // NavigationStack keeps the original ScrollView alive. Restore its
            // exact card, never rebuild the scroll view or jump to its first row.
            guard let last = lastFocusedEntryID, entries.contains(where: { $0.id == last }) else { return }
            Task { @MainActor in
                await Task.yield()
                focusedEntryID = last
            }
        }
    }
}

struct PosterCard: View {
    let entry: CatalogEntry
    @EnvironmentObject private var model: AppModel
    @EnvironmentObject private var downloads: TorrentDownloadsModel
    @State private var metadata: MediaItem?
    private var media: MediaItem {
        var value = entry.media
        if let metadata {
            if !metadata.genres.isEmpty { value.genres = metadata.genres }
            value.rating = metadata.rating ?? value.rating
            if !metadata.seasons.isEmpty { value.seasons = metadata.seasons }
        }
        return value
    }
    var body: some View {
        let viewing = MediaViewingStatus(media: model.mediaWithKnownSeasons(for: entry),
            reference: entry.reference, history: model.library.history)
        let localCopy = downloads.availableCompletedCopy(for: entry.reference,
            episodeID: viewing.resumable?.episodeID ?? viewing.nextKnownEpisode?.id ?? viewing.latest?.episodeID)
        let localFraction = localCopy.flatMap { copy -> Double? in
            guard copy.localDuration > 0, copy.localPosition > 0 else { return nil }
            let fraction = copy.localPosition / copy.localDuration
            return fraction < 0.95 ? fraction : nil
        }
        let resumeFraction = viewing.resumable?.fraction ?? localFraction
        VStack(alignment: .leading, spacing: 10) {
            PosterArtwork(item: media).aspectRatio(2.0 / 3.0, contentMode: .fit)
                .overlay(alignment: .topTrailing) {
                    HStack(spacing: 5) {
                        Image(systemName: "star.fill").foregroundStyle(.yellow)
                        Text(media.displayRating.map { String(format: "%.1f", $0) } ?? "—").monospacedDigit()
                    }.font(.system(size: 20, weight: .semibold))
                        .foregroundStyle(.white).padding(.horizontal, 10).padding(.vertical, 7)
                        .background(.black.opacity(0.78), in: Capsule()).padding(12)
                        .accessibilityElement(children: .ignore)
                        .accessibilityLabel(media.displayRating.map { String(format: "Рейтинг %.1f", $0) } ?? "Без рейтинга")
                }
                .overlay(alignment: .bottomLeading) {
                    Group {
                        if localCopy != nil { MediaStateBadge(title: "Скачано", symbol: "arrow.down.circle.fill") }
                        else if viewing.nextKnownEpisode != nil { MediaStateBadge(title: "Новая серия", symbol: "sparkle") }
                        else if viewing.isWatched {
                            MediaStateBadge(title: media.kind == .series ? "Серия просмотрена" : "Просмотрено", symbol: "checkmark")
                        }
                    }
                    .padding(12).padding(.bottom, resumeFraction == nil ? 0 : 12)
                    .accessibilityIdentifier("card-state-" + entry.id)
                }
                .overlay(alignment: .bottom) {
                    if let fraction = resumeFraction {
                        GeometryReader { geometry in
                            ZStack(alignment: .leading) {
                                Capsule().fill(.black.opacity(0.65))
                                Capsule().fill(Theme.accent).frame(width: geometry.size.width * CGFloat(fraction))
                            }
                        }
                        .frame(height: 4).padding(.horizontal, 12).padding(.bottom, 9)
                        .accessibilityLabel("Просмотрено")
                        .accessibilityValue("\(Int(fraction * 100)) процентов")
                        .accessibilityIdentifier("card-progress-" + entry.id)
                    }
                }
                // The poster can be a placeholder or a composed preview. Do not
                // let borderless infer its focus target from the rating's star.
                .hoverEffect(.highlight)
            Text(media.title).font(.system(size: 24, weight: .semibold)).lineLimit(2)
                .frame(height: 60, alignment: .topLeading)
                .padding(.top, 16) // Clear the native poster lift before the title.
            Text(media.primaryGenre ?? "Жанр не указан").font(.system(size: 21)).lineLimit(1).foregroundStyle(Theme.secondaryText)
            HStack(spacing: 8) {
                if let year = media.year { Text(String(year)) }
                Text(media.kind == .movie ? "Фильм" : "Сериал")
            }.font(.system(size: 19)).foregroundStyle(Theme.secondaryText)
        }.frame(maxWidth: .infinity, alignment: .leading)
            .accessibilityElement(children: .combine)
            .task(id: model.account.isAuthenticated) {
                guard model.account.isAuthenticated else { metadata = nil; return }
                guard metadata == nil else { return }
                do {
                    let result = try await model.cardMetadata(for: entry)
                    try Task.checkCancellation()
                    metadata = result
                } catch { } // A metadata failure must not block catalog navigation.
            }
    }
}

struct PosterArtwork: View {
    let item: MediaItem
    var body: some View {
        GeometryReader { geometry in
            ZStack {
            RoundedRectangle(cornerRadius: 12).fill(Theme.surface)
            #if DEBUG && targetEnvironment(simulator)
            if PreviewSupport.isSyntheticCatalog { PreviewPosterArtwork(item: item) }
            else { remoteArtwork(size: geometry.size) }
            #else
            remoteArtwork(size: geometry.size)
            #endif
            }.frame(width: geometry.size.width, height: geometry.size.height).clipped()
                .clipShape(RoundedRectangle(cornerRadius: 12))
        }
    }

    private func remoteArtwork(size: CGSize) -> some View {
        PosterImage(url: item.posterURL) {
                    VStack(spacing: 20) {
                        Image(systemName: item.kind == .movie ? "film" : "tv").font(.system(size: 52))
                        Text(item.title).font(.caption).multilineTextAlignment(.center).lineLimit(3)
                    }.foregroundStyle(.secondary).padding(22)
        }.frame(width: size.width, height: size.height).clipped()
    }
}

private struct ContinueWatchingRow: View {
    @EnvironmentObject private var model: AppModel
    private var items: [WatchProgress] {
        Array(model.library.history.filter { !$0.isCompleted && $0.position > 5 }.sorted { $0.updatedAt > $1.updatedAt }.prefix(6))
    }
    var body: some View {
        if !items.isEmpty {
            VStack(alignment: .leading, spacing: 18) {
                Text("Продолжить просмотр").font(.title3.weight(.semibold))
                ScrollView(.horizontal) {
                    LazyHStack(spacing: 30) {
                        ForEach(items) { progress in
                            NavigationLink { MediaDetailsView(entry: model.entry(for: progress)) } label: {
                                HStack(spacing: 20) {
                                    PosterArtwork(item: progress.media).frame(width: 76, height: 114)
                                    VStack(alignment: .leading, spacing: 12) {
                                        Text(progress.media.title).font(.system(size: 22, weight: .medium)).lineLimit(2)
                                        Text(playbackTime(progress.position)).font(.system(size: 18)).foregroundStyle(.secondary)
                                        ProgressView(value: progress.fraction)
                                    }.frame(width: 225, alignment: .leading)
                                }.padding(16)
                            }.buttonStyle(.card)
                        }
                    }.padding(12)
                }.focusSection()
            }
        }
    }
}

struct BrandMark: View {
    var body: some View {
        HStack(spacing: 14) {
            Image("AsanHeart").resizable().scaledToFit().frame(width: 34, height: 34)
            VStack(alignment: .leading, spacing: 2) {
                Text("Asan").font(.system(size: 26, weight: .semibold))
            }
        }.accessibilityElement(children: .combine)
    }
}

struct EmptyLibraryView<Actions: View>: View {
    let symbol: String
    let title: String
    let message: String
    let actions: Actions
    init(symbol: String, title: String, message: String, @ViewBuilder actions: () -> Actions) {
        self.symbol = symbol; self.title = title; self.message = message; self.actions = actions()
    }
    var body: some View {
        VStack(alignment: .leading, spacing: 28) {
            Image(systemName: symbol).font(.system(size: 70)).foregroundStyle(Theme.accent)
            Text(title).font(.largeTitle.bold())
            Text(message).font(.title3).foregroundStyle(.secondary).frame(maxWidth: 950, alignment: .leading)
            actions
        }.frame(maxWidth: .infinity, minHeight: 420, alignment: .leading).padding(35)
    }
}
