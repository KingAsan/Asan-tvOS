import SwiftUI
import Combine
import OSLog
import KinoCore
import RezkaKit

@MainActor
final class AppModel: ObservableObject {
    static let providerID = "rezka"
    @Published var selectedTab: AppTab = .catalog
    @Published var selectedCategory: RezkaCategory = .all
    @Published private(set) var entries: [CatalogEntry] = []
    @Published private(set) var searchResults: [CatalogEntry] = []
    @Published private(set) var library = LibrarySnapshot()
    @Published private(set) var isConfigured = false
    @Published private(set) var mirrorAddress = ""
    @Published private(set) var account = RezkaAccount(id: nil, displayName: "", isAuthenticated: false, isPremium: false)
    @Published private(set) var isCheckingAccount = false
    @Published private(set) var isUpdatingAccount = false
    @Published private(set) var accountError: String?
    @Published private(set) var isRefreshing = false
    @Published private(set) var isSearching = false
    @Published private(set) var hasNextPage = false
    @Published private(set) var searchHasNextPage = false
    @Published private(set) var catalogError: String?
    @Published private(set) var searchError: String?
    @Published var playback: PlaybackRequest? {
        didSet { if playback != nil { cancelTorrentDiscovery() } }
    }
    @Published var torrentDiscovery: TorrentDiscoveryRequest?
    private var pendingTorrentDiscovery: TorrentDiscoveryRequest?
    @Published var notice: Notice?
    @Published var autoplayNext: Bool {
        didSet { defaults.set(autoplayNext, forKey: "autoplayNext") }
    }

    private let defaults: UserDefaults
    private let vault = SourceVault()
    private let mirrorKey = UUID(uuidString: "DC63151D-DC35-493A-83A5-F1890DBE8F32")!
    private let libraryStore: LibraryStore
    private let catalogCache: CatalogCache
    private var cacheWriteTask: Task<Void, Never>?
    private var service: RezkaService?
    private var started = false
    private var catalogGeneration = 0
    private var searchGeneration = 0
    private var accountGeneration = 0
    private let playbackLogger = Logger(subsystem: "dev.local.KinoHD", category: "PlaybackOptions")
    private var currentPage = 0
    private var loadedCategory: RezkaCategory = .all
    private var currentSearchPage = 0
    private var currentQuery = ""
    private var historyWriteTask: Task<Void, Never>?
    private var historyErrorPresented = false
    private var observedRatings: [String: Double] = [:]
    @Published private var knownSeasons: [MediaReference: [Season]] = [:]
    private var knownSeasonOrder: [MediaReference] = []

    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
        autoplayNext = defaults.object(forKey: "autoplayNext") as? Bool ?? true
        let cacheURL = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("KinoHD/rezka-catalog.json")
        catalogCache = CatalogCache(fileURL: cacheURL)
        libraryStore = LibraryStore(persistence: UserDefaultsLibraryPersistence(defaults: defaults))
    }

    func start() async {
        guard !started else { return }
        started = true
        isUpdatingAccount = true
        accountGeneration += 1
        defer { isUpdatingAccount = false }
        #if DEBUG && targetEnvironment(simulator)
        if let scene = PreviewSupport.scene {
            mirrorAddress = "https://rezka.fi/"
            isConfigured = true
            account = PreviewSupport.isSyntheticCatalog
                ? RezkaAccount(displayName: PreviewSupport.demoTitle, isAuthenticated: true, isPremium: false)
                : .guest
            if scene == .restoring { account = .guest; isCheckingAccount = true }
            let previewEntries = PreviewSupport.isSyntheticCatalog ? PreviewSupport.items.map(entry) : []
            if scene == .libraryStates, previewEntries.count >= 3,
               let firstEpisode = previewEntries[0].media.seasons.first?.episodes.first {
                try? await libraryStore.recordProgress(media: previewEntries[0].media, providerID: Self.providerID,
                    episodeID: firstEpisode.id, position: 30, duration: 30)
                try? await libraryStore.recordProgress(media: previewEntries[1].media, providerID: Self.providerID,
                    position: 30, duration: 30)
                try? await libraryStore.recordProgress(media: previewEntries[2].media, providerID: Self.providerID,
                    position: 11, duration: 30)
                rememberSeasons(previewEntries[0].media.seasons, for: previewEntries[0].reference)
                await refreshLibrary()
            }
            if [.localDetails, .localVLCDetails, .introSettings, .recovery].contains(scene),
               let first = previewEntries.first, let episode = first.media.seasons.first?.episodes.first {
                // Real local fixture: canonical position differs from the file's
                // fallback 12 seconds, so UI checks can prove which was chosen.
                try? await libraryStore.recordProgress(media: first.media, providerID: Self.providerID,
                    episodeID: episode.id, position: 18, duration: 30)
                try? await libraryStore.setIntroSkipDuration(15, for: first.reference)
                await refreshLibrary()
            }
            // Publishing entries opens the fixture's details/settings. Finish
            // actor-backed preferences first so those screens read ready state.
            entries = previewEntries
            selectedTab = scene == .settings || scene == .login ? .settings : .catalog
            if scene == .search { selectedTab = .search }
            if scene == .downloads || scene == .torrentList || scene == .torrentPlayer || scene == .torrentVLCPlayer {
                selectedTab = .downloads
            }
            if scene == .player || scene == .playerQualities || scene == .recovery, let first = entries.first {
                let streams = scene == .playerQualities ? PreviewSupport.qualityStreams :
                    [StreamVariant(id: "offline-qa", title: "UI test", url: URL(string: "https://preview.example.invalid/never-requested")!)]
                playback = PlaybackRequest(entry: first, episode: scene == .recovery ? first.media.seasons.first?.episodes.first : nil,
                    streams: streams,
                    initialStreamID: streams[0].id, resumePosition: 0, tracksHistory: false,
                    rezkaDetails: scene == .recovery ? PreviewSupport.details(for: first.media) : nil, translatorID: nil)
            }
            return // No session restore, Keychain reads or network in screenshot mode.
        }
        #endif
        await refreshLibrary()
        do {
            let origin = try await vault.read(id: mirrorKey) ?? URL(string: "https://rezka.fi/")!
            service = try RezkaService(origin: origin)
            mirrorAddress = origin.absoluteString
            isConfigured = true
            isCheckingAccount = true
            if let media = try? await catalogCache.load() {
                entries = media.map(entry)
            }
            await restoreAccount()
            if account.isAuthenticated { await refresh() }
        } catch { isCheckingAccount = false; show(error) }
    }

    func configureMirror(address: String) async throws {
        let text = address.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let origin = URL(string: text), CatalogClient.isSecureURL(origin),
              origin.query == nil, origin.fragment == nil,
              origin.path.isEmpty || origin.path == "/" else { throw CatalogError.insecureURL }
        let candidate = try RezkaService(origin: origin)
        guard !isUpdatingAccount else { throw MirrorSetupError.accountBusy }
        isUpdatingAccount = true
        accountGeneration += 1
        isCheckingAccount = false
        defer { isUpdatingAccount = false }
        try Task.checkCancellation()
        let previous = try await vault.read(id: mirrorKey)
        do {
            try await vault.write(origin, id: mirrorKey)
            try Task.checkCancellation()
        } catch {
            if let previous { try? await vault.write(previous, id: mirrorKey) }
            else { try? await vault.remove(id: mirrorKey) }
            throw error
        }
        catalogGeneration += 1
        searchGeneration += 1
        service = candidate
        mirrorAddress = origin.absoluteString
        isConfigured = true
        selectedCategory = .all
        currentPage = 0
        entries = []
        searchResults = []
        currentQuery = ""
        hasNextPage = false
        searchHasNextPage = false
        isRefreshing = false
        isSearching = false
        catalogError = nil
        searchError = nil
        observedRatings.removeAll()
        cacheWriteTask?.cancel()
        account = RezkaAccount(id: nil, displayName: "", isAuthenticated: false, isPremium: false)
        isCheckingAccount = true
        try? await catalogCache.clear()
        await restoreAccount()
        if account.isAuthenticated { await refresh() }
    }

    func login(username: String, password: String) async throws {
        guard let service else { throw MirrorSetupError.required }
        guard !isUpdatingAccount else { throw MirrorSetupError.accountBusy }
        isUpdatingAccount = true
        accountGeneration += 1
        let generation = accountGeneration
        isCheckingAccount = false
        let sessionKey = cookieKey
        defer { isUpdatingAccount = false }
        let authenticated = try await service.login(username: username, password: password)
        try Task.checkCancellation()
        guard generation == accountGeneration else { throw CancellationError() }
        guard authenticated.isAuthenticated else { throw RezkaError.loginRequired }
        let cookies = try await service.exportSessionCookies()
        try Task.checkCancellation()
        guard generation == accountGeneration else { throw CancellationError() }
        try await vault.writeData(cookies, key: sessionKey)
        guard generation == accountGeneration else { throw CancellationError() }
        account = authenticated
        accountError = nil
        await refresh()
    }

    func logout() async {
        guard let service, !isUpdatingAccount else { return }
        isUpdatingAccount = true
        accountGeneration += 1
        let sessionKey = cookieKey
        defer { isUpdatingAccount = false }
        catalogGeneration += 1; searchGeneration += 1
        account = .guest
        observedRatings.removeAll()
        entries = []; searchResults = []; hasNextPage = false; searchHasNextPage = false
        isRefreshing = false; isSearching = false; isCheckingAccount = false; accountError = nil
        var failure: Error?
        do { try await service.logout() } catch { failure = error }
        do { try await vault.removeData(key: sessionKey) } catch { failure = error }
        cacheWriteTask?.cancel()
        try? await catalogCache.clear()
        if let failure { show(failure) }
    }

    func refreshAccount() async {
        guard let service, !isCheckingAccount, !isUpdatingAccount else { return }
        let generation = accountGeneration
        isCheckingAccount = true
        defer { if generation == accountGeneration { isCheckingAccount = false } }
        do {
            let result = try await service.account()
            try Task.checkCancellation()
            guard generation == accountGeneration else { return }
            account = result
            accountError = nil
        } catch is CancellationError { }
        catch { if generation == accountGeneration { accountError = friendly(error) } }
    }

    private var cookieKey: String {
        let origin = URL(string: mirrorAddress)
        return "rezka.session." + (origin?.host?.lowercased() ?? "rezka.fi") + ":" + String(origin?.port ?? 443)
    }

    private func restoreAccount() async {
        guard let service else { return }
        let generation = accountGeneration
        let sessionKey = cookieKey
        isCheckingAccount = true
        defer { if generation == accountGeneration { isCheckingAccount = false } }
        do {
            if let cookies = try await vault.readData(key: sessionKey) {
                try Task.checkCancellation()
                guard generation == accountGeneration else { return }
                try await service.importSessionCookies(cookies)
            }
            try Task.checkCancellation()
            guard generation == accountGeneration else { return }
            let result = try await service.account()
            try Task.checkCancellation()
            guard generation == accountGeneration else { return }
            account = result
            accountError = nil
        } catch is CancellationError { }
        catch { if generation == accountGeneration { accountError = friendly(error) } }
    }

    func refresh() async { await loadCatalog(reset: true) }
    func loadNextPage() async { await loadCatalog(reset: false) }

    private func loadCatalog(reset: Bool) async {
        guard let service, account.isAuthenticated else { return }
        if !reset && (isRefreshing || !hasNextPage) { return }
        catalogGeneration += 1
        let generation = catalogGeneration
        let category = selectedCategory
        if reset && category != loadedCategory { entries = []; currentPage = 0; hasNextPage = false }
        let requestedPage = reset ? 1 : currentPage + 1
        isRefreshing = true
        defer { if generation == catalogGeneration { isRefreshing = false } }
        do {
            let result = try await service.browse(category: category, page: requestedPage)
            try Task.checkCancellation()
            guard generation == catalogGeneration, selectedCategory == category else { return }
            let incoming = result.items.map { entry($0.media) }
            entries = reset ? incoming : merged(entries, incoming)
            currentPage = result.page
            loadedCategory = category
            hasNextPage = result.hasNextPage
            catalogError = nil
            if category == .all { cacheCatalog() }
        } catch is CancellationError { }
        catch {
            guard generation == catalogGeneration else { return }
            catalogError = friendly(error)
        }
    }

    func search(_ query: String, nextPage: Bool = false) async {
        #if DEBUG && targetEnvironment(simulator)
        if PreviewSupport.scene == .search {
            let term = query.trimmingCharacters(in: .whitespacesAndNewlines)
            searchResults = term.isEmpty ? [] : entries.filter {
                $0.media.title.localizedCaseInsensitiveContains(term)
                    || ($0.media.originalTitle?.localizedCaseInsensitiveContains(term) ?? false)
            }
            searchError = nil
            searchHasNextPage = false
            isSearching = false
            return // Exercise the real bound search UI without account/network access.
        }
        #endif
        guard let service, account.isAuthenticated else { return }
        let term = query.trimmingCharacters(in: .whitespacesAndNewlines)
        if nextPage && (isSearching || !searchHasNextPage || term != currentQuery) { return }
        searchGeneration += 1
        let generation = searchGeneration
        guard !term.isEmpty else {
            currentQuery = ""; searchResults = []; searchError = nil
            isSearching = false; searchHasNextPage = false
            return
        }
        currentQuery = term
        if !nextPage { searchResults = []; searchHasNextPage = false }
        let page = nextPage ? currentSearchPage + 1 : 1
        isSearching = true
        defer { if generation == searchGeneration { isSearching = false } }
        do {
            let result = try await service.search(query: term, page: page)
            try Task.checkCancellation()
            guard generation == searchGeneration else { return }
            let incoming = result.items.map { entry($0.media) }
            searchResults = nextPage ? merged(searchResults, incoming) : incoming
            currentSearchPage = result.page
            searchHasNextPage = result.hasNextPage
            searchError = nil
        } catch is CancellationError { }
        catch { if generation == searchGeneration { searchError = friendly(error) } }
    }

    func details(for entry: CatalogEntry, forceRefresh: Bool = false) async throws -> RezkaDetails {
        #if DEBUG && targetEnvironment(simulator)
        if PreviewSupport.isSyntheticCatalog {
            let result = PreviewSupport.details(for: entry.media)
            rememberSeasons(result.seasons, for: entry.reference)
            return result
        }
        #endif
        guard let service else { throw MirrorSetupError.required }
        let generation = accountGeneration
        let result = try await service.details(media: entry.media, forceRefresh: forceRefresh)
        try Task.checkCancellation()
        guard generation == accountGeneration else { throw MirrorSetupError.staleSelection }
        rememberSeasons(result.seasons, for: entry.reference)
        return result
    }

    /// Only metadata already returned for an opened title; cards never fetch all
    /// seasons in the background. Public identity survives without playback URLs.
    func mediaWithKnownSeasons(for entry: CatalogEntry) -> MediaItem {
        guard let seasons = knownSeasons[entry.reference] else { return entry.media }
        var media = entry.media
        media.seasons = seasons
        return media
    }

    private func rememberSeasons(_ seasons: [Season], for reference: MediaReference) {
        guard !seasons.isEmpty else { return }
        var remaining = 2_048
        let compact = seasons.sorted { $0.number < $1.number }.prefix(128).compactMap { season -> Season? in
            guard remaining > 0 else { return nil }
            let episodes = season.episodes.sorted { $0.number < $1.number }.prefix(remaining).map {
                Episode(id: $0.id, title: $0.title, number: $0.number, durationMinutes: $0.durationMinutes)
            }
            remaining -= episodes.count
            return Season(id: season.id, title: season.title, number: season.number, episodes: episodes)
        }
        guard !compact.isEmpty else { return }
        knownSeasonOrder.removeAll { $0 == reference }
        knownSeasonOrder.append(reference)
        while knownSeasonOrder.count > 12 {
            knownSeasons.removeValue(forKey: knownSeasonOrder.removeFirst())
        }
        if knownSeasons[reference] != compact { knownSeasons[reference] = compact }
    }

    func cardMetadata(for entry: CatalogEntry) async throws -> MediaItem {
        #if DEBUG && targetEnvironment(simulator)
        if PreviewSupport.isSyntheticCatalog { return entry.media }
        #endif
        guard let service, account.isAuthenticated else { return entry.media }
        let generation = accountGeneration
        let media = try await service.cardMetadata(media: entry.media)
        try Task.checkCancellation()
        guard generation == accountGeneration else { throw CancellationError() }
        if let rating = media.displayRating {
            if observedRatings.count >= 128, observedRatings[entry.id] == nil { observedRatings.removeAll() }
            observedRatings[entry.id] = rating
        }
        return media
    }

    func knownRating(for entry: CatalogEntry) -> Double? { observedRatings[entry.id] ?? entry.media.displayRating }

    func seasons(for details: RezkaDetails, translatorID: String) async throws -> [Season] {
        #if DEBUG && targetEnvironment(simulator)
        if PreviewSupport.isSyntheticCatalog { return details.seasons }
        #endif
        guard let service else { throw MirrorSetupError.required }
        let generation = accountGeneration
        let result = try await service.seasons(details: details, translatorID: translatorID)
        try Task.checkCancellation()
        guard generation == accountGeneration else { throw MirrorSetupError.staleSelection }
        rememberSeasons(result, for: MediaReference(providerID: Self.providerID, itemID: details.media.id))
        return result
    }

    func playbackRequest(details: RezkaDetails, translatorID: String, seasons: [Season],
                         season: Season?, episode: Episode?, fromStart: Bool = false) async throws -> PlaybackRequest {
        guard let service else { throw MirrorSetupError.required }
        let generation = accountGeneration
        let startedAt = Date()
        let values = try await service.streams(details: details, translatorID: translatorID, season: season, episode: episode)
        try Task.checkCancellation()
        guard generation == accountGeneration else { throw MirrorSetupError.staleSelection }
        let streams = PlaybackVariantPolicy.available(values)
        let elapsed = Date().timeIntervalSince(startedAt)
        playbackLogger.info("Resolved \(streams.count, privacy: .public) variants in \(elapsed, privacy: .public) seconds")
        let choices = PlaybackVariantPolicy.choices(streams)
        let preference = UserDefaults.standard.string(forKey: "Asan.preferredQuality")
        guard let first = choices.first(where: { PlaybackVariantPolicy.label(for: $0) == preference }) ?? choices.first else {
            throw MirrorSetupError.noStreams
        }
        var media = details.media
        media.seasons = seasons
        let resolvedEntry = entry(media)
        let saved = progress(for: resolvedEntry, episodeID: episode?.id)
        let resume = fromStart || saved?.isCompleted == true ? 0 : (saved?.position ?? 0)
        return PlaybackRequest(entry: resolvedEntry, episode: episode, streams: streams,
            initialStreamID: first.id, resumePosition: resume, tracksHistory: true,
            rezkaDetails: details, translatorID: translatorID)
    }

    func preparePlayback(details: RezkaDetails, translatorID: String, seasons: [Season],
                         season: Season?, episode: Episode?, fromStart: Bool) async throws -> PreparedPlayback {
        let generation = accountGeneration
        let request = try await playbackRequest(details: details, translatorID: translatorID, seasons: seasons,
            season: season, episode: episode, fromStart: fromStart)
        guard generation == accountGeneration else { throw MirrorSetupError.staleSelection }
        return PreparedPlayback(request: request, accountGeneration: generation)
    }

    func beginPlayback(_ prepared: PreparedPlayback, streamID: String) throws {
        playback = try validatedPlayback(prepared, streamID: streamID)
    }

    func validatedPlayback(_ prepared: PreparedPlayback, streamID: String) throws -> PlaybackRequest {
        guard prepared.accountGeneration == accountGeneration, account.isAuthenticated, !isUpdatingAccount else {
            throw MirrorSetupError.staleSelection
        }
        guard prepared.request.streams.contains(where: { $0.id == streamID }) else { throw MirrorSetupError.noStreams }
        if let stream = prepared.request.streams.first(where: { $0.id == streamID }) {
            UserDefaults.standard.set(PlaybackVariantPolicy.label(for: stream), forKey: "Asan.preferredQuality")
        }
        return prepared.request.selecting(streamID)
    }

    func nextPlayback(after request: PlaybackRequest) async throws -> PlaybackRequest? {
        guard let details = request.rezkaDetails, let translatorID = request.translatorID,
              let current = request.episode else { return nil }
        let indexed = request.entry.media.seasons.sorted { $0.number < $1.number }.flatMap { season in
            season.episodes.sorted { $0.number < $1.number }.map { (season, $0) }
        }
        guard let index = indexed.firstIndex(where: { $0.1.id == current.id }), indexed.indices.contains(index + 1) else { return nil }
        let next = indexed[index + 1]
        return try await playbackRequest(details: details, translatorID: translatorID,
            seasons: request.entry.media.seasons, season: next.0, episode: next.1, fromStart: true)
    }

    func refreshPlayback(_ request: PlaybackRequest) async throws -> PlaybackRequest? {
        guard request.rezkaDetails != nil, let translatorID = request.translatorID else { return nil }
        let refreshed = try await details(for: request.entry, forceRefresh: true)
        let season = request.entry.media.seasons.first { value in value.episodes.contains { $0.id == request.episode?.id } }
        return try await playbackRequest(details: refreshed, translatorID: translatorID,
            seasons: request.entry.media.seasons, season: season, episode: request.episode)
    }

    private func entry(_ media: MediaItem) -> CatalogEntry {
        CatalogEntry(providerID: Self.providerID, providerName: "Rezka", media: media)
    }
    func entry(for saved: SavedMedia) -> CatalogEntry { entry(saved.media) }
    func entry(for progress: WatchProgress) -> CatalogEntry { entry(progress.media) }
    func isFavorite(_ entry: CatalogEntry) -> Bool { library.favorites.contains { $0.reference == entry.reference } }
    func isWatchlisted(_ entry: CatalogEntry) -> Bool { library.watchlist.contains { $0.reference == entry.reference } }

    func toggleFavorite(_ entry: CatalogEntry) async {
        do {
            try await libraryStore.setFavorite(!isFavorite(entry), media: entry.media, providerID: Self.providerID)
            await refreshLibrary()
        } catch { show(error) }
    }

    func toggleWatchlist(_ entry: CatalogEntry) async {
        do {
            try await libraryStore.setWatchlisted(!isWatchlisted(entry), media: entry.media, providerID: Self.providerID)
            await refreshLibrary()
        } catch { show(error) }
    }

    func progress(for entry: CatalogEntry, episodeID: String? = nil) -> WatchProgress? {
        library.history.first { $0.reference == entry.reference && $0.episodeID == episodeID }
    }

    func playDirect(address: String) throws {
        guard let url = URL(string: address.trimmingCharacters(in: .whitespacesAndNewlines)), CatalogClient.isSecureURL(url) else {
            throw CatalogError.insecureURL
        }
        let stream = StreamVariant(id: "direct", title: "Прямая ссылка", url: url)
        let media = MediaItem(id: UUID().uuidString, title: "Видео по ссылке", kind: .movie, streams: [stream])
        let direct = CatalogEntry(providerID: "direct", providerName: "Прямая ссылка", media: media)
        playback = PlaybackRequest(entry: direct, episode: nil, streams: [stream], initialStreamID: stream.id,
                                   resumePosition: 0, tracksHistory: false, rezkaDetails: nil, translatorID: nil)
    }

    func enqueueRecord(_ request: PlaybackRequest, position: Double, duration: Double) {
        let previous = historyWriteTask
        historyWriteTask = Task { [weak self] in
            await previous?.value
            guard let self else { return }
            await self.record(request, position: position, duration: duration)
        }
    }

    /// Source-independent history uses the same canonical provider/media/episode
    /// identity. An unrecognised torrent filename keeps only per-file progress.
    func enqueueLocalRecord(_ association: TorrentMediaAssociation?, position: Double, duration: Double) {
        guard let association, association.canRecordProgress else { return }
        let previous = historyWriteTask
        historyWriteTask = Task { [weak self] in
            await previous?.value
            guard let self, position.isFinite, position >= 0 else { return }
            do {
                try await self.libraryStore.recordProgress(media: association.media,
                    providerID: association.reference.providerID, episodeID: association.episodeID,
                    position: position, duration: duration.isFinite && duration > 0 ? duration : 0)
                self.historyErrorPresented = false
                await self.refreshLibrary()
            } catch {
                if !self.historyErrorPresented { self.historyErrorPresented = true; self.show(error) }
            }
        }
    }

    func introSkipDuration(for reference: MediaReference) -> Double {
        library.introSkips.first { $0.reference == reference }?.duration ?? 0
    }

    @discardableResult
    func setIntroSkipDuration(_ seconds: Double, for reference: MediaReference) async -> Bool {
        do {
            try await libraryStore.setIntroSkipDuration(seconds, for: reference)
            await refreshLibrary()
            return true
        } catch { show(error); return false }
    }

    func requestTorrentAlternative(for request: PlaybackRequest, presentationID: UUID) {
        guard playback?.id == presentationID, request.rezkaDetails != nil else { return }
        pendingTorrentDiscovery = TorrentDiscoveryRequest(entry: request.entry, episodeID: request.episode?.id)
        playback = nil
    }

    /// UIKit has finished closing the player before a new sheet can take focus.
    func playbackDidDismiss() {
        guard let pending = pendingTorrentDiscovery else { return }
        Task { [weak self] in
            guard let self else { return }
            await self.historyWriteTask?.value
            guard self.playback == nil, self.pendingTorrentDiscovery?.id == pending.id else { return }
            self.pendingTorrentDiscovery = nil
            self.torrentDiscovery = pending
        }
    }

    func cancelTorrentDiscovery() {
        pendingTorrentDiscovery = nil
        torrentDiscovery = nil
    }

    private func record(_ request: PlaybackRequest, position: Double, duration: Double) async {
        guard request.tracksHistory, position.isFinite, position >= 0 else { return }
        do {
            try await libraryStore.recordProgress(media: request.entry.media, providerID: Self.providerID,
                episodeID: request.episode?.id, position: position, duration: duration.isFinite && duration > 0 ? duration : 0)
            historyErrorPresented = false
            await refreshLibrary()
        } catch { if !historyErrorPresented { historyErrorPresented = true; show(error) } }
    }

    func removeProgress(_ progress: WatchProgress) async {
        await historyWriteTask?.value
        do {
            try await libraryStore.removeHistory(reference: progress.reference, episodeID: progress.episodeID)
            await refreshLibrary()
        } catch { show(error) }
    }

    func clearLibrary() async {
        await historyWriteTask?.value
        do { try await libraryStore.reset(); await refreshLibrary() } catch { show(error) }
    }

    func show(_ error: Error) { notice = Notice(title: "Не удалось выполнить действие", message: friendly(error)) }

    func friendly(_ error: Error) -> String {
        if let error = error as? RezkaError { return error.localizedDescription }
        if let error = error as? MirrorSetupError { return error.localizedDescription }
        if let error = error as? CatalogError { return error.localizedDescription }
        if let error = error as? LibraryError { return error.localizedDescription }
        if error is VaultError { return "Не удалось прочитать защищённые настройки Rezka." }
        if error is URLError { return "Сервер недоступен. Проверь сеть и адрес Rezka в настройках." }
        return "Не удалось прочитать или сохранить данные. Повтори действие."
    }

    private func refreshLibrary() async {
        do { library = try await libraryStore.snapshot() } catch { show(error) }
    }

    private func merged(_ current: [CatalogEntry], _ incoming: [CatalogEntry]) -> [CatalogEntry] {
        var seen = Set(current.map(\.id))
        return current + incoming.filter { seen.insert($0.id).inserted }
    }

    private func cacheCatalog() {
        cacheWriteTask?.cancel()
        let snapshot = entries.map(\.media)
        let cache = catalogCache
        cacheWriteTask = Task(priority: .utility) { _ = try? await cache.store(snapshot) }
    }
}

enum MirrorSetupError: Error, LocalizedError {
    case required, noStreams, noEpisodes, accountBusy, staleSelection
    var errorDescription: String? {
        switch self {
        case .required: return "Укажи адрес Rezka в настройках."
        case .noStreams: return "Для выбранной озвучки нет доступных ссылок на видео."
        case .noEpisodes: return "Для этой озвучки список серий не получен. Попробуй другую озвучку или повтори запрос."
        case .accountBusy: return "Дождись завершения входа, выхода или смены зеркала."
        case .staleSelection: return "Аккаунт или зеркало изменились. Вернись к карточке и выбери озвучку ещё раз."
        }
    }
}
