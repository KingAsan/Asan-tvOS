import SwiftUI
import AVKit
import AVFoundation
import Combine
import UIKit

/// This player receives only a completed, owned cache file from the download
/// model. It deliberately has no remote URL or network playback path.
@MainActor
private final class TorrentLocalPlaybackController: ObservableObject {
    let player = AVPlayer()
    @Published private(set) var isWaiting = true
    @Published private(set) var errorMessage: String?
    @Published private(set) var playbackState = "Подготовка"
    private let playback: TorrentLocalPlayback
    private var statusObservation: NSKeyValueObservation?
    private var waitingObservation: NSKeyValueObservation?
    private var failureObserver: NSObjectProtocol?
    private var startupTask: Task<Void, Never>?
    private var generation = 0
    private var started = false
    private var stopped = false
    private var didPrepareItem = false
    private var didStartPlaying = false

    init(playback: TorrentLocalPlayback) { self.playback = playback }

    func start() {
        guard !started, !stopped else { return }
        started = true
        load()
    }

    func retry() {
        guard !stopped else { return }
        load()
    }

    func stop() {
        guard !stopped else { return }
        stopped = true
        generation += 1
        player.pause()
        clearObservers()
        player.replaceCurrentItem(with: nil)
    }

    private func load() {
        generation += 1
        let expected = generation
        clearObservers()
        player.pause()
        player.replaceCurrentItem(with: nil)
        stopped = false
        didPrepareItem = false
        didStartPlaying = false
        isWaiting = true
        errorMessage = nil
        playbackState = "Подготовка"

        let url = playback.url
        guard url.isFileURL, url.host == nil || url.host?.isEmpty == true,
              let values = try? url.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey]),
              values.isRegularFile == true, values.isSymbolicLink != true,
              FileManager.default.isReadableFile(atPath: url.path) else {
            fail("Файла больше нет в кэше. Вернись к загрузкам и скачай его снова.", generation: expected)
            return
        }

        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .moviePlayback)
            try AVAudioSession.sharedInstance().setActive(true)
        } catch {
            fail("Не удалось подготовить звук. Повтори попытку или вернись к загрузкам.", generation: expected)
            return
        }

        let item = AVPlayerItem(url: url)
        let title = AVMutableMetadataItem()
        title.identifier = .commonIdentifierTitle
        title.value = playback.title as NSString
        title.extendedLanguageTag = "ru"
        item.externalMetadata = [title]

        statusObservation = item.observe(\.status, options: [.initial, .new]) { [weak self, weak item] _, _ in
            Task { @MainActor [weak self, weak item] in
                guard let self, let item, self.generation == expected, !self.stopped else { return }
                switch item.status {
                case .readyToPlay:
                    self.didPrepareItem = true
                    self.player.play()
                case .failed:
                    self.fail("Приставка не смогла воспроизвести этот файл. Возможно, его кодек не поддерживается.", generation: expected)
                case .unknown: break
                @unknown default: break
                }
            }
        }
        waitingObservation = player.observe(\.timeControlStatus, options: [.initial, .new]) { [weak self] _, _ in
            Task { @MainActor [weak self] in
                guard let self, self.generation == expected, !self.stopped else { return }
                if self.player.timeControlStatus == .playing {
                    self.didStartPlaying = true
                    self.isWaiting = false
                    self.playbackState = "Воспроизводится"
                    self.startupTask?.cancel()
                    self.startupTask = nil
                } else {
                    self.isWaiting = self.player.timeControlStatus == .waitingToPlayAtSpecifiedRate || !self.didPrepareItem
                    self.playbackState = self.isWaiting ? "Подготовка" : "Пауза"
                }
            }
        }
        failureObserver = NotificationCenter.default.addObserver(
            forName: .AVPlayerItemFailedToPlayToEndTime, object: item, queue: .main
        ) { [weak self] _ in
            Task { @MainActor [weak self] in
                self?.fail("Не удалось продолжить воспроизведение файла. Повтори попытку или вернись к загрузкам.", generation: expected)
            }
        }
        player.replaceCurrentItem(with: item)
        startupTask = Task { @MainActor [weak self] in
            do { try await Task.sleep(for: .seconds(20)) } catch { return }
            guard let self, self.generation == expected, !self.stopped, !self.didStartPlaying else { return }
            self.fail("Фильм не запустился вовремя. Повтори попытку или вернись к загрузкам.", generation: expected)
        }
    }

    private func fail(_ message: String, generation expected: Int) {
        guard generation == expected, !stopped else { return }
        generation += 1
        player.pause()
        clearObservers()
        isWaiting = false
        errorMessage = message
        playbackState = "Ошибка воспроизведения"
    }

    private func clearObservers() {
        startupTask?.cancel()
        startupTask = nil
        statusObservation?.invalidate()
        statusObservation = nil
        waitingObservation?.invalidate()
        waitingObservation = nil
        if let failureObserver { NotificationCenter.default.removeObserver(failureObserver) }
        failureObserver = nil
    }
}

@MainActor
private struct TorrentNativeLocalPlayer: UIViewControllerRepresentable {
    let player: AVPlayer
    let isExitEnabled: Bool
    let close: () -> Void

    func makeCoordinator() -> Coordinator { Coordinator(close: close) }

    func makeUIViewController(context: Context) -> AVPlayerViewController {
        let controller = AVPlayerViewController()
        controller.player = player
        controller.showsPlaybackControls = true
        controller.delegate = context.coordinator
        context.coordinator.playerController = controller
        context.coordinator.isExitEnabled = isExitEnabled
        let menu = UITapGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.menuPressed(_:)))
        menu.allowedPressTypes = [NSNumber(value: UIPress.PressType.menu.rawValue)]
        menu.cancelsTouchesInView = false
        menu.delegate = context.coordinator
        controller.view.addGestureRecognizer(menu)
        context.coordinator.menuRecognizer = menu
        return controller
    }

    func updateUIViewController(_ controller: AVPlayerViewController, context: Context) {
        if controller.player !== player { controller.player = player }
        context.coordinator.close = close
        context.coordinator.isExitEnabled = isExitEnabled
    }

    static func dismantleUIViewController(_ controller: AVPlayerViewController, coordinator: Coordinator) {
        if let menu = coordinator.menuRecognizer { controller.view.removeGestureRecognizer(menu) }
        coordinator.menuRecognizer = nil
        coordinator.playerController = nil
        coordinator.close = {}
        controller.player?.pause()
        controller.player = nil
        controller.delegate = nil
    }

    final class Coordinator: NSObject, @preconcurrency AVPlayerViewControllerDelegate, UIGestureRecognizerDelegate {
        var close: () -> Void
        var isExitEnabled = true
        weak var playerController: AVPlayerViewController?
        var menuRecognizer: UITapGestureRecognizer?
        init(close: @escaping () -> Void) { self.close = close }

        @objc func menuPressed(_ recognizer: UITapGestureRecognizer) {
            guard recognizer.state == .ended, isExitEnabled,
                  let playerController, playerController.presentedViewController == nil else { return }
            close()
        }

        func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive press: UIPress) -> Bool {
            press.type == .menu && isExitEnabled && playerController?.viewIfLoaded?.window != nil
                && playerController?.presentedViewController == nil
        }

        func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer,
                               shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool { true }

        func playerViewControllerShouldDismiss(_ playerViewController: AVPlayerViewController) -> Bool { isExitEnabled }

        func playerViewControllerDidEndDismissalTransition(_ playerViewController: AVPlayerViewController) {
            if isExitEnabled { close() }
        }
    }
}

@MainActor
private struct TorrentAVLocalPlayer: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var controller: TorrentLocalPlaybackController
    @State private var isClosing = false

    init(playback: TorrentLocalPlayback) {
        _controller = StateObject(wrappedValue: TorrentLocalPlaybackController(playback: playback))
    }

    var body: some View {
        ZStack {
            TorrentNativeLocalPlayer(player: controller.player, isExitEnabled: !isClosing, close: close)
                .ignoresSafeArea()
            if controller.isWaiting && controller.errorMessage == nil {
                VStack(spacing: 22) {
                    ProgressView("Открываем скачанный фильм…")
                    Text("Можно вернуться кнопкой «Назад»").font(.callout).foregroundStyle(.secondary)
                }.padding(36).asanPanel().allowsHitTesting(false)
                    .accessibilityIdentifier("torrent-local-loading")
            }
            if let message = controller.errorMessage {
                VStack(spacing: 28) {
                    Text("Не удалось открыть фильм").font(.largeTitle.bold())
                    Text(message).font(.title3).multilineTextAlignment(.center).frame(maxWidth: 1000)
                        .accessibilityIdentifier("torrent-local-error")
                    HStack(spacing: 28) {
                        Button("Повторить") { controller.retry() }.accessibilityIdentifier("torrent-local-retry")
                        Button("Назад к загрузкам") { close() }.accessibilityIdentifier("torrent-local-back")
                    }.focusSection()
                }
                .padding(60).frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(.black.opacity(0.95))
                .onExitCommand { close() }
            }
        }
        .background(.black)
        .accessibilityElement(children: .contain)
        .accessibilityLabel("Плеер скачанного фильма")
        .accessibilityValue(controller.playbackState)
        .accessibilityIdentifier("torrent-local-player")
        .onExitCommand { close() }
        .task { controller.start() }
        .onDisappear { controller.stop() }
    }

    private func close() {
        guard !isClosing else { return }
        isClosing = true
        controller.stop()
        dismiss()
    }
}

/// AVKit remains the first choice for native containers; VLC supplies local
/// formats that AVPlayer cannot demux. Remote URLs never enter either branch.
@MainActor
struct TorrentLocalPlayer: View {
    let playback: TorrentLocalPlayback

    private var usesVLC: Bool {
        #if DEBUG && targetEnvironment(simulator)
        if PreviewSupport.scene == .torrentVLCPlayer { return true }
        #endif
        return ["mkv", "webm", "avi", "ts"].contains(playback.url.pathExtension.lowercased())
    }

    var body: some View {
        if usesVLC { TorrentVLCPlayer(playback: playback) }
        else { TorrentAVLocalPlayer(playback: playback) }
    }
}
