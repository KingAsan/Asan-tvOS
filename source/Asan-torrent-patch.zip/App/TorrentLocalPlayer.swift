import SwiftUI
import AVKit
import AVFoundation
import Combine
import UIKit
import KinoCore

/// This player receives only a completed, owned cache file from the download
/// model. It deliberately has no remote URL or network playback path.
@MainActor
private final class TorrentLocalPlaybackController: ObservableObject {
    let player = AVPlayer()
    @Published private(set) var isWaiting = true
    @Published private(set) var errorMessage: String?
    @Published private(set) var playbackState = "Подготовка"
    @Published private(set) var canSkipIntro = false
    #if DEBUG && targetEnvironment(simulator)
    @Published private(set) var actualPosition = 0.0
    @Published private(set) var actualDuration = 0.0
    @Published private(set) var firstPlayingPosition: Double?
    #endif
    private let playback: TorrentLocalPlayback
    private var statusObservation: NSKeyValueObservation?
    private var waitingObservation: NSKeyValueObservation?
    private var durationObservation: NSKeyValueObservation?
    private var failureObserver: NSObjectProtocol?
    private var endObserver: NSObjectProtocol?
    private var timeObserver: Any?
    private var startupTask: Task<Void, Never>?
    private var generation = 0
    private var started = false
    private var stopped = false
    private var didPrepareItem = false
    private var didStartPlaying = false
    private var hasEnded = false
    private var configuredResume = 0.0
    private var introSeconds = 0.0
    private var resumeIssued = false
    private var resumeAcknowledged = false
    private var lastSample: (position: Double, duration: Double)?
    private var lastSaveUptime = 0.0
    private var suspendedForScene = false
    private var resumeWhenActive = false
    private var onProgress: ((Double, Double, Bool) -> Void)?

    init(playback: TorrentLocalPlayback) { self.playback = playback }

    func start(resumePosition: Double, introSeconds: Double,
               onProgress: @escaping (Double, Double, Bool) -> Void) {
        guard !started, !stopped else { return }
        configuredResume = resumePosition.isFinite ? max(0, resumePosition) : 0
        self.onProgress = onProgress
        updateIntroDuration(introSeconds)
        started = true
        load()
    }

    func retry() {
        guard !stopped else { return }
        load()
    }

    func stop() {
        guard !stopped else { return }
        reportProgress(force: true)
        stopped = true
        generation += 1
        player.pause()
        clearObservers()
        player.replaceCurrentItem(with: nil)
        onProgress = nil
    }

    func updateIntroDuration(_ seconds: Double) {
        introSeconds = seconds.isFinite && (0...600).contains(seconds) ? seconds : 0
        updateIntroAvailability()
    }

    func skipIntro() {
        guard resumeAcknowledged, let item = player.currentItem,
              let target = IntroPlaybackPolicy.target(position: player.currentTime().seconds,
                  duration: item.duration.seconds, introSeconds: introSeconds) else { return }
        let expected = generation
        player.seek(to: CMTime(seconds: target, preferredTimescale: 600), toleranceBefore: .zero, toleranceAfter: .zero) { [weak self] finished in
            Task { @MainActor [weak self] in
                guard let self, self.generation == expected, !self.stopped, finished else { return }
                self.updateIntroAvailability()
                self.reportProgress(force: true)
            }
        }
    }

    func updateScenePhase(_ phase: ScenePhase) {
        guard !stopped else { return }
        if phase == .active {
            guard suspendedForScene else { return }
            suspendedForScene = false
            let shouldResume = resumeWhenActive
            resumeWhenActive = false
            beginPlaybackIfReady(generation: generation)
            if shouldResume, errorMessage == nil, resumeAcknowledged { player.play() }
            if !didStartPlaying, errorMessage == nil { armStartupDeadline() }
        } else {
            reportProgress(force: true)
            startupTask?.cancel()
            startupTask = nil
            if !suspendedForScene { resumeWhenActive = player.timeControlStatus == .playing || !didStartPlaying && errorMessage == nil }
            suspendedForScene = true
            player.pause()
        }
    }

    private func load() {
        reportProgress(force: true)
        generation += 1
        let expected = generation
        clearObservers()
        player.pause()
        player.replaceCurrentItem(with: nil)
        stopped = false
        didPrepareItem = false
        didStartPlaying = false
        hasEnded = false
        resumeIssued = false
        resumeAcknowledged = false
        canSkipIntro = false
        #if DEBUG && targetEnvironment(simulator)
        actualPosition = 0
        actualDuration = 0
        firstPlayingPosition = nil
        #endif
        lastSaveUptime = ProcessInfo.processInfo.systemUptime
        isWaiting = true
        errorMessage = nil
        playbackState = "Подготовка"

        let url = playback.url
        guard url.isFileURL, url.host == nil || url.host?.isEmpty == true,
              let values = try? url.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey]),
              values.isRegularFile == true, values.isSymbolicLink != true,
              FileManager.default.isReadableFile(atPath: url.path) else {
            fail("Файла больше нет в кэше. Вернись к загрузкам и скачай его снова.", generation: expected)
            return
        }

        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .moviePlayback)
            try AVAudioSession.sharedInstance().setActive(true)
        } catch {
            fail("Не удалось подготовить звук. Повтори попытку или вернись к загрузкам.", generation: expected)
            return
        }

        let item = AVPlayerItem(url: url)
        let title = AVMutableMetadataItem()
        title.identifier = .commonIdentifierTitle
        title.value = playback.title as NSString
        title.extendedLanguageTag = "ru"
        item.externalMetadata = [title]

        statusObservation = item.observe(\.status, options: [.initial, .new]) { [weak self, weak item] _, _ in
            Task { @MainActor [weak self, weak item] in
                guard let self, let item, self.generation == expected, !self.stopped else { return }
                switch item.status {
                case .readyToPlay:
                    self.didPrepareItem = true
                    self.beginPlaybackIfReady(generation: expected)
                case .failed:
                    self.fail("Приставка не смогла воспроизвести этот файл. Возможно, его кодек не поддерживается.", generation: expected)
                case .unknown: break
                @unknown default: break
                }
            }
        }
        durationObservation = item.observe(\.duration, options: [.new]) { [weak self] _, _ in
            Task { @MainActor [weak self] in self?.beginPlaybackIfReady(generation: expected) }
        }
        waitingObservation = player.observe(\.timeControlStatus, options: [.initial, .new]) { [weak self, weak item] observed, change in
            #if DEBUG && targetEnvironment(simulator)
            // Capture the native clock before scheduling a MainActor task;
            // a later accessibility snapshot may arrive seconds after start.
            let source = ObjectIdentifier(observed)
            let firstClock = change.newValue == .playing && observed.timeControlStatus == .playing
                && observed.currentItem === item ? observed.currentTime().seconds : nil
            #endif
            Task { @MainActor [weak self] in
                guard let self, self.generation == expected, !self.stopped else { return }
                #if DEBUG && targetEnvironment(simulator)
                if let item, self.player.currentItem === item, source == ObjectIdentifier(self.player),
                   self.resumeAcknowledged, self.firstPlayingPosition == nil,
                   let firstClock, firstClock.isFinite, firstClock >= 0 {
                    self.firstPlayingPosition = firstClock
                }
                #endif
                if self.player.timeControlStatus == .playing && self.resumeAcknowledged {
                    self.hasEnded = false
                    self.didStartPlaying = true
                    self.isWaiting = false
                    self.playbackState = "Воспроизводится"
                    self.startupTask?.cancel()
                    self.startupTask = nil
                } else {
                    self.isWaiting = !self.resumeAcknowledged || self.player.timeControlStatus == .waitingToPlayAtSpecifiedRate || !self.didPrepareItem
                    self.playbackState = self.hasEnded ? "Просмотр завершён" : self.isWaiting ? "Подготовка" : "Пауза"
                }
            }
        }
        failureObserver = NotificationCenter.default.addObserver(
            forName: .AVPlayerItemFailedToPlayToEndTime, object: item, queue: .main
        ) { [weak self] _ in
            Task { @MainActor [weak self] in
                self?.fail("Не удалось продолжить воспроизведение файла. Повтори попытку или вернись к загрузкам.", generation: expected)
            }
        }
        endObserver = NotificationCenter.default.addObserver(forName: .AVPlayerItemDidPlayToEndTime, object: item, queue: .main) { [weak self] _ in
            Task { @MainActor [weak self] in
                guard let self, self.generation == expected, !self.stopped else { return }
                self.hasEnded = true
                self.reportProgress(force: true, ended: true)
                self.playbackState = "Просмотр завершён"
                self.canSkipIntro = false
            }
        }
        player.replaceCurrentItem(with: item)
        timeObserver = player.addPeriodicTimeObserver(forInterval: CMTime(seconds: 1, preferredTimescale: 600), queue: .main) { [weak self] _ in
            Task { @MainActor [weak self] in
                guard let self, self.generation == expected, !self.stopped else { return }
                self.beginPlaybackIfReady(generation: expected)
                self.updateActualTime()
                self.updateIntroAvailability()
                self.reportProgress(force: false)
            }
        }
        armStartupDeadline()
    }

    private func armStartupDeadline() {
        startupTask?.cancel()
        let expected = generation
        guard !suspendedForScene, !stopped else { return }
        startupTask = Task { @MainActor [weak self] in
            do { try await Task.sleep(for: .seconds(20)) } catch { return }
            guard let self, self.generation == expected, !self.stopped, !self.suspendedForScene, !self.didStartPlaying else { return }
            self.fail("Фильм не запустился вовремя. Повтори попытку или вернись к загрузкам.", generation: expected)
        }
    }

    private func beginPlaybackIfReady(generation expected: Int) {
        guard generation == expected, !stopped, !resumeIssued, let item = player.currentItem,
              item.status == .readyToPlay, item.duration.seconds.isFinite, item.duration.seconds > 0 else { return }
        resumeIssued = true
        let target = IntroPlaybackPolicy.resume(position: lastSample?.position ?? configuredResume, duration: item.duration.seconds)
        guard target > 0 else {
            resumeAcknowledged = true
            if !suspendedForScene { player.play() } else { resumeWhenActive = true }
            return
        }
        player.seek(to: CMTime(seconds: target, preferredTimescale: 600), toleranceBefore: .zero, toleranceAfter: .zero) { [weak self] finished in
            Task { @MainActor [weak self] in
                guard let self, self.generation == expected, !self.stopped else { return }
                let actual = self.player.currentTime().seconds
                guard finished, actual.isFinite, abs(actual - target) <= 2 else {
                    self.fail("Не удалось восстановить сохранённую позицию. Повтори попытку.", generation: expected)
                    return
                }
                self.resumeAcknowledged = true
                self.updateActualTime()
                if !self.suspendedForScene { self.player.play() } else { self.resumeWhenActive = true }
            }
        }
    }

    private func updateIntroAvailability() {
        let available = resumeAcknowledged && player.currentItem.map {
            IntroPlaybackPolicy.target(position: player.currentTime().seconds, duration: $0.duration.seconds, introSeconds: introSeconds) != nil
        } == true
        if canSkipIntro != available { canSkipIntro = available }
    }

    private func updateActualTime() {
        #if DEBUG && targetEnvironment(simulator)
        let position = player.currentTime().seconds
        let duration = player.currentItem?.duration.seconds ?? 0
        if position.isFinite, position >= 0 { actualPosition = position }
        if duration.isFinite, duration > 0 { actualDuration = duration }
        #endif
    }

    private func reportProgress(force: Bool, ended: Bool = false) {
        guard resumeAcknowledged, didStartPlaying, !stopped else { return }
        if let item = player.currentItem, item.status == .readyToPlay {
            let duration = item.duration.seconds
            let position = ended || hasEnded ? duration : player.currentTime().seconds
            if duration.isFinite, duration > 0, position.isFinite, position >= 0 {
                lastSample = (min(position, duration), duration)
            }
        }
        guard let sample = lastSample else { return }
        let uptime = ProcessInfo.processInfo.systemUptime
        guard force || uptime - lastSaveUptime >= 10 else { return }
        lastSaveUptime = uptime
        onProgress?(sample.position, sample.duration, force)
    }

    private func fail(_ message: String, generation expected: Int) {
        guard generation == expected, !stopped else { return }
        reportProgress(force: true)
        generation += 1
        player.pause()
        clearObservers()
        isWaiting = false
        errorMessage = message
        playbackState = "Ошибка воспроизведения"
    }

    private func clearObservers() {
        startupTask?.cancel()
        startupTask = nil
        statusObservation?.invalidate()
        statusObservation = nil
        waitingObservation?.invalidate()
        waitingObservation = nil
        durationObservation?.invalidate()
        durationObservation = nil
        if let timeObserver { player.removeTimeObserver(timeObserver) }
        timeObserver = nil
        if let failureObserver { NotificationCenter.default.removeObserver(failureObserver) }
        failureObserver = nil
        if let endObserver { NotificationCenter.default.removeObserver(endObserver) }
        endObserver = nil
    }
}

@MainActor
private struct TorrentNativeLocalPlayer: UIViewControllerRepresentable {
    let player: AVPlayer
    let isExitEnabled: Bool
    let close: () -> Void
    let canSkipIntro: Bool
    let skipIntro: () -> Void

    func makeCoordinator() -> Coordinator { Coordinator(close: close) }

    func makeUIViewController(context: Context) -> AVPlayerViewController {
        let controller = AVPlayerViewController()
        controller.player = player
        controller.showsPlaybackControls = true
        controller.delegate = context.coordinator
        context.coordinator.playerController = controller
        context.coordinator.isExitEnabled = isExitEnabled
        context.coordinator.skipIntro = skipIntro
        context.coordinator.updateIntroAction(visible: canSkipIntro, controller: controller)
        let menu = UITapGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.menuPressed(_:)))
        menu.allowedPressTypes = [NSNumber(value: UIPress.PressType.menu.rawValue)]
        menu.cancelsTouchesInView = false
        menu.delegate = context.coordinator
        controller.view.addGestureRecognizer(menu)
        context.coordinator.menuRecognizer = menu
        return controller
    }

    func updateUIViewController(_ controller: AVPlayerViewController, context: Context) {
        if controller.player !== player { controller.player = player }
        context.coordinator.close = close
        context.coordinator.isExitEnabled = isExitEnabled
        context.coordinator.skipIntro = skipIntro
        context.coordinator.updateIntroAction(visible: canSkipIntro, controller: controller)
    }

    static func dismantleUIViewController(_ controller: AVPlayerViewController, coordinator: Coordinator) {
        if let menu = coordinator.menuRecognizer { controller.view.removeGestureRecognizer(menu) }
        coordinator.menuRecognizer = nil
        coordinator.playerController = nil
        coordinator.close = {}
        coordinator.skipIntro = {}
        controller.player?.pause()
        controller.player = nil
        controller.delegate = nil
    }

    final class Coordinator: NSObject, @preconcurrency AVPlayerViewControllerDelegate, UIGestureRecognizerDelegate {
        var close: () -> Void
        var isExitEnabled = true
        weak var playerController: AVPlayerViewController?
        var menuRecognizer: UITapGestureRecognizer?
        var skipIntro: () -> Void = {}
        private var hasIntroAction = false
        init(close: @escaping () -> Void) { self.close = close }

        func updateIntroAction(visible: Bool, controller: AVPlayerViewController) {
            guard visible != hasIntroAction else { return }
            hasIntroAction = visible
            controller.transportBarCustomMenuItems = visible ? [UIAction(title: "Пропустить заставку",
                image: UIImage(systemName: "forward.end"), identifier: UIAction.Identifier("torrent-local-skip-intro")) { [weak self] _ in
                    Task { @MainActor [weak self] in self?.skipIntro() }
                }] : []
        }

        @objc func menuPressed(_ recognizer: UITapGestureRecognizer) {
            guard recognizer.state == .ended, isExitEnabled,
                  let playerController, playerController.presentedViewController == nil else { return }
            close()
        }

        func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive press: UIPress) -> Bool {
            press.type == .menu && isExitEnabled && playerController?.viewIfLoaded?.window != nil
                && playerController?.presentedViewController == nil
        }

        func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer,
                               shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool { true }

        func playerViewControllerShouldDismiss(_ playerViewController: AVPlayerViewController) -> Bool { isExitEnabled }

        func playerViewControllerDidEndDismissalTransition(_ playerViewController: AVPlayerViewController) {
            if isExitEnabled { close() }
        }
    }
}

@MainActor
private struct TorrentAVLocalPlayer: View {
    let playback: TorrentLocalPlayback
    @EnvironmentObject private var model: AppModel
    @EnvironmentObject private var downloads: TorrentDownloadsModel
    @Environment(\.dismiss) private var dismiss
    @Environment(\.scenePhase) private var scenePhase
    @StateObject private var controller: TorrentLocalPlaybackController
    @State private var isClosing = false

    init(playback: TorrentLocalPlayback) {
        self.playback = playback
        _controller = StateObject(wrappedValue: TorrentLocalPlaybackController(playback: playback))
    }

    var body: some View {
        ZStack {
            TorrentNativeLocalPlayer(player: controller.player, isExitEnabled: !isClosing, close: close,
                canSkipIntro: controller.canSkipIntro, skipIntro: { controller.skipIntro() })
                .ignoresSafeArea()
            if controller.isWaiting && controller.errorMessage == nil {
                VStack(spacing: 22) {
                    ProgressView("Открываем скачанный фильм…")
                    Text("Можно вернуться кнопкой «Назад»").font(.callout).foregroundStyle(.secondary)
                }.padding(36).asanPanel().allowsHitTesting(false)
                    .accessibilityIdentifier("torrent-local-loading")
            }
            if let message = controller.errorMessage {
                VStack(spacing: 28) {
                    Text("Не удалось открыть фильм").font(.largeTitle.bold())
                    Text(message).font(.title3).multilineTextAlignment(.center).frame(maxWidth: 1000)
                        .accessibilityIdentifier("torrent-local-error")
                    HStack(spacing: 28) {
                        Button("Повторить") { controller.retry() }.accessibilityIdentifier("torrent-local-retry")
                        Button("Назад к загрузкам") { close() }.accessibilityIdentifier("torrent-local-back")
                    }.focusSection()
                }
                .padding(60).frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(.black.opacity(0.95))
                .onExitCommand { close() }
            }
            #if DEBUG && targetEnvironment(simulator)
            TorrentLocalPlaybackMetrics(position: controller.actualPosition, duration: controller.actualDuration,
                firstPlayingPosition: controller.firstPlayingPosition)
            #endif
        }
        .background(.black)
        .accessibilityElement(children: .contain)
        .accessibilityLabel("Плеер скачанного фильма")
        .accessibilityValue(controller.playbackState)
        .accessibilityIdentifier("torrent-local-player")
        .onExitCommand { close() }
        .task {
            controller.start(resumePosition: resolvedResume, introSeconds: introSeconds) { position, duration, force in
                model.enqueueLocalRecord(playback.association, position: position, duration: duration)
                Task { await downloads.updateLocalProgress(id: playback.id, position: position, duration: duration, force: force) }
            }
            controller.updateScenePhase(scenePhase)
        }
        .onChange(of: scenePhase) { phase in controller.updateScenePhase(phase) }
        .onChange(of: introSeconds) { seconds in controller.updateIntroDuration(seconds) }
        .onDisappear { controller.stop() }
    }

    private var resolvedResume: Double {
        guard playback.prefersCanonicalResume, let association = playback.association, association.canRecordProgress,
              let saved = model.library.history.first(where: { $0.reference == association.reference && $0.episodeID == association.episodeID }) else { return playback.resumePosition }
        return saved.isCompleted ? 0 : saved.position
    }
    private var introSeconds: Double {
        guard let association = playback.association, association.media.kind == .series else { return 0 }
        return model.introSkipDuration(for: association.reference)
    }

    private func close() {
        guard !isClosing else { return }
        isClosing = true
        controller.stop()
        dismiss()
    }
}

#if DEBUG && targetEnvironment(simulator)
/// Tests observe real player clocks; these values never drive playback readiness.
@MainActor
struct TorrentLocalPlaybackMetrics: View {
    let position: Double
    let duration: Double
    let firstPlayingPosition: Double?
    var body: some View {
        VStack(spacing: 0) {
            Text(String(format: "%.1f", position)).accessibilityIdentifier("torrent-local-position")
                .accessibilityValue(String(format: "%.1f", position))
            Text(String(format: "%.1f", duration)).accessibilityIdentifier("torrent-local-duration")
                .accessibilityValue(String(format: "%.1f", duration))
            if let firstPlayingPosition {
                Text(String(format: "%.1f", firstPlayingPosition)).accessibilityIdentifier("torrent-local-start-position")
                    .accessibilityValue(String(format: "%.1f", firstPlayingPosition))
            }
        }.font(.system(size: 1)).foregroundStyle(.white).opacity(0.01)
            .frame(width: 1, height: 2).allowsHitTesting(false)
    }
}
#endif

/// AVKit remains the first choice for native containers; VLC supplies local
/// formats that AVPlayer cannot demux. Remote URLs never enter either branch.
@MainActor
struct TorrentLocalPlayer: View {
    let playback: TorrentLocalPlayback

    private var usesVLC: Bool {
        #if DEBUG && targetEnvironment(simulator)
        if PreviewSupport.scene == .torrentVLCPlayer || PreviewSupport.scene?.rawValue == "local-vlc-details" { return true }
        #endif
        return ["mkv", "webm", "avi", "ts"].contains(playback.url.pathExtension.lowercased())
    }

    var body: some View {
        if usesVLC { TorrentVLCPlayer(playback: playback) }
        else { TorrentAVLocalPlayer(playback: playback) }
    }
}
