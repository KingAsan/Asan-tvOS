import SwiftUI
import AVKit
import AVFoundation
import Combine
import OSLog
import UIKit
import KinoCore

@MainActor
final class PlaybackController: ObservableObject {
    let player = AVPlayer()
    @Published private(set) var request: PlaybackRequest
    @Published private(set) var selectedStreamID: String
    @Published private(set) var isWaiting = true
    @Published private(set) var errorMessage: String?
    @Published private(set) var hasEnded = false
    @Published private(set) var isResolvingNext = false
    @Published private(set) var hasStartedPlaying = false
    @Published private(set) var statusText = "Подключаем видео…"
    @Published private(set) var canSkipIntro = false
    @Published var shouldOfferTorrent = false
    private var timeObserver: Any?
    private var statusObservation: NSKeyValueObservation?
    private var waitingObservation: NSKeyValueObservation?
    private var endObserver: NSObjectProtocol?
    private var failureObserver: NSObjectProtocol?
    private var jumpObserver: NSObjectProtocol?
    private var recoveryTask: Task<Void, Never>?
    private var recoveryPolicy = PlaybackRecoveryPolicy()
    private var lastHistorySave = 0.0
    private var introDuration: (PlaybackRequest) -> Double = { _ in 0 }
    private var generation = 0
    private var position = 0.0
    private var duration = 0.0
    private var pendingResume = 0.0
    private var stopped = false
    private var canSaveProgress = false
    private var autoNext: () -> Bool = { false }
    private var save: (PlaybackRequest, Double, Double) -> Void = { _, _, _ in }
    private var resolveNext: (PlaybackRequest) async throws -> PlaybackRequest? = { _ in nil }
    private var refreshCurrent: (PlaybackRequest) async throws -> PlaybackRequest? = { _ in nil }
    private var transitionTask: Task<Void, Never>?
    private var nextFailed = false
    private var didPrepareItem = false
    private var startupTask: Task<Void, Never>?
    private var loadStartedAt = Date()
    private var attemptedURLs = Set<URL>()
    private let logger = Logger(subsystem: "dev.local.KinoHD", category: "Playback")

    init(request: PlaybackRequest) {
        self.request = request
        selectedStreamID = request.initialStreamID
        pendingResume = request.resumePosition
    }

    func start(autoplayNext: @escaping () -> Bool,
               save: @escaping (PlaybackRequest, Double, Double) -> Void,
               resolveNext: @escaping (PlaybackRequest) async throws -> PlaybackRequest?,
               refreshCurrent: @escaping (PlaybackRequest) async throws -> PlaybackRequest?,
               introDuration: @escaping (PlaybackRequest) -> Double = { _ in 0 }) {
        guard player.currentItem == nil else { return }
        stopped = false
        self.autoNext = autoplayNext
        self.save = save
        self.resolveNext = resolveNext
        self.refreshCurrent = refreshCurrent
        self.introDuration = introDuration
        #if DEBUG && targetEnvironment(simulator)
        if PreviewSupport.scene == .player || PreviewSupport.scene == .playerQualities || PreviewSupport.scene == .recovery {
            isWaiting = false
            if PreviewSupport.scene == .recovery { shouldOfferTorrent = true }
            return // Offline UI test of the embedded AVKit Menu/Back path.
        }
        #endif
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .moviePlayback)
            try AVAudioSession.sharedInstance().setActive(true)
        } catch {
            errorMessage = "Не удалось подготовить воспроизведение звука."
            return
        }
        waitingObservation = player.observe(\.timeControlStatus, options: [.initial, .new]) { [weak self] _, _ in
            Task { @MainActor [weak self] in
                guard let self else { return }
                guard !self.stopped else { return }
                self.isWaiting = self.player.timeControlStatus == .waitingToPlayAtSpecifiedRate
                if self.player.timeControlStatus == .playing {
                    if !self.hasStartedPlaying {
                        let elapsed = Date().timeIntervalSince(self.loadStartedAt)
                        self.logger.info("Playback started after \(elapsed, privacy: .public) seconds")
                    }
                    self.hasStartedPlaying = true
                    self.startupTask?.cancel()
                    self.startupTask = nil
                } else if !self.didPrepareItem && self.player.currentItem != nil && self.errorMessage == nil {
                    self.isWaiting = true
                }
                self.observeRecoveryWaiting()
            }
        }
        loadSelectedStream(resume: position > 0 ? position : pendingResume)
    }

    func selectStream(_ id: String) {
        guard (id != selectedStreamID || errorMessage != nil), request.streams.contains(where: { $0.id == id }) else { return }
        if errorMessage == nil, let choice = request.streams.first(where: { $0.id == id }),
           request.isSelectedQuality(choice, selectedID: selectedStreamID) { return }
        saveCurrent()
        selectedStreamID = id
        if let stream = request.streams.first(where: { $0.id == id }) {
            UserDefaults.standard.set(PlaybackVariantPolicy.label(for: stream), forKey: "Asan.preferredQuality")
        }
        loadSelectedStream(resume: currentPosition)
    }

    func retry() {
        if request.rezkaDetails != nil { resolveTransition(next: nextFailed) }
        else { loadSelectedStream(resume: currentPosition) }
    }

    func restart() { loadSelectedStream(resume: 0) }

    func pauseForSelection() -> Bool {
        let wasPlaying = player.timeControlStatus != .paused
        saveCurrent()
        player.pause()
        return wasPlaying
    }

    func resumeAfterSelection(_ resume: Bool) {
        if resume, !stopped, errorMessage == nil, canSaveProgress { player.play() }
    }

    func replaceRequest(_ updated: PlaybackRequest) {
        saveCurrent()
        let offset = request.entry.id == updated.entry.id && request.episode?.id == updated.episode?.id
            ? currentPosition : updated.resumePosition
        adoptRequest(updated)
        selectedStreamID = updated.initialStreamID
        loadSelectedStream(resume: offset)
    }

    var nextEpisode: Episode? {
        guard let episode = request.episode else { return nil }
        let episodes = request.entry.media.seasons.sorted { $0.number < $1.number }
            .flatMap { $0.episodes.sorted { $0.number < $1.number } }
        guard let index = episodes.firstIndex(where: { $0.id == episode.id }), episodes.indices.contains(index + 1) else { return nil }
        return episodes[index + 1]
    }

    private func adoptRequest(_ updated: PlaybackRequest) {
        if request.entry.reference != updated.entry.reference || request.episode?.id != updated.episode?.id {
            recoveryPolicy = PlaybackRecoveryPolicy()
            shouldOfferTorrent = false
        }
        request = updated
    }

    func playNext() {
        guard nextEpisode != nil else { return }
        resolveTransition(next: true)
    }

    private func resolveTransition(next: Bool) {
        guard !isResolvingNext, !stopped else { return }
        saveCurrent()
        player.pause()
        let previous = request.streams.first { $0.id == selectedStreamID }
        let offset = next ? 0 : currentPosition
        let generation = self.generation
        let currentRequest = request
        isResolvingNext = true
        errorMessage = nil
        transitionTask = Task { [weak self] in
            guard let self else { return }
            defer { if self.generation == generation { self.isResolvingNext = false } }
            do {
                let updated: PlaybackRequest?
                if next { updated = try await self.resolveNext(currentRequest) }
                else { updated = try await self.refreshCurrent(currentRequest) }
                try Task.checkCancellation()
                guard self.generation == generation, !self.stopped else { return }
                guard let updated, !updated.streams.isEmpty else {
                    self.nextFailed = next
                    self.errorMessage = next ? "Следующая серия больше недоступна. Вернись к карточке и обнови список серий." : "Сервис не передал новую ссылку. Повтори запрос или вернись к карточке."
                    return
                }
                let selected = previous.flatMap { PlaybackVariantPolicy.equivalent(to: $0, in: updated.streams) }
                self.adoptRequest(updated)
                guard let selected else {
                    self.generation += 1
                    self.transitionTask = nil
                    self.isResolvingNext = false
                    self.selectedStreamID = ""
                    self.position = offset
                    self.pendingResume = offset
                    self.player.replaceCurrentItem(with: nil)
                    self.clearItemObservers()
                    self.canSaveProgress = false
                    self.isWaiting = false
                    self.errorMessage = "Прежнее качество больше недоступно. Выбери другое качество видео."
                    return
                }
                self.selectedStreamID = selected.id
                self.transitionTask = nil
                self.isResolvingNext = false
                self.nextFailed = false
                self.loadSelectedStream(resume: offset)
            } catch is CancellationError { }
            catch {
                guard self.generation == generation else { return }
                self.nextFailed = next
                self.errorMessage = next ? "Не удалось получить следующую серию. Повтори запрос или вернись к карточке." : "Не удалось обновить ссылку на видео. Проверь подключение и аккаунт Rezka."
            }
        }
    }

    func stop() {
        guard !stopped else { return }
        stopped = true
        transitionTask?.cancel()
        recoveryTask?.cancel()
        recoveryTask = nil
        startupTask?.cancel()
        startupTask = nil
        transitionTask = nil
        isResolvingNext = false
        generation += 1
        saveCurrent()
        position = currentPosition
        player.pause()
        clearItemObservers()
        canSaveProgress = false
        canSkipIntro = false
        didPrepareItem = false
        hasStartedPlaying = false
        waitingObservation?.invalidate()
        waitingObservation = nil
        player.replaceCurrentItem(with: nil)
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
    }

    func saveCurrent() {
        guard canSaveProgress else { return }
        let now = currentPosition
        let total = player.currentItem?.duration.seconds ?? duration
        save(request, now, total.isFinite && total > 0 ? total : duration)
    }

    private var currentPosition: Double {
        let time = player.currentTime().seconds
        return canSaveProgress && time.isFinite && time >= 0 ? time : position
    }

    private func observe(_ time: CMTime) {
        guard !stopped, canSaveProgress, time.seconds.isFinite else { return }
        position = max(0, time.seconds)
        let total = player.currentItem?.duration.seconds ?? 0
        duration = total.isFinite && total > 0 ? total : 0
        updateIntroAvailability()
        let now = ProcessInfo.processInfo.systemUptime
        if now - lastHistorySave >= 10 { lastHistorySave = now; save(request, position, duration) }
    }

    func skipIntro() {
        guard canSaveProgress, let target = IntroPlaybackPolicy.target(position: currentPosition,
            duration: player.currentItem?.duration.seconds ?? duration, introSeconds: introDuration(request)) else { return }
        recoveryPolicy.suppressForSeek(at: ProcessInfo.processInfo.systemUptime)
        let expected = generation
        canSaveProgress = false
        player.seek(to: CMTime(seconds: target, preferredTimescale: 600), toleranceBefore: .zero, toleranceAfter: .zero) { [weak self] done in
            Task { @MainActor [weak self] in
                guard let self, self.generation == expected, !self.stopped else { return }
                self.canSaveProgress = true
                if done { self.position = target; self.saveCurrent() }
                self.updateIntroAvailability()
            }
        }
    }

    private func updateIntroAvailability() {
        let available = request.entry.media.kind == .series && canSaveProgress && IntroPlaybackPolicy.target(
            position: currentPosition, duration: player.currentItem?.duration.seconds ?? duration,
            introSeconds: introDuration(request)) != nil
        if canSkipIntro != available { canSkipIntro = available }
    }

    private func observeRecoveryWaiting() {
        recoveryTask?.cancel()
        recoveryTask = nil
        let waiting = isWaiting && errorMessage == nil && request.rezkaDetails != nil
        let now = ProcessInfo.processInfo.systemUptime
        if recoveryPolicy.observe(isWaiting: waiting, hasStarted: hasStartedPlaying, at: now) { shouldOfferTorrent = true }
        guard waiting, hasStartedPlaying, !recoveryPolicy.hasOffered else { return }
        let expected = generation
        recoveryTask = Task { [weak self] in
            do { try await Task.sleep(for: .milliseconds(3100)) } catch { return }
            guard let self, self.generation == expected, !self.stopped,
                  self.player.timeControlStatus == .waitingToPlayAtSpecifiedRate, self.errorMessage == nil else { return }
            if self.recoveryPolicy.observe(isWaiting: true, hasStarted: self.hasStartedPlaying,
                at: ProcessInfo.processInfo.systemUptime) { self.shouldOfferTorrent = true }
        }
    }

    private func tryAlternative() -> Bool {
        guard !stopped, let current = request.streams.first(where: { $0.id == selectedStreamID }),
              let alternative = PlaybackVariantPolicy.nextAlternative(for: current, in: request.streams,
                  attemptedURLs: attemptedURLs) else { return false }
        let offset = currentPosition
        saveCurrent()
        selectedStreamID = alternative.id
        loadSelectedStream(resume: offset, resetCandidates: false)
        statusText = "Пробуем резервное подключение…"
        return true
    }

    private func loadSelectedStream(resume: Double, resetCandidates: Bool = true) {
        guard !stopped else {
            position = resume.isFinite ? max(0, resume) : 0
            pendingResume = position
            return
        }
        generation += 1
        transitionTask?.cancel()
        transitionTask = nil
        isResolvingNext = false
        let loadGeneration = generation
        player.pause()
        clearItemObservers()
        canSaveProgress = false
        canSkipIntro = false
        didPrepareItem = false
        hasStartedPlaying = false
        loadStartedAt = Date()
        statusText = resume > 0 ? "Продолжаем просмотр…" : "Подключаем видео…"
        guard let stream = request.streams.first(where: { $0.id == selectedStreamID }),
              CatalogClient.isSecureURL(stream.url) else {
            errorMessage = "Этот источник не передал подходящую HTTPS-ссылку."
            return
        }
        if resetCandidates { attemptedURLs.removeAll() }
        attemptedURLs.insert(stream.url)
        position = resume.isFinite ? max(0, resume) : 0
        duration = 0
        pendingResume = position
        errorMessage = nil
        hasEnded = false
        isWaiting = true
        let item = AVPlayerItem(url: stream.url)
        let interval = CMTime(seconds: 1, preferredTimescale: 600)
        timeObserver = player.addPeriodicTimeObserver(forInterval: interval, queue: .main) { [weak self] time in
            Task { @MainActor [weak self] in
                guard let self, self.generation == loadGeneration else { return }
                self.observe(time)
            }
        }
        statusObservation = item.observe(\.status, options: [.initial, .new]) { [weak self] item, _ in
            Task { @MainActor [weak self] in
                guard let self, self.generation == loadGeneration else { return }
                if item.status == .readyToPlay {
                    guard !self.didPrepareItem else { return }
                    self.didPrepareItem = true
                    let total = item.duration.seconds
                    let seek = total.isFinite && total > 0 ? min(self.pendingResume, max(0, total - 2)) : self.pendingResume
                    self.pendingResume = 0
                    if seek > 0 {
                        let tolerance = CMTime(seconds: 1, preferredTimescale: 600)
                        self.player.seek(to: CMTime(seconds: seek, preferredTimescale: 600), toleranceBefore: tolerance, toleranceAfter: tolerance) { [weak self] completed in
                            Task { @MainActor [weak self] in
                                guard let self, self.generation == loadGeneration, !self.stopped else { return }
                                guard completed else {
                                    self.startupTask?.cancel()
                                    self.isWaiting = false
                                    self.errorMessage = "Не удалось продолжить с сохранённого места. Попробуй повторить или начать фильм сначала."
                                    return
                                }
                                self.canSaveProgress = true
                                self.updateIntroAvailability()
                                self.player.play()
                            }
                        }
                    } else {
                        self.canSaveProgress = true
                        self.updateIntroAvailability()
                        self.player.play()
                    }
                } else if item.status == .failed {
                    if self.tryAlternative() { return }
                    self.startupTask?.cancel()
                    self.isWaiting = false
                    self.logger.error("Player item failed, code \((item.error as NSError?)?.code ?? 0, privacy: .public)")
                    self.errorMessage = "Не удалось открыть видео. Повтори запрос, выбери другое качество или другую озвучку."
                }
            }
        }
        endObserver = NotificationCenter.default.addObserver(forName: .AVPlayerItemDidPlayToEndTime, object: item, queue: .main) { [weak self] _ in
            Task { @MainActor [weak self] in
                guard let self, self.generation == loadGeneration else { return }
                self.hasEnded = true
                self.isWaiting = false
                self.startupTask?.cancel()
                self.saveCurrent()
                if self.autoNext(), self.nextEpisode != nil { self.playNext() }
            }
        }
        failureObserver = NotificationCenter.default.addObserver(forName: .AVPlayerItemFailedToPlayToEndTime, object: item, queue: .main) { [weak self] _ in
            Task { @MainActor [weak self] in
                guard let self, self.generation == loadGeneration else { return }
                if self.tryAlternative() { return }
                self.isWaiting = false
                self.saveCurrent()
                self.errorMessage = "Воспроизведение прервано. Проверь сеть или выбери другой источник."
            }
        }
        jumpObserver = NotificationCenter.default.addObserver(forName: .AVPlayerItemTimeJumped, object: item, queue: .main) { [weak self] _ in
            Task { @MainActor [weak self] in
                guard let self, self.generation == loadGeneration, !self.stopped else { return }
                self.recoveryPolicy.suppressForSeek(at: ProcessInfo.processInfo.systemUptime)
                self.updateIntroAvailability()
            }
        }
        player.replaceCurrentItem(with: item)
        startupTask = Task { @MainActor [weak self] in
            do { try await Task.sleep(for: .seconds(45)) } catch { return }
            guard let self, self.generation == loadGeneration, !self.stopped, !self.hasStartedPlaying else { return }
            if self.tryAlternative() { return }
            self.generation += 1
            self.player.pause()
            self.clearItemObservers()
            self.canSaveProgress = false
            self.isWaiting = false
            self.errorMessage = "Видео не ответило вовремя. Повтори запрос или выбери другое качество."
            self.logger.error("Playback startup timed out")
        }
    }

    private func clearItemObservers() {
        recoveryTask?.cancel()
        recoveryTask = nil
        startupTask?.cancel()
        startupTask = nil
        if let timeObserver { player.removeTimeObserver(timeObserver) }
        timeObserver = nil
        statusObservation?.invalidate()
        statusObservation = nil
        if let endObserver { NotificationCenter.default.removeObserver(endObserver) }
        if let failureObserver { NotificationCenter.default.removeObserver(failureObserver) }
        if let jumpObserver { NotificationCenter.default.removeObserver(jumpObserver) }
        jumpObserver = nil
        endObserver = nil
        failureObserver = nil
    }
}

@MainActor
struct NativePlayerView: UIViewControllerRepresentable {
    let player: AVPlayer
    let streams: [StreamVariant]
    let selectedStreamID: String
    let menuKey: String
    let isExitEnabled: Bool
    let chooseStream: (String) -> Void
    let chooseVoice: (() -> Void)?
    let playNext: (() -> Void)?
    var skipIntro: (() -> Void)? = nil
    var findTorrent: (() -> Void)? = nil
    let close: () -> Void

    func makeCoordinator() -> Coordinator { Coordinator(close: close) }

    func makeUIViewController(context: Context) -> AVPlayerViewController {
        let controller = AVPlayerViewController()
        controller.player = player
        controller.delegate = context.coordinator
        controller.showsPlaybackControls = true
        context.coordinator.playerController = controller
        context.coordinator.isExitEnabled = isExitEnabled
        let menuPress = UITapGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.menuPressed(_:)))
        menuPress.allowedPressTypes = [NSNumber(value: UIPress.PressType.menu.rawValue)]
        menuPress.cancelsTouchesInView = false
        menuPress.delegate = context.coordinator
        controller.view.addGestureRecognizer(menuPress)
        context.coordinator.menuRecognizer = menuPress
        configureMenus(controller, coordinator: context.coordinator)
        return controller
    }

    func updateUIViewController(_ controller: AVPlayerViewController, context: Context) {
        if controller.player !== player { controller.player = player }
        context.coordinator.close = close
        context.coordinator.isExitEnabled = isExitEnabled
        if context.coordinator.menuKey != menuKey { configureMenus(controller, coordinator: context.coordinator) }
    }

    private func configureMenus(_ controller: AVPlayerViewController, coordinator: Coordinator) {
        coordinator.menuKey = menuKey
        let selected = streams.first { $0.id == selectedStreamID }
        let choices = PlaybackVariantPolicy.choices(streams).map { stream in
            UIAction(title: PlaybackVariantPolicy.label(for: stream), state: selected.map { PlaybackVariantPolicy.sameChoice($0, stream) } == true ? .on : .off) { _ in
                chooseStream(stream.id)
            }
        }
        var menus: [UIMenuElement] = [UIMenu(title: "Качество", image: UIImage(systemName: "slider.horizontal.3"), children: choices)]
        if let chooseVoice {
            menus.append(UIAction(title: "Озвучка", image: UIImage(systemName: "waveform")) { _ in chooseVoice() })
        }
        if let playNext {
            menus.append(UIAction(title: "Следующая серия", image: UIImage(systemName: "forward.end")) { _ in playNext() })
        }
        if let skipIntro {
            menus.append(UIAction(title: "Пропустить заставку", image: UIImage(systemName: "forward.frame")) { _ in skipIntro() })
        }
        if let findTorrent {
            menus.append(UIAction(title: "Найти торрент", image: UIImage(systemName: "arrow.down.circle")) { _ in findTorrent() })
        }
        controller.transportBarCustomMenuItems = menus
    }

    static func dismantleUIViewController(_ controller: AVPlayerViewController, coordinator: Coordinator) {
        if let recognizer = coordinator.menuRecognizer { controller.view.removeGestureRecognizer(recognizer) }
        coordinator.menuRecognizer = nil
        coordinator.playerController = nil
        coordinator.close = {}
        controller.player = nil
        controller.delegate = nil
    }

    final class Coordinator: NSObject, @preconcurrency AVPlayerViewControllerDelegate, UIGestureRecognizerDelegate {
        var close: () -> Void
        var menuKey = ""
        var isExitEnabled = true
        weak var playerController: AVPlayerViewController?
        var menuRecognizer: UITapGestureRecognizer?
        init(close: @escaping () -> Void) { self.close = close }
        // An embedded AVPlayerViewController does not own the SwiftUI cover.
        // Handle only Back/Menu here; Select, seeking and Play/Pause stay native.
        @objc func menuPressed(_ recognizer: UITapGestureRecognizer) {
            guard recognizer.state == .ended, isExitEnabled,
                  let playerController, playerController.presentedViewController == nil else { return }
            close()
        }
        func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive press: UIPress) -> Bool {
            press.type == .menu && isExitEnabled && playerController?.viewIfLoaded?.window != nil
                && playerController?.presentedViewController == nil
        }
        func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer,
                               shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool { true }
        func playerViewControllerShouldDismiss(_ playerViewController: AVPlayerViewController) -> Bool { isExitEnabled }
        func playerViewControllerDidEndDismissalTransition(_ playerViewController: AVPlayerViewController) {
            if isExitEnabled { close() }
        }
    }
}

@MainActor
struct PlaybackScreen: View {
    @EnvironmentObject private var model: AppModel
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @StateObject private var controller: PlaybackController
    @State private var showChoices = false
    @State private var showVoices = false
    @State private var titleVisible = false
    @State private var pendingChoice: PlaybackChoice?
    @State private var choiceError: String?
    @State private var resumeAfterVoices = false
    @State private var isClosing = false
    @State private var resumeAfterRecoveryOffer = false
    private let presentationID: UUID

    init(request: PlaybackRequest) {
        presentationID = request.id
        _controller = StateObject(wrappedValue: PlaybackController(request: request))
    }

    var body: some View {
        ZStack(alignment: .topLeading) {
            NativePlayerView(player: controller.player, streams: controller.request.streams,
                selectedStreamID: controller.selectedStreamID,
                menuKey: controller.request.id.uuidString + controller.selectedStreamID + String(controller.canSkipIntro),
                isExitEnabled: !showChoices && !showVoices && !controller.shouldOfferTorrent && !isClosing,
                chooseStream: { controller.selectStream($0) },
                chooseVoice: controller.request.rezkaDetails == nil ? nil : { openVoices() },
                playNext: controller.nextEpisode == nil ? nil : { controller.playNext() },
                skipIntro: controller.canSkipIntro ? { controller.skipIntro() } : nil,
                findTorrent: controller.request.rezkaDetails == nil ? nil : { openTorrentAlternative() },
                close: { closePlayback() }).ignoresSafeArea()
            if titleVisible {
                Text(controller.request.title).font(.headline).lineLimit(2)
                    .padding(22).background(.black.opacity(0.65), in: RoundedRectangle(cornerRadius: 12))
                    .padding(44).allowsHitTesting(false).transition(.opacity)
            }
            if (controller.isWaiting || controller.isResolvingNext) && controller.errorMessage == nil {
                VStack(spacing: 20) {
                    ProgressView()
                    Text(controller.isResolvingNext ? "Обновляем видео…" : controller.statusText).font(.title3)
                    Text("Можно вернуться кнопкой «Назад»").font(.callout).foregroundStyle(.secondary)
                }.padding(36).asanPanel().frame(maxWidth: .infinity, maxHeight: .infinity)
                    .allowsHitTesting(false).transition(.opacity)
            }
            if let error = choiceError ?? controller.errorMessage {
                playerMessage(title: "Не удалось продолжить просмотр", message: error) {
                    Button("Повторить") { choiceError = nil; controller.retry() }
                    Button("Сначала") { choiceError = nil; controller.restart() }
                    Button("Другое качество") { showChoices = true }
                    if controller.request.rezkaDetails != nil { Button("Озвучки") { openVoices() } }
                    if controller.request.rezkaDetails != nil { Button("Торрент") { openTorrentAlternative() } }
                    Button("Назад к фильму") { closePlayback() }
                }
            } else if controller.hasEnded && !controller.isResolvingNext {
                playerMessage(title: "Просмотр завершён", message: controller.request.title) {
                    if controller.nextEpisode != nil { Button("Следующая серия") { controller.playNext() } }
                    Button("Смотреть заново") { controller.restart() }
                    Button("Назад к фильму") { closePlayback() }
                }
            }
        }
        .background(.black)
        .accessibilityElement(children: .contain)
        .accessibilityLabel("Видеоплеер")
        .accessibilityIdentifier("playback-screen")
        .onExitCommand {
            if controller.shouldOfferTorrent { controller.shouldOfferTorrent = false }
            else if showChoices { showChoices = false }
            else if showVoices { showVoices = false }
            else { closePlayback() }
        }
        .task {
            controller.start(autoplayNext: { model.autoplayNext }, save: { request, position, duration in
                model.enqueueRecord(request, position: position, duration: duration)
            }, resolveNext: { try await model.nextPlayback(after: $0) },
               refreshCurrent: { try await model.refreshPlayback($0) },
               introDuration: { model.introSkipDuration(for: $0.entry.reference) })
            #if DEBUG && targetEnvironment(simulator)
            if PreviewSupport.scene == .playerQualities { showChoices = true }
            #endif
        }
        .task(id: controller.hasStartedPlaying) {
            titleVisible = controller.hasStartedPlaying
            guard controller.hasStartedPlaying else { return }
            do { try await Task.sleep(for: .seconds(5)) } catch { return }
            withAnimation(reduceMotion || AsanEffects.isPreviewReduced ? nil : .easeOut(duration: 0.2)) { titleVisible = false }
        }
        .onDisappear { if !showChoices && !showVoices { controller.stop() } }
        .onChange(of: scenePhase) { phase in if phase != .active { controller.saveCurrent() } }
        .onChange(of: controller.shouldOfferTorrent) { _, offered in
            if offered { resumeAfterRecoveryOffer = controller.pauseForSelection() }
            else if !isClosing { controller.resumeAfterSelection(resumeAfterRecoveryOffer) }
        }
        .alert("Видео часто останавливается", isPresented: $controller.shouldOfferTorrent) {
            Button("Найти торрент") { openTorrentAlternative() }
            Button("Продолжить просмотр", role: .cancel) { }
        } message: {
            Text("Можно найти раздачу этого фильма или серии. Позиция просмотра сохранится; скачивание начнётся после твоего выбора.")
        }
        .sheet(isPresented: $showChoices) {
            NavigationStack {
                List(controller.request.qualityChoices) { stream in
                    Button {
                        choiceError = nil
                        controller.selectStream(stream.id)
                        showChoices = false
                    } label: {
                        HStack {
                            Text(PlaybackVariantPolicy.label(for: stream)).font(.title3)
                            Spacer()
                            if controller.request.isSelectedQuality(stream, selectedID: controller.selectedStreamID) { Image(systemName: "checkmark") }
                        }.padding(.vertical, 12)
                    }.accessibilityIdentifier("quality-option-\(stream.id)")
                }
                .navigationTitle("Качество")
                .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Назад") { showChoices = false } } }
            }
        }
        .sheet(isPresented: $showVoices, onDismiss: applyVoiceChoice) {
            if let details = controller.request.rezkaDetails {
                PlaybackOptionsScreen(details: details, fromStart: false, preferredEpisodeID: controller.request.episode?.id) { choice in
                    pendingChoice = choice
                    showVoices = false
                }.environmentObject(model)
            }
        }
    }

    private func openVoices() {
        resumeAfterVoices = controller.pauseForSelection()
        showVoices = true
    }

    private func openTorrentAlternative() {
        guard !isClosing else { return }
        isClosing = true
        controller.stop()
        model.requestTorrentAlternative(for: controller.request, presentationID: presentationID)
    }

    private func closePlayback() {
        guard !isClosing else { return }
        isClosing = true
        controller.stop()
        // Clear the actual fullScreenCover binding, not the embedded UIKit VC.
        // An old callback must never dismiss a newer playback presentation.
        if model.playback?.id == presentationID { model.playback = nil }
    }

    private func applyVoiceChoice() {
        guard let choice = pendingChoice else { controller.resumeAfterSelection(resumeAfterVoices); return }
        pendingChoice = nil
        do {
            let request = try model.validatedPlayback(choice.prepared, streamID: choice.streamID)
            choiceError = nil
            controller.replaceRequest(request)
        } catch { choiceError = model.friendly(error) }
    }

    private func playerMessage<Actions: View>(title: String, message: String, @ViewBuilder actions: () -> Actions) -> some View {
        VStack(spacing: 28) {
            Text(title).font(.largeTitle.bold())
            Text(message).font(.title3).multilineTextAlignment(.center).frame(maxWidth: 1000)
            HStack(spacing: 25) { actions() }
        }.padding(60).frame(maxWidth: .infinity, maxHeight: .infinity).background(.black.opacity(0.93))
            .onExitCommand { closePlayback() }
    }
}
