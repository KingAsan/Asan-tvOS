#if DEBUG && targetEnvironment(simulator)
import Foundation
import SwiftUI
import Combine
import KinoCore
import RezkaKit

/// Process-local evidence of actual AVFoundation callbacks. It outlives the
/// short intro view, but is never persisted or used to control playback.
@MainActor
final class PreviewIntroPlaybackProbe: ObservableObject {
    let sessionID = UUID().uuidString
    @Published private(set) var starts = 0
    @Published private(set) var sawFrame = false
    @Published private(set) var sawPlaying = false
    @Published private(set) var naturalEnds = 0
    @Published private(set) var finishReason: String?

    func recordStart() { starts += 1 }
    func recordFrame() { if !sawFrame { sawFrame = true } }
    func recordPlaying() { if !sawPlaying { sawPlaying = true } }
    func recordNaturalEnd() { naturalEnds += 1 }
    func recordFinish(_ reason: String) { if finishReason == nil { finishReason = reason } }

    var evidence: String {
        "session=\(sessionID);starts=\(starts);frame=\(sawFrame ? 1 : 0);playing=\(sawPlaying ? 1 : 0);naturalEnd=\(naturalEnds);finish=\(finishReason ?? "pending")"
    }
}

@MainActor
struct PreviewIntroPlaybackProof: View {
    @ObservedObject var probe: PreviewIntroPlaybackProbe
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("QA · Actual intro playback events").font(.system(size: 12, weight: .semibold))
            Text(probe.evidence).font(.system(size: 12, design: .monospaced)).lineLimit(2)
        }
        .foregroundStyle(.white).frame(maxWidth: 650, alignment: .leading)
        .padding(12).background(.black.opacity(0.85), in: RoundedRectangle(cornerRadius: 10))
        .padding(20).allowsHitTesting(false)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("Фактические события заставки")
        .accessibilityValue(probe.evidence)
        .accessibilityIdentifier("asan-intro-playback-proof")
    }
}

/// Read-only evidence from inside actual NavigationLink labels. This object
/// never chooses a target, changes FocusState or accepts commands from a test.
@MainActor
final class PreviewCatalogFocusProbe: ObservableObject {
    let sessionID = UUID().uuidString
    @Published private(set) var revision = 0
    private var observations: [UUID: PreviewPosterFocusObservation] = [:]
    private var activeOwnerIDs: Set<UUID> = []
    private var focusedOwnerID: UUID?

    func register(ownerID: UUID) { activeOwnerIDs.insert(ownerID) }

    func record(ownerID: UUID, observation: PreviewPosterFocusObservation) {
        guard PreviewSupport.observesNativeCatalogFocus, activeOwnerIDs.contains(ownerID) else { return }
        guard observation.hasValidFrame else { discardObservation(ownerID: ownerID); return }
        let previous = observations[ownerID]
        guard previous != observation else { return }
        observations[ownerID] = observation
        // A former label's layout update cannot overtake a newer focus gain.
        if observation.isFocused && previous?.isFocused != true { focusedOwnerID = ownerID }
        else if !observation.isFocused && focusedOwnerID == ownerID { focusedOwnerID = nil }
        revision += 1
    }

    func remove(ownerID: UUID) {
        activeOwnerIDs.remove(ownerID)
        discardObservation(ownerID: ownerID)
    }

    private func discardObservation(ownerID: UUID) {
        guard observations.removeValue(forKey: ownerID) != nil else { return }
        // Losing the old label must not clear a newer label's focus event.
        if focusedOwnerID == ownerID { focusedOwnerID = nil }
        revision += 1
    }

    func clear() {
        guard !observations.isEmpty || focusedOwnerID != nil else { return }
        observations.removeAll()
        focusedOwnerID = nil
        revision += 1
    }

    var evidence: String {
        var payload: [String: Any] = ["session": sessionID, "revision": revision,
                                     "registeredLabels": activeOwnerIDs.count, "observedLabels": observations.count,
                                     "focusedLabels": observations.values.filter(\.isFocused).map {
                                         ["id": $0.cardID, "grid": $0.gridID.uuidString, "layoutFrame": $0.coordinates] as [String: Any]
                                     },
                                     "focus": NSNull(), "layouts": [String: [Double]]()]
        if let owner = focusedOwnerID, let focus = observations[owner], focus.isFocused {
            payload["focus"] = ["id": focus.cardID, "grid": focus.gridID.uuidString,
                                "layoutFrame": focus.coordinates]
            var layouts: [String: [Double]] = [:]
            for observation in observations.values where observation.gridID == focus.gridID {
                layouts[observation.cardID] = observation.coordinates
            }
            payload["layouts"] = layouts
        }
        guard let data = try? JSONSerialization.data(withJSONObject: payload, options: [.sortedKeys]),
              let value = String(data: data, encoding: .utf8) else { return "{}" }
        return value
    }
}

struct PreviewPosterFocusObservation: Equatable {
    let gridID: UUID
    let cardID: String
    let layoutFrame: CGRect
    let isFocused: Bool

    var coordinates: [Double] {
        [Double(layoutFrame.minX), Double(layoutFrame.minY),
         Double(layoutFrame.width), Double(layoutFrame.height)]
    }
    var hasValidFrame: Bool { !layoutFrame.isEmpty && coordinates.allSatisfy(\.isFinite) }
}

/// A background measures its existing label without adding another focusable
/// view or participating in the grid's layout. isFocused belongs to the nearest
/// native focusable ancestor: the NavigationLink containing this label.
@MainActor
struct PreviewPosterFocusObserver: View {
    let gridID: UUID
    let cardID: String
    @Environment(\.isFocused) private var isFocused
    @Environment(\.scenePhase) private var scenePhase
    @EnvironmentObject private var probe: PreviewCatalogFocusProbe
    @State private var ownerID = UUID()

    var body: some View {
        GeometryReader { geometry in
            let observation = PreviewPosterFocusObservation(gridID: gridID, cardID: cardID,
                layoutFrame: geometry.frame(in: .global), isFocused: isFocused && scenePhase == .active)
            Color.clear
                .onAppear {
                    probe.register(ownerID: ownerID)
                    probe.record(ownerID: ownerID, observation: observation)
                }
                .onChange(of: observation, initial: true) { _, value in
                    probe.record(ownerID: ownerID, observation: value)
                }
                .onDisappear { probe.remove(ownerID: ownerID) }
        }
        .allowsHitTesting(false).accessibilityHidden(true)
    }
}

/// Keep the evidence outside the native TabView's sometimes stale AX subtree.
/// Its small visible mark does not cover a control or receive remote focus.
@MainActor
struct PreviewCatalogFocusProof: View {
    @ObservedObject var probe: PreviewCatalogFocusProbe
    var body: some View {
        Text("QA \(probe.revision)").font(.system(size: 2)).foregroundStyle(.white)
            .frame(width: 2, height: 2).clipped().padding(2)
            .allowsHitTesting(false)
            .accessibilityElement(children: .ignore)
            .accessibilityLabel("Фактический фокус каталога")
            .accessibilityValue(probe.evidence)
            .accessibilityIdentifier("asan-catalog-focus-proof")
    }
}

/// Offline, fictional fixtures for native Simulator screenshots only. This file
/// contributes no code or account state to a Release/device build.
enum PreviewSupport {
    enum Scene: String {
        case guest, catalog, details, voices, qualities, settings, login, stress, player, restoring, downloads, search
        case torrentList = "torrent-list"
        case torrentPlayer = "torrent-player"
        case torrentVLCPlayer = "torrent-vlc-player"
        case playerQualities = "player-qualities"
        case torrentSearch = "torrent-search"
        case torrentSearchEmpty = "torrent-search-empty"
        case torrentSearchError = "torrent-search-error"
        case intro
        case localDetails = "local-details"
        case localVLCDetails = "local-vlc-details"
        case introSettings = "intro-settings"
        case recovery
        case libraryStates = "library-states"
    }

    static let scene: Scene? = {
        let arguments = ProcessInfo.processInfo.arguments
        guard let index = arguments.firstIndex(of: "--screenshot-scene"),
              arguments.indices.contains(index + 1) else { return nil }
        return Scene(rawValue: arguments[index + 1])
    }()

    static var observesNativeCatalogFocus: Bool {
        scene != nil && ProcessInfo.processInfo.arguments.contains("--qa-observe-native-focus")
    }

    static var isSyntheticCatalog: Bool {
        guard let scene else { return false }
        return [Scene.catalog, .details, .voices, .qualities, .stress, .player, .playerQualities, .restoring,
                .torrentSearch, .torrentSearchEmpty, .torrentSearchError, .intro,
                .localDetails, .localVLCDetails, .introSettings, .recovery, .libraryStates, .search].contains(scene)
    }

    static let qualityStreams: [StreamVariant] = [1080, 720, 480, 360].flatMap { height in
        ["mp4", "m3u8"].map { format in
            StreamVariant(id: "preview-\(height)-\(format)", title: "Демонстрационная озвучка",
                url: URL(string: "https://preview.example.invalid/\(height).\(format)")!, quality: "\(height)p")
        }
    }
    static let demoTitle = "Демонстрационный каталог"

    static let items: [MediaItem] = {
        let base = [
            MediaItem(id: "/series/drama/900001-severnaya-liniya.html", title: "Северная линия", kind: .series,
                      originalTitle: "Northern Line", year: 2026,
                      overview: "Небольшая станция за полярным кругом перестаёт выходить на связь. Новая смена отправляется на север и находит следы путешествия, которого ещё не было. Вымышленный сериал для демонстрации интерфейса.",
                      genres: ["Детектив", "Драма", "Приключения"], rating: 8.4,
                      durationMinutes: 48, seasons: seriesSeasons),
            MediaItem(id: "/films/drama/900002-gorod-posle-polunochi.html", title: "Город после полуночи", kind: .movie,
                      year: 2025, overview: "Один вечер, один незнакомый город и восемь случайных встреч. Демонстрационная карточка.",
                      genres: ["Драма", "Триллер"], rating: 8.1, durationMinutes: 112),
            MediaItem(id: "/films/adventures/900003-posledniy-mayak.html", title: "Последний маяк", kind: .movie,
                      year: 2026, overview: "Смотритель отдалённого маяка замечает свет там, где на карте заканчивается берег. Демонстрационная карточка.",
                      genres: ["Приключения"], rating: 7.9, durationMinutes: 104),
            MediaItem(id: "/films/fiction/900004-po-tu-storonu-orbity.html", title: "По ту сторону орбиты", kind: .movie,
                      year: 2025, overview: "Экипаж исследовательской станции получает послание из собственного будущего. Демонстрационная карточка.",
                      genres: ["Фантастика"], rating: 8.6, durationMinutes: 126),
            MediaItem(id: "/films/adventures/900005-karta-tihogo-morya.html", title: "Карта тихого моря", kind: .movie,
                      year: 2024, overview: "Старая карта помогает двум друзьям найти давно потерянный маршрут. Демонстрационная карточка.",
                      genres: ["Приключения", "Семейный"], rating: 7.6, durationMinutes: 98),
            MediaItem(id: "/films/thriller/900006-zavtra-v-0417.html", title: "Завтра в 04:17", kind: .movie,
                      year: 2026, overview: "Все часы в городе показывают одно и то же время. Демонстрационная карточка.",
                      genres: ["Триллер", "Фантастика"], rating: 8.0, durationMinutes: 109),
            MediaItem(id: "/films/family/900007-leto-na-drugoy-planete.html", title: "Лето на другой планете", kind: .movie,
                      year: 2025, overview: "Необычные летние каникулы начинаются с забытых дверей обсерватории. Демонстрационная карточка.",
                      genres: ["Семейный", "Фантастика"], rating: 7.8, durationMinutes: 102),
            MediaItem(id: "/films/drama/900008-nochnaya-smena-vetra.html", title: "Ночная смена ветра", kind: .movie,
                      year: 2024, overview: "Последний рейс ночного поезда меняет планы его пассажиров. Демонстрационная карточка.",
                      genres: ["Драма"], rating: 8.2, durationMinutes: 117),
            MediaItem(id: "/films/fiction/900009-long-title.html",
                      title: "Очень длинное название фильма, которое должно аккуратно помещаться в две строки и не перекрывать соседние карточки",
                      kind: .movie, year: 2026, genres: ["Научная фантастика", "Драма", "Комедия"], rating: 7.4),
            MediaItem(id: "/films/drama/900010-unrated.html", title: "Без оценки и года", kind: .movie)
        ]
        guard scene == .stress else { return base }
        return (0..<240).map { index in
            var item = base[index % base.count]
            item.id = "/films/drama/\(910000 + index)-stress.html"
            item.title += " · \(index + 1)"
            return item
        }
    }()

    private static var seriesSeasons: [Season] {
        (1...2).map { season in
            Season(id: "900001:s\(season)", title: "Сезон \(season)", number: season,
                   episodes: (1...3).map { episode in
                       Episode(id: "900001:s\(season):e\(episode)", title: ["За северной чертой", "Сигнал", "Обратный путь"][episode - 1],
                               number: episode, overview: "Демонстрационная серия. Видео и сетевые ссылки отсутствуют.", durationMinutes: 48)
                   })
        }
    }

    static func details(for item: MediaItem) -> RezkaDetails {
        let origin = URL(string: "https://preview.example.invalid/")!
        let pageURL = URL(string: item.id, relativeTo: origin)!.absoluteURL
        return RezkaDetails(item: RezkaItem(media: item, pageURL: pageURL), translators: [
            RezkaTranslator(id: "1", title: "Русская озвучка", isSelected: true),
            RezkaTranslator(id: "2", title: "Профессиональная многоголосая озвучка — демонстрационная студия"),
            RezkaTranslator(id: "3", title: "Авторский перевод с оригинальной звуковой дорожкой"),
            RezkaTranslator(id: "4", title: "Оригинал с субтитрами")
        ], selectedTranslatorID: "1", isAvailable: true)
    }
}

/// Original geometric illustrations, drawn by SwiftUI without external images.
struct PreviewPosterArtwork: View {
    let item: MediaItem
    var showsTitle = true

    private var index: Int { PreviewSupport.items.firstIndex(where: { $0.id == item.id }) ?? 0 }
    private var colors: [Color] {
        switch index % 4 {
        case 0: return [Color(red: 0.02, green: 0.11, blue: 0.18), Color(red: 0.06, green: 0.57, blue: 0.59)]
        case 1: return [Color(red: 0.18, green: 0.04, blue: 0.13), Color(red: 0.73, green: 0.29, blue: 0.24)]
        case 2: return [Color(red: 0.09, green: 0.13, blue: 0.18), Color(red: 0.70, green: 0.53, blue: 0.29)]
        default: return [Color(red: 0.08, green: 0.04, blue: 0.21), Color(red: 0.43, green: 0.37, blue: 0.73)]
        }
    }

    var body: some View {
        GeometryReader { geometry in
            let size = geometry.size
            ZStack {
                LinearGradient(colors: colors, startPoint: .topLeading, endPoint: .bottomTrailing)
                Circle().fill(.white.opacity(0.035))
                    .frame(width: size.width * 1.8, height: size.width * 1.8)
                    .position(x: size.width * 0.2, y: size.height * 0.9)
                illustration(in: size)
                LinearGradient(colors: [.clear, .black.opacity(0.78)], startPoint: .center, endPoint: .bottom)
                if showsTitle {
                    VStack(alignment: .leading, spacing: 10) {
                        Text(item.kind == .series ? "ДЕМОНСТРАЦИОННЫЙ СЕРИАЛ" : "ДЕМОНСТРАЦИОННЫЙ ФИЛЬМ")
                            .font(.system(size: max(8, min(size.width * 0.031, 14)), weight: .semibold))
                            .tracking(2).opacity(0.7)
                        Text(item.title.uppercased())
                            .font(.system(size: max(16, min(size.width * 0.105, 44)), weight: .black, design: .rounded))
                            .lineLimit(3).minimumScaleFactor(0.65)
                        Rectangle().fill(colors[1]).frame(width: size.width * 0.22, height: 3)
                    }
                    .foregroundStyle(.white)
                    .padding(size.width * 0.09)
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottomLeading)
                }
            }.clipped()
        }
        .accessibilityHidden(true)
    }

    @ViewBuilder
    private func illustration(in size: CGSize) -> some View {
        switch index % 4 {
        case 0:
            Circle().fill(Color.white.opacity(0.7))
                .frame(width: size.width * 0.22, height: size.width * 0.22)
                .position(x: size.width * 0.7, y: size.height * 0.23)
            mountains(in: size, offset: 0).fill(Color.black.opacity(0.32))
            mountains(in: size, offset: size.height * 0.14).fill(Color.black.opacity(0.24))
        case 1:
            Circle().fill(Color(red: 1, green: 0.72, blue: 0.43).opacity(0.72))
                .frame(width: size.width * 0.52, height: size.width * 0.52)
                .position(x: size.width * 0.54, y: size.height * 0.31)
            ForEach(0..<11, id: \.self) { building in
                let height = size.height * CGFloat([0.21, 0.31, 0.26, 0.42, 0.33, 0.47, 0.28, 0.37, 0.25, 0.34, 0.2][building])
                Rectangle().fill(Color.black.opacity(0.68))
                    .frame(width: size.width * 0.105, height: height)
                    .position(x: size.width * CGFloat(building) / 10, y: size.height * 0.76 - height / 2)
            }
        case 2:
            Path { path in
                path.move(to: CGPoint(x: size.width * 0.67, y: size.height * 0.15))
                path.addLine(to: CGPoint(x: size.width * 0.1, y: size.height * 0.53))
                path.addLine(to: CGPoint(x: size.width * 0.94, y: size.height * 0.45))
                path.closeSubpath()
            }.fill(Color.white.opacity(0.18))
            Path { path in
                path.move(to: CGPoint(x: size.width * 0.61, y: size.height * 0.65))
                path.addLine(to: CGPoint(x: size.width * 0.64, y: size.height * 0.28))
                path.addLine(to: CGPoint(x: size.width * 0.71, y: size.height * 0.28))
                path.addLine(to: CGPoint(x: size.width * 0.76, y: size.height * 0.65))
                path.closeSubpath()
            }.fill(Color.black.opacity(0.62))
            Rectangle().fill(Color.white.opacity(0.86))
                .frame(width: size.width * 0.12, height: size.height * 0.032)
                .position(x: size.width * 0.675, y: size.height * 0.28)
        default:
            Circle().fill(LinearGradient(colors: [Color.white.opacity(0.7), colors[1], colors[0]], startPoint: .topLeading, endPoint: .bottomTrailing))
                .frame(width: size.width * 0.65, height: size.width * 0.65)
                .position(x: size.width * 0.56, y: size.height * 0.36)
            Ellipse().stroke(Color.white.opacity(0.55), lineWidth: max(1, size.width * 0.006))
                .frame(width: size.width * 0.98, height: size.width * 0.23)
                .rotationEffect(.degrees(-24))
                .position(x: size.width * 0.56, y: size.height * 0.37)
            ForEach(0..<13, id: \.self) { star in
                Circle().fill(Color.white.opacity(star % 3 == 0 ? 0.8 : 0.3))
                    .frame(width: star % 3 == 0 ? 3 : 2, height: star % 3 == 0 ? 3 : 2)
                    .position(x: size.width * CGFloat((star * 37 + 11) % 100) / 100,
                              y: size.height * CGFloat((star * 19 + 7) % 56) / 100)
            }
        }
    }

    private func mountains(in size: CGSize, offset: CGFloat) -> Path {
        Path { path in
            path.move(to: CGPoint(x: 0, y: size.height * 0.62 + offset))
            path.addLine(to: CGPoint(x: size.width * 0.24, y: size.height * 0.31 + offset))
            path.addLine(to: CGPoint(x: size.width * 0.42, y: size.height * 0.5 + offset))
            path.addLine(to: CGPoint(x: size.width * 0.67, y: size.height * 0.27 + offset))
            path.addLine(to: CGPoint(x: size.width, y: size.height * 0.59 + offset))
            path.addLine(to: CGPoint(x: size.width, y: size.height))
            path.addLine(to: CGPoint(x: 0, y: size.height))
            path.closeSubpath()
        }
    }
}

struct PreviewWatermark: View {
    var body: some View {
        Text("QA · ТЕСТОВЫЕ ДАННЫЕ")
            .font(.system(size: 12, weight: .semibold)).tracking(1)
            .foregroundStyle(.white.opacity(0.9))
            .padding(.horizontal, 12).padding(.vertical, 7)
            .background(Color.black.opacity(0.84), in: Capsule())
            .padding(.trailing, 18).padding(.top, 12)
            .allowsHitTesting(false).accessibilityHidden(true)
    }
}
#endif
