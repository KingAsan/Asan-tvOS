import Foundation
import SwiftUI
import KinoCore
import TorrentSearch

/// One presentation owns search, metadata discovery and explicit file selection.
/// Choosing a search result does not choose a movie file or start payload transfer.
@MainActor
struct TorrentSearchScreen: View {
    // Freeze the identity at presentation. An asynchronous Rezka details refresh
    // must not change the query/header while the user is choosing torrent files.
    @State private var searchMedia: MediaItem
    @State private var mediaReference: MediaReference?
    @State private var preferredEpisodeID: String?
    private let service: any TorrentSearching
    @EnvironmentObject private var downloads: TorrentDownloadsModel
    @Environment(\.dismiss) private var dismiss
    @State private var results: [TorrentSearchResult] = []
    @State private var isSearching = true
    @State private var errorMessage: String?
    @State private var retryToken = 0
    @State private var selectedResult: TorrentSearchResult?
    @State private var presentations: [String: TorrentReleasePresentation] = [:]
    @State private var recommendedID: String?

    private struct SearchRequest: Hashable {
        let query: TorrentSearchQuery
        let generation: Int
    }
    private var searchRequest: SearchRequest {
        SearchRequest(query: TorrentSearchQuery(media: searchMedia), generation: retryToken)
    }

    init(media: MediaItem, reference: MediaReference? = nil, preferredEpisodeID: String? = nil,
         service: any TorrentSearching = TorrentSearchService()) {
        _searchMedia = State(initialValue: media)
        _mediaReference = State(initialValue: reference)
        _preferredEpisodeID = State(initialValue: preferredEpisodeID)
        self.service = service
    }

    var body: some View {
        let request = searchRequest
        NavigationStack {
            if let result = selectedResult {
                TorrentAddFlow(initialMagnet: result.magnet, automaticallySubmit: true, embedsNavigationStack: false,
                    media: searchMedia, reference: mediaReference,
                    preferredEpisodeID: preferredEpisodeID,
                    onCompleted: { dismiss() }, onCancelled: { selectedResult = nil })
                    .environmentObject(downloads)
                    .id(result.id)
            } else { searchContent }
        }
        .background { AsanBackdrop() }
        .task(id: request) { await search(request: request) }
    }

    private var searchContent: some View {
        VStack(spacing: 0) {
            HStack {
                Button("Закрыть") { dismiss() }.accessibilityIdentifier("torrent-search-close")
                Spacer()
                Text("Раздачи").font(.title3.bold())
                    .fixedSize(horizontal: false, vertical: true)
            }
            .padding()
            .focusSection()
            Divider()
            List {
                Section {
                    VStack(alignment: .leading, spacing: 10) {
                        Text(searchMedia.title).font(.system(size: 27, weight: .semibold)).lineLimit(2)
                            .fixedSize(horizontal: false, vertical: true)
                            .accessibilityIdentifier("torrent-search-title")
                        if let original = searchMedia.originalTitle, original != searchMedia.title {
                            Text(original).font(.system(size: 21)).foregroundStyle(.secondary).lineLimit(2)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                        if let year = searchMedia.year { Text(String(year)).font(.system(size: 21)).foregroundStyle(.secondary) }
                    }.padding(.vertical, 8)
                }

                if isSearching {
                    Section {
                        ProgressView("Ищем раздачи…").accessibilityIdentifier("torrent-search-loading")
                    }
                } else if let errorMessage {
                    Section {
                        Button("Повторить поиск") { retryToken += 1 }
                            .accessibilityIdentifier("torrent-search-retry")
                        Text(errorMessage).font(.system(size: 22)).foregroundStyle(.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                            .accessibilityIdentifier("torrent-search-error")
                    }
                } else if results.isEmpty {
                    Section {
                        Button("Повторить поиск") { retryToken += 1 }
                            .accessibilityIdentifier("torrent-search-retry")
                        Text("Раздачи не найдены").font(.system(size: 26, weight: .semibold))
                            .accessibilityIdentifier("torrent-search-empty")
                        Text("Для этого названия и года пока нет подходящих результатов. Попробуй позже или добавь свою magnet-ссылку в «Загрузках».")
                            .font(.system(size: 21)).foregroundStyle(.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                } else {
                    Section {
                        ForEach(results) { result in
                            Button { choose(result) } label: {
                                TorrentSearchResultRow(result: result, requestedYear: searchMedia.kind == .series ? nil : searchMedia.year,
                                    presentation: presentations[result.id] ?? TorrentReleasePresentation(title: ""),
                                    isRecommended: result.id == recommendedID)
                            }
                            .disabled(downloads.isBusy || downloads.preparingID != nil)
                            .accessibilityIdentifier("torrent-search-result-" + result.infoHash)
                        }
                    } header: { Text("Найдено: \(results.count)") } footer: {
                        Text("Выше — доступные компактные релизы с H.264 до 1080p, если это указано в названии. Это подсказки из описания, а не проверка кодеков файла. Выбери раздачу, затем нужные файлы.")
                            .font(.system(size: 20))
                    }
                    if downloads.isBusy || downloads.preparingID != nil {
                        Section { ProgressView("Завершаем предыдущее действие с загрузками…") }
                    }
                }
            }
            .focusSection()
        }
        .background { AsanBackdrop() }
        .accessibilityIdentifier("torrent-search-screen")
        .onExitCommand { dismiss() }
    }

    private func choose(_ result: TorrentSearchResult) {
        guard !downloads.isBusy, downloads.preparingID == nil else { return }
        downloads.clearError()
        selectedResult = result
    }

    private func search(request: SearchRequest) async {
        isSearching = true
        errorMessage = nil
        do {
            let found = try await service.search(request.query)
            try Task.checkCancellation()
            guard request == searchRequest, selectedResult == nil else { return }
            results = TorrentReleasePresentation.ranked(found)
            presentations = Dictionary(uniqueKeysWithValues: results.map { ($0.id, TorrentReleasePresentation(title: $0.title)) })
            recommendedID = TorrentReleasePresentation.recommendedResultID(in: results)
            isSearching = false
        } catch is CancellationError { }
        catch {
            guard !Task.isCancelled, request == searchRequest, selectedResult == nil else { return }
            results = []
            errorMessage = (error as? LocalizedError)?.errorDescription
                ?? "Не удалось получить раздачи. Проверь подключение к интернету и повтори поиск."
            isSearching = false
        }
    }
}

@MainActor
private struct TorrentSearchResultRow: View {
    let result: TorrentSearchResult
    let requestedYear: Int?
    let presentation: TorrentReleasePresentation
    let isRecommended: Bool

    private var size: String {
        guard let bytes = result.sizeBytes, bytes > 0 else { return "Размер уточнится" }
        return ByteCountFormatter.string(fromByteCount: bytes, countStyle: .file)
    }

    private var yearLabel: String {
        guard let year = result.year else { return "Год не указан" }
        if let requestedYear, year != requestedYear { return "\(year) · проверь год" }
        return String(year)
    }

    private var matchLabel: String {
        let score = result.matchConfidence.isFinite ? min(max(result.matchConfidence, 0), 1) : 0
        return score >= 0.9 ? "Название совпадает" : "Проверь название"
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(result.title).font(.system(size: 25, weight: .semibold))
                .fixedSize(horizontal: false, vertical: true)
            if presentation.quality != nil || presentation.codec != nil {
                Text([presentation.quality, presentation.codec].compactMap { $0 }.joined(separator: " · "))
                    .font(.system(size: 22, weight: .medium))
                    .fixedSize(horizontal: false, vertical: true)
            }
            HStack(spacing: 18) {
                Text(size)
                Label("\(max(0, result.seeders))", systemImage: "person.2")
                    .accessibilityLabel("Участников с полной копией: \(max(0, result.seeders))")
            }.font(.system(size: 21)).foregroundStyle(.secondary)
            Text(result.sourceName + " · " + yearLabel)
                .font(.system(size: 20)).foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
            Text(presentation.voice.map { "Озвучка: " + $0 } ?? "Озвучка в описании не указана")
                .font(.system(size: 20)).foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
            Text(isRecommended ? "Предпочтительный вариант по описанию" : matchLabel)
                .font(.system(size: 20)).foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(.vertical, 10)
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

#if DEBUG && targetEnvironment(simulator)
/// Deliberately fictional, offline data for native UI tests. No public swarm or
/// provider request is contacted, and this actor is absent from Release builds.
actor PreviewTorrentSearchService: TorrentSearching {
    private let scene: String?
    private var attempts = 0
    init(scene: String?) { self.scene = scene }

    func search(_ query: TorrentSearchQuery) async throws -> [TorrentSearchResult] {
        attempts += 1
        let attempt = attempts
        try await Task.sleep(for: .milliseconds(200))
        try Task.checkCancellation()
        if attempt == 1, scene == "torrent-search-empty" || scene == "search-empty" { return [] }
        if attempt == 1, scene == "torrent-search-error" || scene == "search-error" { throw PreviewTorrentSearchFailure.unavailable }
        let title = query.originalTitle ?? query.title
        let year = query.year ?? 2026
        return [
            fixture(title: "\(title) (\(year)) 1080p H.264 / AAC", hash: String(repeating: "1", count: 40),
                    bytes: 2 * 1_024 * 1_024 * 1_024, seeders: 24, year: year),
            fixture(title: "\(title) (\(year)) 720p H.264 / AAC", hash: String(repeating: "2", count: 40),
                    bytes: 1_024 * 1_024 * 1_024, seeders: 8, year: year),
        ]
    }

    private func fixture(title: String, hash: String, bytes: Int64, seeders: Int, year: Int) -> TorrentSearchResult {
        TorrentSearchResult(title: title, magnet: "magnet:?xt=urn:btih:" + hash, infoHash: hash,
            sizeBytes: bytes, seeders: seeders, sourceName: "Тестовый источник",
            sourceURL: URL(string: "https://preview.example.invalid/never-requested")!,
            matchConfidence: 1, year: year)
    }
}

private enum PreviewTorrentSearchFailure: LocalizedError {
    case unavailable
    var errorDescription: String? { "Тестовая ошибка поиска. Повтори попытку." }
}
#endif
