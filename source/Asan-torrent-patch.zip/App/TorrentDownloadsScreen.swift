import Foundation
import SwiftUI
import KinoCore

/// Local downloads have their own screen and player; Rezka streams stay separate.
@MainActor
struct TorrentDownloadsScreen: View {
    @EnvironmentObject private var model: TorrentDownloadsModel
    @State private var showAdd = false
    @State private var selection: DownloadSelection?
    @State private var pendingPlaybackID: UUID?

    private struct DownloadSelection: Identifiable { let id: UUID }

    var body: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 30) {
                HStack(alignment: .center, spacing: 30) {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("На этой Apple TV").font(.system(size: 34, weight: .semibold))
                        Text("Свободно: \(torrentByteCount(model.availableBytes))")
                            .font(.callout).foregroundStyle(.secondary)
                            .accessibilityIdentifier("torrent-free-space")
                        Text("Лимит загрузок: 4 ГиБ · один файл за раз")
                            .font(.system(size: 20)).foregroundStyle(.secondary)
                    }
                    Spacer()
                    Button {
                        model.clearError()
                        showAdd = true
                    } label: { Label("Добавить торрент", systemImage: "plus") }
                        .buttonStyle(.borderedProminent)
                        .tint(Theme.accent)
                        .disabled(model.isBusy || model.preparingID != nil)
                        .accessibilityIdentifier("torrent-add")
                }.focusSection()

                if model.downloads.isEmpty {
                    VStack(alignment: .leading, spacing: 20) {
                        Image(systemName: "arrow.down.to.line")
                            .font(.system(size: 48, weight: .light)).foregroundStyle(Theme.accent)
                            .accessibilityHidden(true)
                        Text("Скачай фильм заранее").font(.system(size: 34, weight: .semibold))
                        Text("Добавь magnet-ссылку и выбери видеофайл. После загрузки его можно смотреть прямо с приставки.")
                            .font(.title3).foregroundStyle(.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(40).asanPanel()
                    .accessibilityIdentifier("torrent-empty")
                } else {
                    ForEach(model.downloads) { download in
                        Button {
                            model.clearError()
                            selection = DownloadSelection(id: download.id)
                        } label: { TorrentDownloadRow(download: download) }
                            .accessibilityIdentifier("torrent-download-\(download.id.uuidString)")
                    }
                }

                VStack(alignment: .leading, spacing: 12) {
                    Label("Очистка через 10 часов после загрузки", systemImage: "clock.arrow.circlepath")
                        .font(.system(size: 24, weight: .medium))
                    Text("Оставляй Asan открытым на время скачивания. Если приложение закрыто, просроченные файлы удалятся при следующем запуске. tvOS может освободить кэш раньше.")
                        .font(.system(size: 22)).foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                    Text("Нужна magnet-ссылка на раздачу. Приватные раздачи и раздачи только с HTTPS-трекерами пока не поддерживаются.")
                        .font(.system(size: 20)).foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }.padding(30).asanPanel()
            }
            .padding(.horizontal, 70).padding(.vertical, 40)
        }
        .navigationTitle("Загрузки")
        .background { AsanBackdrop() }
        .accessibilityIdentifier("torrent-downloads")
        .task { await model.refresh() }
        .sheet(isPresented: $showAdd) { TorrentAddFlow().environmentObject(model) }
        .sheet(item: $selection, onDismiss: {
            guard let id = pendingPlaybackID else { return }
            pendingPlaybackID = nil
            Task { await model.play(id: id) }
        }) { selected in
            TorrentDownloadDetails(id: selected.id, play: {
                // Present the root player after this sheet has finished closing.
                pendingPlaybackID = selected.id
                selection = nil
            }).environmentObject(model)
        }
        .alert("Не удалось выполнить действие", isPresented: Binding(
            get: { model.errorMessage != nil && !showAdd && selection == nil },
            set: { if !$0 { model.clearError() } }
        )) {
            Button("Понятно", role: .cancel) { model.clearError() }
        } message: { Text(model.errorMessage ?? "Повтори попытку.") }
    }
}

@MainActor
private struct TorrentDownloadRow: View {
    let download: TorrentDownload

    var body: some View {
        HStack(alignment: .center, spacing: 26) {
            Image(systemName: torrentStatusSymbol(download.state))
                .font(.system(size: 34)).frame(width: 46).accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 12) {
                Text(download.title).font(.system(size: 28, weight: .semibold)).lineLimit(2)
                    .frame(maxWidth: .infinity, alignment: .leading)
                HStack(spacing: 18) {
                    Text(torrentStatusTitle(download.state))
                    if download.totalBytes > 0 {
                        Text("\(torrentByteCount(download.downloadedBytes)) из \(torrentByteCount(download.totalBytes))")
                    }
                }.font(.system(size: 21)).foregroundStyle(.secondary)
                if download.state == .downloading || download.state == .paused || download.state == .queued {
                    ProgressView(value: download.progress)
                        .tint(Theme.accent)
                        .accessibilityLabel("Загрузка")
                        .accessibilityValue("\(Int(download.progress * 100)) процентов")
                }
                if let expiry = download.expiresAt, download.state == .completed {
                    Text("Очистка: \(expiry.formatted(date: .abbreviated, time: .shortened))")
                        .font(.system(size: 20)).foregroundStyle(.secondary)
                }
            }
            Image(systemName: "chevron.right").font(.title3).accessibilityHidden(true)
        }
        .padding(.vertical, 16)
    }
}

/// A single modal owns input, metadata loading and the vertical file list.
/// This avoids presenting a second sheet while the keyboard sheet is closing.
@MainActor
private struct TorrentAddFlow: View {
    @EnvironmentObject private var model: TorrentDownloadsModel
    @Environment(\.dismiss) private var dismiss
    @State private var magnet = ""
    @State private var isSubmitting = false
    @State private var didCommit = false
    @State private var didCancel = false
    @State private var operation: Task<Void, Never>?

    var body: some View {
        NavigationStack {
            Group {
                if model.preparingID != nil && !model.candidates.isEmpty {
                    fileList
                } else if isSubmitting || model.preparingID != nil {
                    VStack(spacing: 28) {
                        ProgressView("Получаем список файлов…")
                        Text("Ожидаем ответ участников раздачи.")
                            .font(.callout).foregroundStyle(.secondary)
                        Button("Отмена") { cancel() }
                    }.frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    inputForm
                }
            }
            .background { AsanBackdrop() }
            .navigationTitle(model.candidates.isEmpty ? "Добавить торрент" : "Выбери видеофайл")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Отмена") { cancel() }.accessibilityIdentifier("torrent-cancel-add")
                }
            }
            .onExitCommand { cancel() }
        }
        .onDisappear {
            operation?.cancel()
            if !didCommit { abandonPreparation() }
        }
    }

    private var inputForm: some View {
        Form {
            Section {
                TextField("magnet:?xt=urn:btih:…", text: $magnet)
                    .textInputAutocapitalization(.never).autocorrectionDisabled()
                    .submitLabel(.continue)
                    .onSubmit { submit() }
                    .accessibilityIdentifier("torrent-magnet")
            } header: { Text("Magnet-ссылка") } footer: {
                Text("Вставь ссылку на раздачу с помощью клавиатуры iPhone или введи её с пульта. Размер и файлы появятся после подключения к раздаче.")
                    .font(.system(size: 20))
            }
            if let error = model.errorMessage {
                Section { Text(error).foregroundStyle(.red).fixedSize(horizontal: false, vertical: true) }
            }
            Section {
                Button("Получить список файлов") { submit() }
                    .disabled(model.isBusy || magnet.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    .accessibilityIdentifier("torrent-submit")
            }
        }
    }

    private var fileList: some View {
        List {
            Section {
                ForEach(model.candidates) { file in
                    Button { choose(file) } label: {
                        VStack(alignment: .leading, spacing: 10) {
                            Text(file.name).font(.system(size: 27, weight: .medium))
                                .fixedSize(horizontal: false, vertical: true)
                            Text(file.isPlayable ? torrentByteCount(file.size) : "Неподдерживаемый формат · \(torrentByteCount(file.size))")
                                .font(.system(size: 21)).foregroundStyle(.secondary)
                        }.padding(.vertical, 12)
                    }
                    .disabled(model.isBusy || !file.isPlayable)
                    .accessibilityIdentifier("torrent-file-\(file.id)")
                }
            } footer: {
                Text("Скачается только выбранный файл. Оставляй Asan открытым до завершения загрузки.")
                    .font(.system(size: 20))
            }
            if let error = model.errorMessage {
                Section { Text(error).foregroundStyle(.red).fixedSize(horizontal: false, vertical: true) }
            }
        }.focusSection().accessibilityIdentifier("torrent-files")
    }

    private func submit() {
        guard !isSubmitting, !model.isBusy,
              !magnet.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
        model.clearError()
        isSubmitting = true
        operation = Task { @MainActor in
            defer { isSubmitting = false }
            await model.add(magnet: magnet)
        }
    }

    private func choose(_ file: TorrentFileChoice) {
        guard !model.isBusy, file.isPlayable else { return }
        model.clearError()
        operation = Task { @MainActor in
            await model.download(file: file)
            guard !Task.isCancelled, model.errorMessage == nil else { return }
            didCommit = true
            dismiss()
        }
    }

    private func abandonPreparation() {
        guard !didCancel, !didCommit else { return }
        didCancel = true
        operation?.cancel()
        Task { await model.cancelPreparation() }
    }

    private func cancel() {
        abandonPreparation()
        dismiss()
    }
}

@MainActor
private struct TorrentDownloadDetails: View {
    let id: UUID
    let play: () -> Void
    @EnvironmentObject private var model: TorrentDownloadsModel
    @Environment(\.dismiss) private var dismiss
    @State private var confirmDelete = false

    private var download: TorrentDownload? { model.downloads.first { $0.id == id } }

    var body: some View {
        NavigationStack {
            Form {
                if let download {
                    // Keep remote actions visible at sheet entry; a tall
                    // read-only Form section can otherwise strand focus on Done.
                    Section {
                        if model.isBusy { ProgressView("Подготавливаем загрузку…") }
                        if download.state == .completed && !download.isExpired(at: Date()) {
                            Button(action: play) {
                                Label("Смотреть", systemImage: "play.fill")
                            }.accessibilityIdentifier("torrent-play-\(id.uuidString)")
                        } else if download.state == .downloading {
                            Button { Task { await model.pause(id: id) } } label: {
                                Label("Приостановить", systemImage: "pause")
                            }.accessibilityIdentifier("torrent-pause-\(id.uuidString)")
                        } else if download.fileIndex != nil && download.state != .completed {
                            Button { Task { await model.resume(id: id) } } label: {
                                Label(download.state == .missing || download.state == .failed ? "Скачать снова" : "Продолжить загрузку",
                                    systemImage: "arrow.down")
                            }.accessibilityIdentifier("torrent-resume-\(id.uuidString)")
                        }
                        Button("Удалить загрузку", role: .destructive) { confirmDelete = true }
                            .accessibilityIdentifier("torrent-delete-\(id.uuidString)")
                    }.disabled(model.isBusy)
                    Section {
                        Text(download.title).font(.title3).fixedSize(horizontal: false, vertical: true)
                        if let fileName = download.fileName {
                            Text(fileName).font(.callout).foregroundStyle(.secondary)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                    }
                    Section {
                        LabeledContent("Состояние", value: torrentStatusTitle(download.state))
                        if download.totalBytes > 0 {
                            LabeledContent("Загружено", value: "\(torrentByteCount(download.downloadedBytes)) из \(torrentByteCount(download.totalBytes))")
                            ProgressView(value: download.progress).tint(Theme.accent)
                        }
                        if let expiry = download.expiresAt {
                            LabeledContent("Очистка", value: expiry.formatted(date: .abbreviated, time: .shortened))
                        }
                        if download.state == .missing {
                            Text("Файла больше нет в кэше. Его можно скачать снова.")
                                .font(.callout).foregroundStyle(.secondary)
                        }
                    }
                } else {
                    Text("Загрузка удалена.")
                }
            }
            .navigationTitle("Загрузка")
            .background { AsanBackdrop() }
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Готово") { dismiss() } }
            }
            .onExitCommand { dismiss() }
        }
        .onChange(of: download == nil) { missing in if missing { dismiss() } }
        .confirmationDialog("Удалить файл с этой Apple TV?", isPresented: $confirmDelete, titleVisibility: .visible) {
            Button("Удалить", role: .destructive) { Task { await model.remove(id: id) } }
            Button("Отмена", role: .cancel) {}
        } message: { Text("Чтобы посмотреть его позже, потребуется повторная загрузка.") }
        .alert("Не удалось выполнить действие", isPresented: Binding(
            get: { model.errorMessage != nil },
            set: { if !$0 { model.clearError() } }
        )) {
            Button("Понятно", role: .cancel) { model.clearError() }
        } message: { Text(model.errorMessage ?? "Повтори попытку.") }
    }
}

private func torrentByteCount(_ bytes: Int64) -> String {
    ByteCountFormatter.string(fromByteCount: max(0, bytes), countStyle: .file)
}

private func torrentStatusTitle(_ state: TorrentDownloadState) -> String {
    switch state {
    case .queued: return "В очереди"
    case .downloading: return "Скачивается"
    case .paused: return "Приостановлено"
    case .completed: return "Готово к просмотру"
    case .failed: return "Загрузка остановлена"
    case .missing: return "Файл отсутствует"
    }
}

private func torrentStatusSymbol(_ state: TorrentDownloadState) -> String {
    switch state {
    case .queued: return "clock"
    case .downloading: return "arrow.down.circle"
    case .paused: return "pause.circle"
    case .completed: return "checkmark.circle"
    case .failed: return "exclamationmark.circle"
    case .missing: return "externaldrive.badge.exclamationmark"
    }
}
