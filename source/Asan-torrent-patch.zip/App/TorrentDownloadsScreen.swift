import Foundation
import SwiftUI
import KinoCore

/// Local downloads have their own screen and player; Rezka streams stay separate.
@MainActor
struct TorrentDownloadsScreen: View {
    @EnvironmentObject private var model: TorrentDownloadsModel
    @State private var showAdd = false
    @State private var selection: DownloadSelection?
    @State private var pendingPlaybackID: UUID?

    private struct DownloadSelection: Identifiable { let id: UUID }

    var body: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 30) {
                HStack(alignment: .center, spacing: 30) {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("На этой Apple TV").font(.system(size: 34, weight: .semibold))
                        Text("Свободно: \(torrentByteCount(model.availableBytes))")
                            .font(.callout).foregroundStyle(.secondary)
                            .accessibilityIdentifier("torrent-free-space")
                        Text("Лимит загрузок: \(TorrentDownloadPolicy.defaultBudgetBytes / 1_073_741_824) ГиБ · один файл за раз")
                            .font(.system(size: 20)).foregroundStyle(.secondary)
                    }
                    Spacer()
                    Button {
                        model.clearError()
                        showAdd = true
                    } label: { Label("Добавить торрент", systemImage: "plus") }
                        .buttonStyle(.bordered)
                        .disabled(model.isBusy || model.preparingID != nil)
                        .accessibilityIdentifier("torrent-add")
                }.focusSection()

                if model.downloads.isEmpty {
                    VStack(alignment: .leading, spacing: 20) {
                        Image(systemName: "arrow.down.to.line")
                            .font(.system(size: 48, weight: .light)).foregroundStyle(Theme.accent)
                            .accessibilityHidden(true)
                        Text("Скачай фильм заранее").font(.system(size: 34, weight: .semibold))
                        Text("Добавь magnet-ссылку и выбери видеофайл. После загрузки его можно смотреть прямо с приставки.")
                            .font(.title3).foregroundStyle(.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(40).asanPanel()
                    .accessibilityIdentifier("torrent-empty")
                } else {
                    ForEach(model.downloads) { download in
                        Button {
                            model.clearError()
                            selection = DownloadSelection(id: download.id)
                        } label: { TorrentDownloadRow(download: download) }
                            .accessibilityIdentifier("torrent-download-\(download.id.uuidString)")
                    }
                }

                VStack(alignment: .leading, spacing: 12) {
                    Label("Очистка через 10 часов после загрузки", systemImage: "clock.arrow.circlepath")
                        .font(.system(size: 24, weight: .medium))
                    Text("Оставляй Asan открытым на время скачивания. Если приложение закрыто, просроченные файлы удалятся при следующем запуске. tvOS может освободить кэш раньше.")
                        .font(.system(size: 22)).foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                    Text("Нужна magnet-ссылка на раздачу. Приватные раздачи и раздачи только с HTTPS-трекерами пока не поддерживаются.")
                        .font(.system(size: 20)).foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }.padding(30).asanPanel()
            }
            .padding(.horizontal, 70).padding(.vertical, 40)
        }
        .navigationTitle("Загрузки")
        .background { AsanBackdrop() }
        .accessibilityIdentifier("torrent-downloads")
        .task { await model.refresh() }
        .sheet(isPresented: $showAdd) { TorrentAddFlow().environmentObject(model) }
        .sheet(item: $selection, onDismiss: {
            guard let id = pendingPlaybackID else { return }
            pendingPlaybackID = nil
            Task { await model.play(id: id) }
        }) { selected in
            TorrentDownloadDetails(id: selected.id, play: {
                // Present the root player after this sheet has finished closing.
                pendingPlaybackID = selected.id
                selection = nil
            }).environmentObject(model)
        }
        .alert("Не удалось выполнить действие", isPresented: Binding(
            get: { model.errorMessage != nil && !showAdd && selection == nil },
            set: { if !$0 { model.clearError() } }
        )) {
            Button("Понятно", role: .cancel) { model.clearError() }
        } message: { Text(model.errorMessage ?? "Повтори попытку.") }
    }
}

@MainActor
private struct TorrentDownloadRow: View {
    let download: TorrentDownload
    @EnvironmentObject private var model: TorrentDownloadsModel

    var body: some View {
        HStack(alignment: .center, spacing: 26) {
            Image(systemName: torrentStatusSymbol(download.state))
                .font(.system(size: 34)).frame(width: 46).accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 12) {
                Text(download.title).font(.system(size: 28, weight: .semibold)).lineLimit(2)
                    .frame(maxWidth: .infinity, alignment: .leading)
                HStack(spacing: 18) {
                    Text(model.waitingForSpaceID == download.id ? "Ожидает места" :
                        model.queuePreparingID == download.id ? "Получаем файлы…" : torrentStatusTitle(download.state))
                    if download.totalBytes > 0 {
                        Text("\(torrentByteCount(download.downloadedBytes)) из \(torrentByteCount(download.totalBytes))")
                    }
                }.font(.system(size: 21)).foregroundStyle(.secondary)
                if download.state == .downloading || download.state == .paused || download.state == .queued {
                    ProgressView(value: download.progress)
                        .tint(Theme.accent)
                        .accessibilityLabel("Загрузка")
                        .accessibilityValue("\(Int(download.progress * 100)) процентов")
                }
                if let expiry = download.expiresAt, download.state == .completed {
                    Text("Очистка: \(expiry.formatted(date: .abbreviated, time: .shortened))")
                        .font(.system(size: 20)).foregroundStyle(.secondary)
                }
                if let association = download.mediaAssociation,
                   let season = association.seasonNumber, let episode = association.episodeNumber {
                    Text("Сезон \(season) · серия \(episode)").font(.system(size: 20)).foregroundStyle(.secondary)
                }
            }
            Image(systemName: "chevron.right").font(.title3).accessibilityHidden(true)
        }
        .padding(.vertical, 16)
    }
}

/// A single modal owns input, metadata loading and the vertical file list.
/// This avoids presenting a second sheet while the keyboard sheet is closing.
@MainActor
struct TorrentAddFlow: View {
    @EnvironmentObject private var model: TorrentDownloadsModel
    @Environment(\.dismiss) private var dismiss
    @State private var magnet = ""
    @State private var isSubmitting = false
    @State private var didCommit = false
    @State private var didCancel = false
    @State private var operation: Task<Void, Never>?
    @State private var didAutomaticallySubmit = false
    @State private var selectedFiles = Set<Int>()
    private let automaticallySubmit: Bool
    private let embedsNavigationStack: Bool
    private let onCompleted: (() -> Void)?
    private let onCancelled: (() -> Void)?
    private let media: MediaItem?
    private let reference: MediaReference?
    private let preferredEpisodeID: String?

    init(initialMagnet: String = "", automaticallySubmit: Bool = false, embedsNavigationStack: Bool = true,
         media: MediaItem? = nil, reference: MediaReference? = nil,
         preferredEpisodeID: String? = nil,
         onCompleted: (() -> Void)? = nil, onCancelled: (() -> Void)? = nil) {
        _magnet = State(initialValue: initialMagnet)
        self.automaticallySubmit = automaticallySubmit
        self.embedsNavigationStack = embedsNavigationStack
        self.onCompleted = onCompleted
        self.onCancelled = onCancelled
        self.media = media
        self.reference = reference
        self.preferredEpisodeID = preferredEpisodeID
    }

    var body: some View {
        VStack(spacing: 0) {
            if embedsNavigationStack { NavigationStack { content } }
            else { content }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .onDisappear {
            operation?.cancel()
            if !didCommit { abandonPreparation() }
        }
    }

    private var content: some View {
        Group {
            if model.preparingID != nil && !model.candidates.isEmpty {
                fileList
            } else if isSubmitting || model.preparingID != nil {
                VStack(spacing: 28) {
                    ProgressView("Получаем список файлов…")
                    Text("Ожидаем ответ участников раздачи.")
                        .font(.callout).foregroundStyle(.secondary)
                    Button(embedsNavigationStack ? "Отмена" : "Назад") { cancel() }
                }.frame(maxWidth: .infinity, maxHeight: .infinity)
            } else { inputForm }
        }
        .background { AsanBackdrop() }
        .navigationTitle(model.candidates.isEmpty ? "Торрент" : "Файлы")
        .toolbar {
            ToolbarItem(placement: .cancellationAction) {
                Button(embedsNavigationStack ? "Отмена" : "Назад") { cancel() }
                    .accessibilityIdentifier("torrent-cancel-add")
            }
        }
        .onExitCommand { cancel() }
        .task(id: model.isBusy) {
            guard automaticallySubmit, !didAutomaticallySubmit, !model.isBusy else { return }
            didAutomaticallySubmit = true
            submit()
        }
    }

    private var inputForm: some View {
        Form {
            Section {
                TextField("magnet:?xt=urn:btih:…", text: $magnet)
                    .textInputAutocapitalization(.never).autocorrectionDisabled()
                    .submitLabel(.continue)
                    .onSubmit { submit() }
                    .accessibilityIdentifier("torrent-magnet")
            } header: { Text("Magnet-ссылка") } footer: {
                Text("Вставь ссылку на раздачу с помощью клавиатуры iPhone или введи её с пульта. Размер и файлы появятся после подключения к раздаче.")
                    .font(.system(size: 20))
            }
            if let error = model.errorMessage {
                Section { Text(error).foregroundStyle(.red).fixedSize(horizontal: false, vertical: true) }
            }
            Section {
                Button("Получить список файлов") { submit() }
                    .disabled(model.isBusy || magnet.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    .accessibilityIdentifier("torrent-submit")
            }
        }
    }

    private var fileList: some View {
        List {
            if media?.kind == .series {
                Section {
                    Button { chooseBatch() } label: {
                        Label("В очередь: \(selectedFiles.count)", systemImage: "text.badge.plus")
                    }
                    .disabled(model.isBusy || selectedFiles.isEmpty)
                    .accessibilityIdentifier("torrent-queue-confirm")
                } footer: {
                    Text("Отметь нужные серии. Они скачаются по одной, пока Asan открыт. Если кэш заполнен, очередь дождётся места.")
                        .font(.system(size: 20))
                }
            }
            Section {
                ForEach(model.candidates) { file in
                    Button { select(file) } label: {
                        HStack(spacing: 18) {
                            if media?.kind == .series {
                                Image(systemName: selectedFiles.contains(file.id) ? "checkmark.circle.fill" : "circle")
                                    .accessibilityHidden(true)
                            }
                            VStack(alignment: .leading, spacing: 10) {
                                Text(file.name).font(.system(size: 27, weight: .medium))
                                    .fixedSize(horizontal: false, vertical: true)
                                Text(file.isPlayable ? torrentByteCount(file.size) : "Неподдерживаемый формат · \(torrentByteCount(file.size))")
                                    .font(.system(size: 21)).foregroundStyle(.secondary)
                                if isPreferredEpisode(file) {
                                    Text("Нужная серия по каталогу").font(.system(size: 20)).foregroundStyle(.secondary)
                                }
                            }
                        }.padding(.vertical, 12)
                    }
                    .disabled(model.isBusy || !file.isPlayable)
                    .accessibilityValue(selectedFiles.contains(file.id) ? "Выбрано" : "Не выбрано")
                    .accessibilityIdentifier("torrent-file-\(file.id)")
                }
            } footer: {
                Text(media?.kind == .series ? "Номера серий связываются с каталогом только при однозначном совпадении SxxExx. Остальные файлы доступны в «Загрузках»." :
                    "Скачается только выбранный файл. Оставляй Asan открытым до завершения загрузки.")
                    .font(.system(size: 20))
            }
            if let error = model.errorMessage {
                Section { Text(error).foregroundStyle(.red).fixedSize(horizontal: false, vertical: true) }
            }
        }.focusSection().accessibilityIdentifier("torrent-files")
    }

    private func submit() {
        guard !isSubmitting, !model.isBusy,
              !magnet.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
        model.clearError()
        isSubmitting = true
        operation = Task { @MainActor in
            defer { isSubmitting = false }
            await model.add(magnet: magnet, media: media, reference: reference)
        }
    }

    private func isPreferredEpisode(_ file: TorrentFileChoice) -> Bool {
        guard let preferredEpisodeID, let media, let reference else { return false }
        return TorrentMediaAssociation.resolvingFile(name: file.name, media: media, providerID: reference.providerID)?.episodeID == preferredEpisodeID
    }

    private func select(_ file: TorrentFileChoice) {
        guard !model.isBusy, file.isPlayable else { return }
        if media?.kind == .series {
            if selectedFiles.contains(file.id) { selectedFiles.remove(file.id) }
            else { selectedFiles.insert(file.id) }
        } else { choose([file]) }
    }

    private func chooseBatch() {
        choose(model.candidates.filter { selectedFiles.contains($0.id) && $0.isPlayable })
    }

    private func choose(_ files: [TorrentFileChoice]) {
        guard !model.isBusy, !files.isEmpty, files.allSatisfy(\.isPlayable) else { return }
        model.clearError()
        operation = Task { @MainActor in
            let accepted = await model.download(files: files)
            guard !Task.isCancelled, accepted else { return }
            didCommit = true
            if let onCompleted { onCompleted() } else { dismiss() }
        }
    }

    private func abandonPreparation() {
        guard !didCancel, !didCommit else { return }
        didCancel = true
        operation?.cancel()
        Task { await model.cancelPreparation() }
    }

    private func cancel() {
        abandonPreparation()
        if let onCancelled { onCancelled() } else { dismiss() }
    }
}

@MainActor
private struct TorrentDownloadDetails: View {
    let id: UUID
    let play: () -> Void
    @EnvironmentObject private var model: TorrentDownloadsModel
    @Environment(\.dismiss) private var dismiss
    @State private var confirmDelete = false

    private var download: TorrentDownload? { model.downloads.first { $0.id == id } }

    var body: some View {
        NavigationStack {
            Form {
                if let download {
                    // Keep remote actions visible at sheet entry; a tall
                    // read-only Form section can otherwise strand focus on Done.
                    Section {
                        if model.isBusy || model.queuePreparingID == id { ProgressView("Подготавливаем загрузку…") }
                        if download.state == .completed && !download.isExpired(at: Date()) {
                            Button(action: play) {
                                Label("Смотреть", systemImage: "play.fill")
                            }.accessibilityIdentifier("torrent-play-\(id.uuidString)")
                        } else if download.state == .downloading || download.state == .queued {
                            Button { Task { await model.pause(id: id) } } label: {
                                Label(download.state == .queued ? "Убрать из очереди" : "Приостановить", systemImage: "pause")
                            }.accessibilityIdentifier("torrent-pause-\(id.uuidString)")
                        } else if download.fileIndex != nil && download.state != .completed {
                            Button { Task { await model.resume(id: id) } } label: {
                                Label(download.state == .missing || download.state == .failed ? "Скачать снова" : "Продолжить загрузку",
                                    systemImage: "arrow.down")
                            }.accessibilityIdentifier("torrent-resume-\(id.uuidString)")
                        }
                        if download.queueOrder != nil && [.paused, .failed].contains(download.state) {
                            Button { Task { await model.pause(id: id) } } label: {
                                Label("Убрать из очереди", systemImage: "pause")
                            }.accessibilityIdentifier("torrent-dequeue-\(id.uuidString)")
                        }
                        Button("Удалить загрузку", role: .destructive) { confirmDelete = true }
                            .disabled(model.isBusy)
                            .accessibilityIdentifier("torrent-delete-\(id.uuidString)")
                    }.disabled(model.isBusy && model.queuePreparingID != id)
                    Section {
                        Text(download.title).font(.title3).fixedSize(horizontal: false, vertical: true)
                        if let fileName = download.fileName {
                            Text(fileName).font(.callout).foregroundStyle(.secondary)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                    }
                    Section {
                        LabeledContent("Состояние", value: torrentStatusTitle(download.state))
                        if model.waitingForSpaceID == id {
                            Text("Ожидает места. Предыдущие файлы сохранятся до удаления или срока очистки.")
                                .font(.callout).foregroundStyle(.secondary)
                        }
                        if download.totalBytes > 0 {
                            LabeledContent("Загружено", value: "\(torrentByteCount(download.downloadedBytes)) из \(torrentByteCount(download.totalBytes))")
                            ProgressView(value: download.progress).tint(Theme.accent)
                        }
                        if let expiry = download.expiresAt {
                            LabeledContent("Очистка", value: expiry.formatted(date: .abbreviated, time: .shortened))
                        }
                        if download.state == .missing {
                            Text("Файла больше нет в кэше. Его можно скачать снова.")
                                .font(.callout).foregroundStyle(.secondary)
                        }
                    }
                } else {
                    Text("Загрузка удалена.")
                }
            }
            .navigationTitle("Загрузка")
            .background { AsanBackdrop() }
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Готово") { dismiss() } }
            }
            .onExitCommand { dismiss() }
        }
        .onChange(of: download == nil) { missing in if missing { dismiss() } }
        .confirmationDialog("Удалить файл с этой Apple TV?", isPresented: $confirmDelete, titleVisibility: .visible) {
            Button("Удалить", role: .destructive) { Task { await model.remove(id: id) } }
            Button("Отмена", role: .cancel) {}
        } message: { Text("Чтобы посмотреть его позже, потребуется повторная загрузка.") }
        .alert("Не удалось выполнить действие", isPresented: Binding(
            get: { model.errorMessage != nil },
            set: { if !$0 { model.clearError() } }
        )) {
            Button("Понятно", role: .cancel) { model.clearError() }
        } message: { Text(model.errorMessage ?? "Повтори попытку.") }
    }
}

private func torrentByteCount(_ bytes: Int64) -> String {
    ByteCountFormatter.string(fromByteCount: max(0, bytes), countStyle: .file)
}

private func torrentStatusTitle(_ state: TorrentDownloadState) -> String {
    switch state {
    case .queued: return "В очереди"
    case .downloading: return "Скачивается"
    case .paused: return "Приостановлено"
    case .completed: return "Готово к просмотру"
    case .failed: return "Загрузка остановлена"
    case .missing: return "Файл отсутствует"
    }
}

private func torrentStatusSymbol(_ state: TorrentDownloadState) -> String {
    switch state {
    case .queued: return "clock"
    case .downloading: return "arrow.down.circle"
    case .paused: return "pause.circle"
    case .completed: return "checkmark.circle"
    case .failed: return "exclamationmark.circle"
    case .missing: return "externaldrive.badge.exclamationmark"
    }
}
