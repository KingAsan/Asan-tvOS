import SwiftUI

struct SettingsScreen: View {
    @EnvironmentObject private var model: AppModel
    @State private var showLogin = false
    @State private var showMirror = false
    @State private var confirmClear = false
    @State private var confirmLogout = false

    var body: some View {
        Form {
            Section("Аккаунт Rezka") {
                if model.isCheckingAccount { ProgressView("Проверяем сессию…") }
                if model.account.isAuthenticated {
                    LabeledContent("Пользователь", value: model.account.displayName)
                    LabeledContent("Подписка", value: model.account.isPremium ? "Premium" : "Статус Premium не подтверждён")
                    Button("Обновить данные аккаунта") { Task { await model.refreshAccount() } }.disabled(model.isCheckingAccount)
                    Button("Выйти из аккаунта", role: .destructive) { confirmLogout = true }
                } else {
                    Button("Войти в Rezka") { showLogin = true }.disabled(!model.isConfigured)
                    Text("Войди в тот же аккаунт, где оформлена Premium-подписка.")
                        .font(.callout).foregroundStyle(.secondary)
                }
                if let error = model.accountError { Text(error).font(.callout).foregroundStyle(.secondary) }
            }.disabled(model.isUpdatingAccount)
            Section("Зеркало") {
                LabeledContent("Адрес", value: model.mirrorAddress.isEmpty ? "https://rezka.fi/" : model.mirrorAddress)
                Button("Изменить адрес") { showMirror = true }
                Button("Обновить каталог") { Task { await model.refresh() } }
                    .disabled(!model.account.isAuthenticated || model.isRefreshing)
            }
            .disabled(model.isUpdatingAccount)
            Section("Воспроизведение") {
                Toggle("Следующая серия автоматически", isOn: $model.autoplayNext)
                Text("Озвучка и качество выбираются перед просмотром. Во время фильма качество, аудио и субтитры доступны в штатной панели видео.")
                    .font(.callout).foregroundStyle(.secondary)
            }
            Section {
                LabeledContent("В избранном", value: "\(model.library.favorites.count)")
                LabeledContent("Смотреть позже", value: "\(model.library.watchlist.count)")
                LabeledContent("Записей в истории", value: "\(model.library.history.count)")
                Button("Очистить библиотеку", role: .destructive) { confirmClear = true }
            } header: { Text("Библиотека") } footer: {
                Text("Эти списки и позиции просмотра сохраняются на приставке. Синхронизация с закладками сайта пока не подключена.")
            }
            Section("О приложении") {
                LabeledContent("Версия", value: Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "0.4.0")
                Text("Asan для Apple TV · Rezka и локальные загрузки")
            }
        }
        .background { AsanBackdrop() }
        .navigationTitle("Настройки")
        .sheet(isPresented: $showLogin) { LoginForm().environmentObject(model) }
        .sheet(isPresented: $showMirror) { MirrorForm().environmentObject(model) }
        .onAppear {
            #if DEBUG && targetEnvironment(simulator)
            if PreviewSupport.scene == .login { showLogin = true }
            #endif
        }
        .confirmationDialog("Очистить избранное, очередь и историю?", isPresented: $confirmClear, titleVisibility: .visible) {
            Button("Очистить", role: .destructive) { Task { await model.clearLibrary() } }
            Button("Отмена", role: .cancel) {}
        } message: { Text("Аккаунт останется подключённым. Удалённые записи восстановить не получится.") }
        .confirmationDialog("Выйти из Rezka?", isPresented: $confirmLogout, titleVisibility: .visible) {
            Button("Выйти", role: .destructive) { Task { await model.logout() } }
            Button("Отмена", role: .cancel) {}
        }
    }
}

private struct LoginForm: View {
    @EnvironmentObject private var model: AppModel
    @Environment(\.dismiss) private var dismiss
    @State private var username = ""
    @State private var password = ""
    @State private var isLoading = false
    @State private var error: String?
    @State private var loginTask: Task<Void, Never>?

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("Email или логин", text: $username)
                        .textContentType(.username).textInputAutocapitalization(.never).autocorrectionDisabled()
                    SecureField("Пароль", text: $password).textContentType(.password)
                } header: { Text(model.mirrorAddress) } footer: {
                    Text("Пароль не сохраняется. На приставке остаётся только защищённая сессия.")
                        .font(.system(size: 18)).foregroundStyle(.secondary)
                }
                if let error { Section { Text(error).font(.callout).foregroundStyle(.red) } }
                Section {
                    Button {
                        isLoading = true; error = nil
                        loginTask = Task {
                            do {
                                try await model.login(username: username.trimmingCharacters(in: .whitespacesAndNewlines), password: password)
                                try Task.checkCancellation()
                                password = ""
                                dismiss()
                            } catch is CancellationError { password = "" }
                            catch { self.error = model.friendly(error); password = "" }
                            isLoading = false
                        }
                    } label: {
                        if isLoading { HStack { ProgressView(); Text("Входим…") } } else { Text("Войти") }
                    }.disabled(isLoading || username.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || password.isEmpty)
                }
            }
            .navigationTitle("Вход")
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Отмена") { loginTask?.cancel(); password = ""; dismiss() } } }
        }
        .overlay(alignment: .topTrailing) {
            #if DEBUG && targetEnvironment(simulator)
            if PreviewSupport.scene != nil { PreviewWatermark() }
            #endif
        }
        .onDisappear { loginTask?.cancel(); password = "" }
    }
}

private struct MirrorForm: View {
    @EnvironmentObject private var model: AppModel
    @Environment(\.dismiss) private var dismiss
    @State private var address = ""
    @State private var isSaving = false
    @State private var error: String?
    @State private var saveTask: Task<Void, Never>?
    var body: some View {
        NavigationStack {
            Form {
                Section("Адрес Rezka") {
                    TextField("https://rezka.fi/", text: $address).textInputAutocapitalization(.never).autocorrectionDisabled()
                    Text("Введи полный HTTPS-адрес зеркала без пути к фильму. Для другого адреса может понадобиться повторный вход.")
                        .font(.callout).foregroundStyle(.secondary)
                }
                if let error { Section { Text(error).foregroundStyle(.red) } }
                Section {
                    Button {
                        isSaving = true; error = nil
                        saveTask = Task {
                            do { try await model.configureMirror(address: address); try Task.checkCancellation(); dismiss() }
                            catch is CancellationError { }
                            catch { self.error = model.friendly(error) }
                            isSaving = false
                        }
                    } label: {
                        if isSaving { HStack { ProgressView(); Text("Сохраняем…") } } else { Text("Сохранить адрес") }
                    }.disabled(isSaving || address.isEmpty)
                }
            }
            .navigationTitle("Зеркало")
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Отмена") { saveTask?.cancel(); dismiss() } } }
        }
        .onAppear { address = model.mirrorAddress.isEmpty ? "https://rezka.fi/" : model.mirrorAddress }
        .onDisappear { saveTask?.cancel() }
    }
}
