#if DEBUG && targetEnvironment(simulator)
import SwiftUI
import UIKit
import KinoCore

/// Rasterise the same fictional poster already visible in the marked QA
/// catalogue. This exercises the real decoding/processing path, offline.
/// Neither a new image resource nor this code is present in a Release build.
@MainActor
enum PreviewArtwork {
    private static var images: [String: Data] = [:]

    static func atmosphereData(for media: MediaItem) -> Data? {
        guard PreviewSupport.isSyntheticCatalog,
              media.backdropURL == nil, media.posterURL == nil else { return nil }
        let key = media.id + "|" + media.title
        if let image = images[key] { return image }
        let renderer = ImageRenderer(content: PreviewPosterArtwork(item: media)
            .frame(width: 320, height: 480).environment(\.colorScheme, .dark))
        renderer.scale = 1
        renderer.isOpaque = true
        guard let image = renderer.uiImage?.pngData(), image.count <= 2 * 1024 * 1024 else { return nil }
        if images.count >= 12 { images.removeAll(keepingCapacity: true) }
        images[key] = image
        return image
    }
}
#endif
