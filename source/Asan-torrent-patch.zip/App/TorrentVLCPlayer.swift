import Foundation
import SwiftUI
import AVFoundation
import Combine
import UIKit
import TVVLCKit

private struct TorrentVLCTrack: Identifiable, Equatable {
    let id: Int32
    let title: String
}

/// Ownership transfers to this operation after drawable and delegate detach.
/// libVLC's synchronous stop can join decoder threads, so it runs off the UI.
private final class TorrentVLCStopOperation: @unchecked Sendable {
    private let player: VLCMediaPlayer
    init(_ player: VLCMediaPlayer) { self.player = player }
    func run() { player.stop() }
}

@MainActor
private final class TorrentVLCController: NSObject, ObservableObject, VLCMediaPlayerDelegate {
    @Published private(set) var isWaiting = true
    @Published private(set) var isPlaying = false
    @Published private(set) var hasEnded = false
    @Published private(set) var stateText = "Подготовка"
    @Published private(set) var errorMessage: String?
    @Published private(set) var elapsedSeconds = 0
    @Published private(set) var audioTracks: [TorrentVLCTrack] = []
    @Published private(set) var subtitleTracks: [TorrentVLCTrack] = []
    @Published private(set) var selectedAudioID: Int32 = -1
    @Published private(set) var selectedSubtitleID: Int32 = -1
    private let playback: TorrentLocalPlayback
    private var player: VLCMediaPlayer?
    private weak var drawable: UIView?
    private var startupTask: Task<Void, Never>?
    private var generation = 0
    private var started = false
    private var stopped = false
    private var suspendedForScene = false
    private var resumeWhenActive = false
    private var lastTimeUpdate = 0.0

    init(playback: TorrentLocalPlayback) { self.playback = playback }

    func attach(_ view: UIView) {
        drawable = view
        player?.drawable = view
        if started, player == nil, !stopped {
            Task { @MainActor [weak self, weak view] in
                guard let self, let view, self.drawable === view, !self.stopped, self.player == nil else { return }
                self.load()
            }
        }
    }

    func start() {
        guard !started, !stopped else { return }
        started = true
        if drawable != nil { load() }
    }

    func retry() {
        guard !stopped else { return }
        load()
    }

    func stop() {
        guard !stopped else { return }
        stopped = true
        resumeWhenActive = false
        generation += 1
        startupTask?.cancel()
        startupTask = nil
        retirePlayer()
        drawable = nil
        isPlaying = false
    }

    func updateScenePhase(_ phase: ScenePhase) {
        guard !stopped else { return }
        if phase == .active {
            guard suspendedForScene else { return }
            suspendedForScene = false
            let shouldResume = resumeWhenActive
            resumeWhenActive = false
            if shouldResume, errorMessage == nil { player?.play() }
        } else {
            // Preserve the first transition's real native state across
            // active -> inactive -> background. A user-paused file stays paused.
            if !suspendedForScene { resumeWhenActive = player?.state == .playing }
            suspendedForScene = true
            player?.pause()
        }
    }

    func togglePlayback() {
        guard let player, !stopped, !suspendedForScene, errorMessage == nil else { return }
        if hasEnded {
            load()
        } else if isPlaying {
            player.pause()
        } else {
            player.play()
        }
    }

    func seek(_ seconds: Int32) {
        guard let player, !stopped, errorMessage == nil, !isWaiting else { return }
        if seconds > 0 { player.jumpForward(seconds) }
        else { player.jumpBackward(-seconds) }
    }

    func selectAudio(_ id: Int32) {
        guard let player, audioTracks.contains(where: { $0.id == id }) else { return }
        player.currentAudioTrackIndex = id
        selectedAudioID = id
    }

    func selectSubtitle(_ id: Int32) {
        guard let player, id == -1 || subtitleTracks.contains(where: { $0.id == id }) else { return }
        player.currentVideoSubTitleIndex = id
        selectedSubtitleID = id
    }

    nonisolated func mediaPlayerStateChanged(_ notification: Notification) {
        let source = notification.object.map { ObjectIdentifier($0 as AnyObject) }
        Task { @MainActor [weak self] in
            guard let self, let player = self.player, !self.stopped,
                  source == nil || source == ObjectIdentifier(player) else { return }
            self.readState()
        }
    }

    nonisolated func mediaPlayerTimeChanged(_ notification: Notification) {
        let source = notification.object.map { ObjectIdentifier($0 as AnyObject) }
        Task { @MainActor [weak self] in
            guard let self, let player = self.player, !self.stopped,
                  source == nil || source == ObjectIdentifier(player) else { return }
            let now = ProcessInfo.processInfo.systemUptime
            guard now - self.lastTimeUpdate >= 0.5 else { return }
            self.lastTimeUpdate = now
            let seconds = max(0, Int(player.time.intValue) / 1000)
            if self.elapsedSeconds != seconds { self.elapsedSeconds = seconds }
        }
    }

    private func load() {
        generation += 1
        let expected = generation
        startupTask?.cancel()
        startupTask = nil
        retirePlayer()
        errorMessage = nil
        isWaiting = true
        isPlaying = false
        hasEnded = false
        stateText = "Подготовка"
        elapsedSeconds = 0
        audioTracks = []
        subtitleTracks = []
        selectedAudioID = -1
        selectedSubtitleID = -1
        lastTimeUpdate = 0

        let url = playback.url
        guard let drawable,
              url.isFileURL, url.host == nil || url.host?.isEmpty == true,
              let values = try? url.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey]),
              values.isRegularFile == true, values.isSymbolicLink != true,
              FileManager.default.isReadableFile(atPath: url.path) else {
            fail("Файла больше нет в кэше. Вернись к загрузкам и скачай его снова.", generation: expected)
            return
        }
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .moviePlayback)
            try AVAudioSession.sharedInstance().setActive(true)
        } catch {
            fail("Не удалось подготовить звук. Повтори попытку или вернись к загрузкам.", generation: expected)
            return
        }

        let value = VLCMediaPlayer(options: [])
        value.delegate = self
        value.drawable = drawable
        value.media = VLCMedia(url: url)
        player = value
        if suspendedForScene {
            value.pause()
            isWaiting = false
            stateText = "Приостановлено"
        } else { value.play() }
        startupTask = Task { @MainActor [weak self] in
            do { try await Task.sleep(for: .seconds(60)) } catch { return }
            guard let self, self.generation == expected, !self.stopped, self.isWaiting else { return }
            self.fail("Этот файл не запустился вовремя. Повтори попытку или выбери файл с другим кодеком.", generation: expected)
        }
    }

    private func readState() {
        guard let player else { return }
        switch player.state {
        case .playing:
            guard !suspendedForScene else {
                player.pause()
                isPlaying = false
                isWaiting = false
                stateText = "Приостановлено"
                return
            }
            isPlaying = true
            isWaiting = false
            hasEnded = false
            stateText = "Воспроизводится"
            startupTask?.cancel()
            startupTask = nil
        case .paused:
            isPlaying = false
            isWaiting = false
            stateText = "Приостановлено"
            startupTask?.cancel()
            startupTask = nil
        case .opening, .buffering:
            isWaiting = true
            stateText = "Подготовка"
        case .ended:
            isPlaying = false
            isWaiting = false
            hasEnded = true
            stateText = "Просмотр завершён"
            startupTask?.cancel()
            startupTask = nil
        case .error:
            fail("Не удалось воспроизвести файл. Его кодек или параметры могут не поддерживаться приставкой.", generation: generation)
            return
        case .stopped:
            isPlaying = false
        default: break
        }
        readTracks(player)
    }

    private func readTracks(_ player: VLCMediaPlayer) {
        let audio = tracks(names: player.audioTrackNames, indexes: player.audioTrackIndexes, subtitles: false)
        var subtitles = tracks(names: player.videoSubTitlesNames, indexes: player.videoSubTitlesIndexes, subtitles: true)
        if !subtitles.contains(where: { $0.id == -1 }) {
            subtitles.insert(TorrentVLCTrack(id: -1, title: "Выключены"), at: 0)
        }
        if audio != audioTracks { audioTracks = audio }
        if subtitles != subtitleTracks { subtitleTracks = subtitles }
        if selectedAudioID != player.currentAudioTrackIndex { selectedAudioID = player.currentAudioTrackIndex }
        if selectedSubtitleID != player.currentVideoSubTitleIndex { selectedSubtitleID = player.currentVideoSubTitleIndex }
    }

    private func tracks(names: [Any], indexes: [Any], subtitles: Bool) -> [TorrentVLCTrack] {
        var result: [TorrentVLCTrack] = []
        var seen = Set<Int32>()
        for (offset, rawIndex) in indexes.prefix(128).enumerated() {
            guard let value = rawIndex as? NSNumber else { continue }
            let id = value.int32Value
            guard (id >= 0 || subtitles && id == -1), seen.insert(id).inserted else { continue }
            let rawName = offset < names.count ? names[offset] as? String : nil
            let name = rawName?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
            result.append(TorrentVLCTrack(id: id,
                title: id == -1 ? "Выключены" : name.isEmpty ? "Дорожка \(offset + 1)" : String(name.prefix(300))))
        }
        return result
    }

    private func fail(_ message: String, generation expected: Int) {
        guard generation == expected, !stopped else { return }
        generation += 1
        startupTask?.cancel()
        startupTask = nil
        retirePlayer()
        isPlaying = false
        isWaiting = false
        stateText = "Ошибка воспроизведения"
        errorMessage = message
    }

    private func retirePlayer() {
        guard let old = player else { return }
        player = nil
        old.delegate = nil
        old.drawable = nil
        let operation = TorrentVLCStopOperation(old)
        DispatchQueue.global(qos: .userInitiated).async { operation.run() }
    }
}

@MainActor
private struct TorrentVLCSurface: UIViewRepresentable {
    @ObservedObject var controller: TorrentVLCController

    func makeUIView(context: Context) -> UIView {
        let view = UIView()
        view.backgroundColor = .black
        view.isAccessibilityElement = true
        view.accessibilityIdentifier = "torrent-vlc-state"
        view.accessibilityLabel = controller.stateText
        controller.attach(view)
        return view
    }

    func updateUIView(_ view: UIView, context: Context) {
        view.accessibilityLabel = controller.stateText
    }
}

@MainActor
struct TorrentVLCPlayer: View {
    let playback: TorrentLocalPlayback
    @Environment(\.dismiss) private var dismiss
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @StateObject private var controller: TorrentVLCController
    @State private var controlsVisible = true
    @State private var hideTask: Task<Void, Never>?
    @State private var trackMenu: TrackMenu?
    @State private var isClosing = false
    @FocusState private var focus: Control?

    private enum Control: Hashable { case video, backward, toggle, forward, audio, subtitles }
    private enum TrackMenu: String, Identifiable {
        case audio, subtitles
        var id: String { rawValue }
        var title: String { self == .audio ? "Аудиодорожка" : "Субтитры" }
    }

    init(playback: TorrentLocalPlayback) {
        self.playback = playback
        _controller = StateObject(wrappedValue: TorrentVLCController(playback: playback))
    }

    var body: some View {
        ZStack(alignment: .bottom) {
            TorrentVLCSurface(controller: controller).ignoresSafeArea()
                .focusable(!controlsVisible && controller.errorMessage == nil)
                .focused($focus, .video)
                .onTapGesture { revealControls(focusToggle: true) }
                .onMoveCommand { direction in
                    guard !controlsVisible else { return }
                    if direction == .left { controller.seek(-10) }
                    else if direction == .right { controller.seek(10) }
                    revealControls(focusToggle: true)
                }

            if controlsVisible && controller.errorMessage == nil {
                VStack(alignment: .leading, spacing: 30) {
                    Text(playback.title).font(.system(size: 32, weight: .semibold))
                        .lineLimit(2).fixedSize(horizontal: false, vertical: true)
                    HStack(spacing: 28) {
                        Text(playbackTime(Double(controller.elapsedSeconds)))
                            .font(.system(size: 24, weight: .medium, design: .monospaced))
                            .frame(minWidth: 130, alignment: .leading)
                        Button { controller.seek(-10); revealControls() } label: {
                            Label("10 с", systemImage: "gobackward.10")
                        }.focused($focus, .backward).accessibilityIdentifier("torrent-vlc-backward")
                        Button { controller.togglePlayback(); revealControls() } label: {
                            Label(controller.hasEnded ? "Заново" : controller.isPlaying ? "Пауза" : "Смотреть",
                                systemImage: controller.isPlaying ? "pause.fill" : "play.fill")
                        }.focused($focus, .toggle).accessibilityIdentifier("torrent-vlc-toggle")
                        Button { controller.seek(10); revealControls() } label: {
                            Label("10 с", systemImage: "goforward.10")
                        }.focused($focus, .forward).accessibilityIdentifier("torrent-vlc-forward")
                        Spacer(minLength: 12)
                        Button { openTracks(.audio) } label: { Label("Аудио", systemImage: "waveform") }
                            .disabled(controller.audioTracks.isEmpty).focused($focus, .audio)
                            .accessibilityIdentifier("torrent-vlc-audio")
                        Button { openTracks(.subtitles) } label: { Label("Субтитры", systemImage: "captions.bubble") }
                            .focused($focus, .subtitles).accessibilityIdentifier("torrent-vlc-subtitles")
                    }.font(.system(size: 23)).focusSection()
                }
                .padding(32).asanPanel().padding(.horizontal, 60).padding(.bottom, 44)
                .transition(.opacity)
            }

            if controller.isWaiting && controller.errorMessage == nil {
                VStack(spacing: 22) {
                    ProgressView("Открываем скачанный фильм…")
                    Text("Можно вернуться кнопкой «Назад»").font(.callout).foregroundStyle(.secondary)
                }.padding(36).asanPanel().frame(maxWidth: .infinity, maxHeight: .infinity)
                    .allowsHitTesting(false).accessibilityIdentifier("torrent-vlc-loading")
            }

            if let message = controller.errorMessage {
                VStack(spacing: 28) {
                    Text("Не удалось открыть фильм").font(.largeTitle.bold())
                    Text(message).font(.title3).multilineTextAlignment(.center).frame(maxWidth: 1000)
                        .accessibilityIdentifier("torrent-vlc-error")
                    HStack(spacing: 28) {
                        Button("Повторить") { controller.retry(); revealControls(focusToggle: true) }
                            .accessibilityIdentifier("torrent-vlc-retry")
                        Button("Назад к загрузкам") { close() }.accessibilityIdentifier("torrent-vlc-back")
                    }.focusSection()
                }
                .padding(60).frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(.black.opacity(0.95)).onExitCommand { close() }
            }
        }
        .background(.black)
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("torrent-local-player")
        .animation(reduceMotion || AsanEffects.isPreviewReduced ? nil : .easeOut(duration: 0.18), value: controlsVisible)
        .onExitCommand {
            if trackMenu != nil { trackMenu = nil }
            else { close() }
        }
        .onPlayPauseCommand { controller.togglePlayback(); revealControls() }
        .task { controller.start(); revealControls(focusToggle: true) }
        .onChange(of: scenePhase) { phase in controller.updateScenePhase(phase) }
        .onChange(of: controller.isPlaying) { playing in
            if playing { scheduleHide() }
            else { hideTask?.cancel(); controlsVisible = true }
        }
        .sheet(item: $trackMenu, onDismiss: { revealControls(focusToggle: true) }) { menu in
            NavigationStack {
                List(menu == .audio ? controller.audioTracks : controller.subtitleTracks) { track in
                    Button {
                        if menu == .audio { controller.selectAudio(track.id) }
                        else { controller.selectSubtitle(track.id) }
                        trackMenu = nil
                    } label: {
                        HStack(spacing: 24) {
                            Text(track.title).font(.system(size: 27)).fixedSize(horizontal: false, vertical: true)
                            Spacer()
                            if track.id == (menu == .audio ? controller.selectedAudioID : controller.selectedSubtitleID) {
                                Image(systemName: "checkmark").accessibilityLabel("Выбрано")
                            }
                        }.padding(.vertical, 12)
                    }.accessibilityIdentifier("torrent-vlc-track-\(menu.rawValue)-\(track.id)")
                }
                .navigationTitle(menu.title)
                .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Назад") { trackMenu = nil } } }
                .onExitCommand { trackMenu = nil }
            }
        }
        .onDisappear {
            hideTask?.cancel()
            if trackMenu == nil { controller.stop() }
        }
    }

    private func revealControls(focusToggle: Bool = false) {
        controlsVisible = true
        if focusToggle { focus = .toggle }
        scheduleHide()
    }

    private func scheduleHide() {
        hideTask?.cancel()
        guard controller.isPlaying, trackMenu == nil else { return }
        hideTask = Task { @MainActor in
            do { try await Task.sleep(for: .seconds(5)) } catch { return }
            guard !isClosing, controller.isPlaying, trackMenu == nil, controller.errorMessage == nil else { return }
            controlsVisible = false
            focus = .video
        }
    }

    private func openTracks(_ menu: TrackMenu) {
        hideTask?.cancel()
        trackMenu = menu
    }

    private func close() {
        guard !isClosing else { return }
        isClosing = true
        hideTask?.cancel()
        controller.stop()
        dismiss()
    }
}
