import SwiftUI
import KinoCore
import RezkaKit

@MainActor
struct MediaDetailsView: View {
    let entry: CatalogEntry
    @EnvironmentObject private var model: AppModel
    @EnvironmentObject private var downloads: TorrentDownloadsModel
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var details: RezkaDetails?
    @State private var isLoading = true
    @State private var error: String?
    private enum DetailsSheet: String, Identifiable {
        case playbackOptions, torrents, introSettings
        var id: String { rawValue }
    }
    private enum ActionFocus: Hashable { case watch, local }
    @State private var activeSheet: DetailsSheet?
    @State private var fromStart = false
    @State private var pendingChoice: PlaybackChoice?
    @State private var posterAppeared = false
    @FocusState private var actionFocus: ActionFocus?

    private var media: MediaItem {
        var media = details?.media ?? entry.media
        if let seasons = details?.seasons, !seasons.isEmpty { media.seasons = seasons }
        return media
    }
    private var displayedEntry: CatalogEntry {
        CatalogEntry(providerID: entry.providerID, providerName: entry.providerName, media: media)
    }
    private var viewing: MediaViewingStatus {
        MediaViewingStatus(media: media, reference: entry.reference, history: model.library.history)
    }
    private var preferredEpisodeID: String? {
        viewing.resumable?.episodeID ?? viewing.nextKnownEpisode?.id ?? viewing.latest?.episodeID
    }
    private var localCopy: TorrentDownload? {
        downloads.availableCompletedCopy(for: entry.reference, episodeID: preferredEpisodeID)
    }
    private var localResumePosition: Double? {
        guard let progress = viewing.resumable, progress.episodeID == preferredEpisodeID else { return nil }
        return progress.position
    }
    private var canResumeLocal: Bool {
        if let position = localResumePosition, position > 5 { return true }
        guard let copy = localCopy, copy.localPosition > 0 else { return false }
        return copy.localDuration <= 0 || copy.localPosition / copy.localDuration < 0.95
    }
    private var watchTitle: String {
        if localCopy != nil { return "Онлайн" }
        if viewing.resumable != nil { return "Продолжить" }
        return viewing.nextKnownEpisode == nil ? "Смотреть" : "Следующая серия"
    }
    private var reducedEffects: Bool { reduceMotion || AsanEffects.isPreviewReduced }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 44) {
                HStack(alignment: .top, spacing: 58) {
                    VStack(alignment: .leading, spacing: 18) {
                        PosterArtwork(item: media).frame(width: 270, height: 405)
                            .shadow(color: .black.opacity(0.30), radius: 14, y: 10)
                            .opacity(reducedEffects || posterAppeared ? 1 : 0)
                            .offset(y: reducedEffects || posterAppeared ? 0 : 8)
                        if localCopy != nil { MediaStateBadge(title: "Скачано", symbol: "arrow.down.circle.fill") }
                        else if viewing.nextKnownEpisode != nil { MediaStateBadge(title: "Новая серия", symbol: "sparkle") }
                        else if viewing.isWatched {
                            MediaStateBadge(title: media.kind == .series ? "Серия просмотрена" : "Просмотрено", symbol: "checkmark")
                        }
                    }
                    VStack(alignment: .leading, spacing: 22) {
                        Text(entry.providerName.uppercased())
                            .font(.system(size: 16, weight: .semibold)).tracking(3)
                            .foregroundStyle(Theme.accent)
                        Text(media.title).font(.system(size: 48, weight: .bold))
                            .foregroundStyle(Theme.text).fixedSize(horizontal: false, vertical: true)
                            .accessibilityIdentifier("details-title")
                        if let original = media.originalTitle, original != media.title {
                            Text(original).font(.system(size: 25)).foregroundStyle(Theme.secondaryText)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                        HStack(spacing: 16) {
                            if let rating = media.displayRating {
                                Label(String(format: "%.1f", rating), systemImage: "star.fill")
                                    .font(.system(size: 22, weight: .semibold)).foregroundStyle(Theme.accent)
                            }
                            Text(descriptiveMetadata).font(.system(size: 23)).foregroundStyle(Theme.secondaryText)
                        }
                        if let genre = media.primaryGenre {
                            Text(genre).font(.system(size: 23)).foregroundStyle(Theme.secondaryText)
                        }
                        primaryActions.padding(.top, 8)
                        if let copy = localCopy, media.kind == .series {
                            Label(copy.mediaAssociation?.resolvedEpisode?.title ?? copy.fileName ?? copy.title, systemImage: "internaldrive")
                                .font(.system(size: 19)).foregroundStyle(Theme.secondaryText)
                                .lineLimit(2).accessibilityIdentifier("details-local-file")
                        }
                        if let progress = viewing.resumable {
                            VStack(alignment: .leading, spacing: 12) {
                                HStack(spacing: 20) {
                                    Text("Остановились на \(playbackTime(progress.position))")
                                        .font(.system(size: 21)).foregroundStyle(Theme.secondaryText)
                                    Button("С начала") {
                                        if let copy = localCopy { playLocal(copy, fromStart: true) }
                                        else { fromStart = true; activeSheet = .playbackOptions }
                                    }
                                    .disabled(localCopy == nil && details == nil).accessibilityIdentifier("details-from-start")
                                }
                                ProgressView(value: progress.fraction).tint(Theme.accent).frame(maxWidth: 520)
                                    .accessibilityLabel("Просмотрено")
                                    .accessibilityValue("\(Int(progress.fraction * 100)) процентов")
                            }.focusSection()
                        } else if let next = viewing.nextKnownEpisode {
                            Label(next.title, systemImage: "play.rectangle")
                                .font(.system(size: 21)).foregroundStyle(Theme.secondaryText)
                        }
                        secondaryActions.padding(.top, 8)
                        loadStatus
                    }.frame(maxWidth: .infinity, alignment: .leading)
                }
                VStack(alignment: .leading, spacing: 18) {
                    Text(media.kind == .movie ? "О фильме" : "О сериале")
                        .font(.system(size: 27, weight: .semibold)).foregroundStyle(Theme.text)
                    Text(media.overview ?? "Описание пока не загружено.")
                        .font(.system(size: 25)).foregroundStyle(Theme.secondaryText).lineSpacing(6)
                        .fixedSize(horizontal: false, vertical: true)
                }.frame(maxWidth: 1330, alignment: .leading)
            }.padding(.horizontal, 64).padding(.top, 50).padding(.bottom, 80)
        }
        .background { MediaAtmosphereBackdrop(media: media) }
        .accessibilityIdentifier("media-details")
        .onAppear {
            guard !posterAppeared else { return }
            withAnimation(reducedEffects ? nil : .easeOut(duration: 0.24)) { posterAppeared = true }
        }
        .task(id: entry.id) { await load() }
        .task { await downloads.refresh() }
        .sheet(item: $activeSheet, onDismiss: startSelectedPlayback) { sheet in
            switch sheet {
            case .playbackOptions:
                if let details {
                    PlaybackOptionsScreen(details: details, fromStart: fromStart, preferredEpisodeID: preferredEpisodeID) { choice in
                        pendingChoice = choice
                        activeSheet = nil
                    }.environmentObject(model)
                }
            case .torrents: torrentSearch
            case .introSettings: IntroSkipSettingsSheet(entry: displayedEntry).environmentObject(model)
            }
        }
    }

    private var descriptiveMetadata: String {
        var parts = [media.kind == .movie ? "Фильм" : "Сериал"]
        if let year = media.year { parts.append(String(year)) }
        if let duration = media.durationMinutes, duration > 0 { parts.append("\(duration) мин") }
        return parts.joined(separator: "  ·  ")
    }

    private var primaryActions: some View {
        HStack(spacing: 22) {
            if let copy = localCopy {
                Button { playLocal(copy) } label: {
                    Label(canResumeLocal ? "Продолжить скачанное" : "Смотреть скачанное", systemImage: "play.fill")
                }
                .buttonStyle(.borderedProminent).focused($actionFocus, equals: .local)
                .disabled(downloads.isBusy).accessibilityIdentifier("details-play-local")
            }
            Button { fromStart = false; activeSheet = .playbackOptions } label: {
                Label(watchTitle, systemImage: "play.fill")
            }
            .buttonStyle(.borderedProminent).focused($actionFocus, equals: .watch)
            .disabled(details == nil || details?.isAvailable != true || details?.translators.isEmpty == true)
            .accessibilityIdentifier("details-watch")
            Button { activeSheet = .torrents } label: { Label("Торрент", systemImage: "arrow.down.circle") }
                .accessibilityIdentifier("details-torrent")
        }.focusSection()
    }

    private var secondaryActions: some View {
        HStack(spacing: 22) {
            Button { Task { await model.toggleFavorite(displayedEntry) } } label: {
                Label(model.isFavorite(displayedEntry) ? "В избранном" : "В избранное", systemImage: model.isFavorite(displayedEntry) ? "heart.fill" : "heart")
            }
            Button { Task { await model.toggleWatchlist(displayedEntry) } } label: {
                Label(model.isWatchlisted(displayedEntry) ? "В списке" : "Смотреть позже", systemImage: model.isWatchlisted(displayedEntry) ? "bookmark.fill" : "bookmark")
            }
            if media.kind == .series {
                Button { activeSheet = .introSettings } label: {
                    Label(introSettingTitle, systemImage: "forward.end")
                }.accessibilityIdentifier("details-intro-settings")
            }
        }.focusSection()
    }

    private var introSettingTitle: String {
        let duration = model.introSkipDuration(for: entry.reference)
        return duration > 0 ? "Заставка · \(Int(duration)) с" : "Пропуск заставки"
    }

    @ViewBuilder private var loadStatus: some View {
        if isLoading { ProgressView("Загружаем карточку…").tint(Theme.accent) }
        if let error {
            Text(error).font(.system(size: 21)).foregroundStyle(Theme.secondaryText)
            Button("Повторить") { Task { await load() } }
        }
        if let details, !details.isAvailable || details.translators.isEmpty {
            Text("Для этой страницы пока нет доступного видео или озвучек.")
                .font(.system(size: 21)).foregroundStyle(Theme.secondaryText)
        }
    }

    @ViewBuilder private var torrentSearch: some View {
        #if DEBUG && targetEnvironment(simulator)
        if PreviewSupport.scene != nil {
            TorrentSearchScreen(media: media, reference: entry.reference, preferredEpisodeID: preferredEpisodeID,
                service: PreviewTorrentSearchService(scene: PreviewSupport.scene?.rawValue))
        } else {
            TorrentSearchScreen(media: media, reference: entry.reference, preferredEpisodeID: preferredEpisodeID)
        }
        #else
        TorrentSearchScreen(media: media, reference: entry.reference, preferredEpisodeID: preferredEpisodeID)
        #endif
    }

    private func playLocal(_ copy: TorrentDownload, fromStart: Bool = false) {
        Task {
            downloads.clearError()
            await downloads.play(id: copy.id, resumePosition: fromStart ? 0 : localResumePosition)
            if let message = downloads.errorMessage { error = message; downloads.clearError() }
        }
    }

    private func load() async {
        isLoading = true; error = nil
        defer { isLoading = false }
        do {
            details = try await model.details(for: entry)
            try Task.checkCancellation()
            if activeSheet == nil { actionFocus = localCopy == nil ? .watch : .local }
            #if DEBUG && targetEnvironment(simulator)
            if PreviewSupport.scene == .voices || PreviewSupport.scene == .qualities { activeSheet = .playbackOptions }
            if let scene = PreviewSupport.scene,
               [.torrentSearch, .torrentSearchEmpty, .torrentSearchError].contains(scene) { activeSheet = .torrents }
            if PreviewSupport.scene == .introSettings { activeSheet = .introSettings }
            #endif
        } catch is CancellationError { }
        catch { self.error = model.friendly(error) }
    }

    private func startSelectedPlayback() {
        guard let choice = pendingChoice else { return }
        pendingChoice = nil
        do { try model.beginPlayback(choice.prepared, streamID: choice.streamID) }
        catch { self.error = model.friendly(error) }
    }
}
