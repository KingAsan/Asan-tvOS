import SwiftUI
import KinoCore
import RezkaKit

@MainActor
struct MediaDetailsView: View {
    let entry: CatalogEntry
    @EnvironmentObject private var model: AppModel
    @State private var details: RezkaDetails?
    @State private var isLoading = true
    @State private var error: String?
    private enum DetailsSheet: String, Identifiable {
        case playbackOptions, torrents
        var id: String { rawValue }
    }
    @State private var activeSheet: DetailsSheet?
    @State private var fromStart = false
    @State private var pendingChoice: PlaybackChoice?
    @FocusState private var watchFocused: Bool

    private var media: MediaItem { details?.media ?? entry.media }
    private var displayedEntry: CatalogEntry { CatalogEntry(providerID: AppModel.providerID, providerName: "Rezka", media: media) }
    private var progress: WatchProgress? {
        model.library.history.filter { $0.reference == entry.reference }.max { $0.updatedAt < $1.updatedAt }
    }

    var body: some View {
        ScrollView {
            HStack(alignment: .top, spacing: 44) {
                PosterArtwork(item: media).frame(width: 255, height: 382)
                VStack(alignment: .leading, spacing: 24) {
                    Text(media.title).font(.system(size: 42, weight: .bold)).fixedSize(horizontal: false, vertical: true)
                    if let original = media.originalTitle, original != media.title {
                        Text(original).font(.title3).foregroundStyle(.secondary)
                    }
                    Text(media.metadataLine).font(.callout).foregroundStyle(.secondary)
                    if let genre = media.primaryGenre {
                        Text(genre).font(.callout).foregroundStyle(.secondary)
                    }
                    HStack(spacing: 24) {
                        Button {
                            fromStart = false
                            activeSheet = .playbackOptions
                        } label: {
                            Label(progress?.isCompleted == false ? "Продолжить" : "Смотреть", systemImage: "play.fill")
                        }
                        .buttonStyle(.borderedProminent).focused($watchFocused)
                        .disabled(details == nil || details?.isAvailable != true || details?.translators.isEmpty == true)
                        Button {
                            activeSheet = .torrents
                        } label: {
                            Label("Торрент", systemImage: "arrow.down.circle")
                        }
                        .accessibilityIdentifier("details-torrent")
                        if let progress, !progress.isCompleted, progress.position > 5 {
                            Button("С начала") { fromStart = true; activeSheet = .playbackOptions }.disabled(details == nil)
                        }
                    }.padding(.vertical, 8).focusSection()
                    if let progress, !progress.isCompleted {
                        Text("Остановились на \(playbackTime(progress.position))").font(.callout).foregroundStyle(.secondary)
                    }
                    Text(media.overview ?? "Описание пока не загружено.")
                        .font(.system(size: 24)).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                    HStack(spacing: 24) {
                        Button { Task { await model.toggleFavorite(displayedEntry) } } label: {
                            Label(model.isFavorite(displayedEntry) ? "В избранном" : "В избранное", systemImage: model.isFavorite(displayedEntry) ? "heart.fill" : "heart")
                        }
                        Button { Task { await model.toggleWatchlist(displayedEntry) } } label: {
                            Label(model.isWatchlisted(displayedEntry) ? "В списке" : "Смотреть позже", systemImage: model.isWatchlisted(displayedEntry) ? "bookmark.fill" : "bookmark")
                        }
                    }.focusSection()
                    if isLoading { ProgressView("Загружаем карточку…") }
                    if let error {
                        Text(error).font(.callout).foregroundStyle(.secondary)
                        Button("Повторить") { Task { await load() } }
                    }
                    if let details, !details.isAvailable || details.translators.isEmpty {
                        Text("Для этой страницы пока нет доступного видео или озвучек.").font(.callout).foregroundStyle(.secondary)
                    }
                }.frame(maxWidth: .infinity, alignment: .leading).padding(32).asanPanel()
            }.padding(50)
        }
        .background { AsanBackdrop() }
        .task(id: entry.id) { await load() }
        .sheet(item: $activeSheet, onDismiss: startSelectedPlayback) { sheet in
            switch sheet {
            case .playbackOptions:
                if let details {
                    PlaybackOptionsScreen(details: details, fromStart: fromStart, preferredEpisodeID: progress?.episodeID) { choice in
                        pendingChoice = choice
                        activeSheet = nil
                    }.environmentObject(model)
                }
            case .torrents:
                torrentSearch
            }
        }
    }

    @ViewBuilder private var torrentSearch: some View {
        #if DEBUG && targetEnvironment(simulator)
        if PreviewSupport.scene != nil {
            TorrentSearchScreen(media: media, service: PreviewTorrentSearchService(scene: PreviewSupport.scene?.rawValue))
        } else {
            TorrentSearchScreen(media: media)
        }
        #else
        TorrentSearchScreen(media: media)
        #endif
    }

    private func load() async {
        isLoading = true; error = nil
        defer { isLoading = false }
        do {
            details = try await model.details(for: entry)
            try Task.checkCancellation()
            if activeSheet == nil { watchFocused = true }
            #if DEBUG && targetEnvironment(simulator)
            if PreviewSupport.scene == .voices || PreviewSupport.scene == .qualities { activeSheet = .playbackOptions }
            if let scene = PreviewSupport.scene,
               [.torrentSearch, .torrentSearchEmpty, .torrentSearchError].contains(scene) { activeSheet = .torrents }
            #endif
        } catch is CancellationError { }
        catch { self.error = model.friendly(error) }
    }

    private func startSelectedPlayback() {
        guard let choice = pendingChoice else { return }
        pendingChoice = nil
        do { try model.beginPlayback(choice.prepared, streamID: choice.streamID) }
        catch { self.error = model.friendly(error) }
    }
}
