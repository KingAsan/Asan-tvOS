import SwiftUI
import KinoCore

struct TorrentDiscoveryRequest: Identifiable {
    let id = UUID()
    let entry: CatalogEntry
    let episodeID: String?
}

/// An explicit, per-series preference. No guessed markers or automatic seeking.
@MainActor
struct IntroSkipSettingsSheet: View {
    let entry: CatalogEntry
    @EnvironmentObject private var model: AppModel
    @Environment(\.dismiss) private var dismiss
    @State private var seconds = 0.0
    @State private var saving = false
    private let choices: [Double] = [0, 15, 30, 45, 60, 75, 90, 120, 150, 180]

    var body: some View {
        VStack(spacing: 0) {
            VStack(alignment: .leading, spacing: 12) {
                Text("Пропуск заставки").font(.title3.bold()).foregroundStyle(.primary)
                    .fixedSize(horizontal: false, vertical: true)
                Text(entry.media.title).font(.headline)
                    .fixedSize(horizontal: false, vertical: true)
                HStack {
                    Button("Отмена") { dismiss() }
                    Spacer()
                    Button("Готово") {
                        saving = true
                        Task {
                            if await model.setIntroSkipDuration(seconds, for: entry.reference) { dismiss() }
                            saving = false
                        }
                    }.disabled(saving).accessibilityIdentifier("intro-duration-save")
                }.focusSection()
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding()
            Divider()
            List {
                Section {
                    Text(seconds == 0 ? "Выключен" : "Длительность: \(Int(seconds)) сек.")
                        .accessibilityIdentifier("intro-duration-value")
                    Text("Задай длительность заставки. В плеере появится кнопка пропуска к этой отметке.")
                        .font(.callout).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                }
                Section {
                    HStack(spacing: 24) {
                        Button("−5 сек.") { seconds = max(0, seconds - 5) }.disabled(seconds <= 0)
                        Button("+5 сек.") { seconds = min(600, seconds + 5) }.disabled(seconds >= 600)
                    }
                    ForEach(choices, id: \.self) { value in
                        Button { seconds = value } label: {
                            HStack {
                                Text(value == 0 ? "Выключить" : "\(Int(value)) секунд")
                                Spacer()
                                if seconds == value { Image(systemName: "checkmark") }
                            }
                        }.accessibilityIdentifier("intro-duration-\(Int(value))")
                    }
                }
            }
        }
        .background { AsanBackdrop() }
        .onExitCommand { dismiss() }
        .task { seconds = model.introSkipDuration(for: entry.reference) }
    }
}
