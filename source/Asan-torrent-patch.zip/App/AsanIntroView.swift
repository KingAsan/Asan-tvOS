import SwiftUI
import AVFoundation
import Combine
import UIKit

/// A short, bundled, silent introduction after the system's static launch screen.
/// The app owns presentation once per cold launch; catalog startup runs behind it.
@MainActor
struct AsanIntroView: View {
    let onFinished: () -> Void
    @StateObject private var controller = AsanIntroController()
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.scenePhase) private var scenePhase
    @FocusState private var skipFocused: Bool
    @State private var notified = false
    @State private var surfaceIsReady = false
    #if DEBUG && targetEnvironment(simulator)
    @EnvironmentObject private var playbackProbe: PreviewIntroPlaybackProbe
    #endif

    private var staticPresentation: Bool { reduceMotion || AsanEffects.isPreviewReduced }

    var body: some View {
        ZStack {
            Theme.background
            if staticPresentation {
                VStack(spacing: 22) {
                    Image("AsanHeart").resizable().scaledToFit().frame(width: 128, height: 128)
                    Text("Asan").font(.system(size: 48, weight: .semibold)).foregroundStyle(Theme.accent)
                }
                .accessibilityIdentifier("asan-intro-static")
                .accessibilityHidden(true)
            } else {
                AsanIntroVideo(player: controller.player, onReady: controller.frameBecameReady) { size, attached in
                    surfaceIsReady = attached && size.width.isFinite && size.height.isFinite && size.width > 0 && size.height > 0
                    #if DEBUG && targetEnvironment(simulator)
                    playbackProbe.recordSurface(size: size, attached: attached)
                    #endif
                }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .accessibilityHidden(true)
                if !controller.hasVideoFrame {
                    Image("AsanHeart").resizable().scaledToFit().frame(width: 128, height: 128)
                        .allowsHitTesting(false).accessibilityHidden(true)
                }
            }

            Button { controller.finish() } label: {
                Color.clear.contentShape(Rectangle()).frame(maxWidth: .infinity, maxHeight: .infinity)
            }
            .buttonStyle(AsanIntroSkipStyle())
            .focusEffectDisabled()
            .focused($skipFocused)
            .accessibilityLabel("Пропустить заставку Asan")
            .accessibilityValue(controller.state)
            .accessibilityIdentifier("asan-intro-skip")

            if !staticPresentation {
                VStack {
                    Spacer()
                    Text("Нажми для пропуска")
                        .font(.system(size: 18, weight: .medium))
                        .foregroundStyle(.white.opacity(0.55))
                        .padding(.bottom, 48)
                }
                .allowsHitTesting(false)
                .accessibilityHidden(true)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .ignoresSafeArea()
        .accessibilityElement(children: .contain)
        .accessibilityLabel("Заставка Asan")
        .accessibilityValue(controller.state)
        .accessibilityIdentifier("asan-intro-overlay")
        .onExitCommand { controller.finish() }
        .onPlayPauseCommand { controller.finish() }
        .task(id: scenePhase) {
            guard scenePhase == .active else { return }
            beginWhenActive(scenePhase)
            // A missing UIKit surface must never leave the launch screen up.
            try? await Task.sleep(nanoseconds: 12_000_000_000)
            guard !Task.isCancelled else { return }
            controller.finish(reason: "presentation-timeout")
        }
        .onChange(of: surfaceIsReady) { _, ready in
            if ready { beginWhenActive(scenePhase) }
        }
        .onChange(of: controller.isFinished) { _, finished in
            guard finished, !notified else { return }
            notified = true
            onFinished()
        }
        .onChange(of: scenePhase) { _, phase in
            // Never leave the decoder rendering behind another app or replay
            // the introduction when this scene returns to the foreground.
            if phase == .active { beginWhenActive(phase) }
            else { controller.finishIfStarted() }
        }
        .onChange(of: staticPresentation) { _, reduced in
            if reduced { controller.finish(reason: "reduced-motion") }
        }
        .onDisappear { controller.stop() }
    }

    private func beginWhenActive(_ phase: ScenePhase) {
        // Cold-launch tasks can run before tvOS presents an active scene. Do
        // not consume the local movie's startup deadline behind SpringBoard.
        guard phase == .active, !notified, staticPresentation || surfaceIsReady else { return }
        skipFocused = true
        #if DEBUG && targetEnvironment(simulator)
        controller.playbackProbe = playbackProbe
        #endif
        controller.start(reducedMotion: staticPresentation)
    }
}

private struct AsanIntroSkipStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View { configuration.label }
}

@MainActor
private final class AsanIntroController: ObservableObject {
    let player = AVPlayer()
    @Published private(set) var state = "loading"
    @Published private(set) var isFinished = false
    private var statusObservation: NSKeyValueObservation?
    private var timeObservation: NSKeyValueObservation?
    private var notifications: [NSObjectProtocol] = []
    private var deadline: Task<Void, Never>?
    private var startupDeadline: Task<Void, Never>?
    private var started = false
    private var stopped = false
    @Published private(set) var hasVideoFrame = false
    #if DEBUG && targetEnvironment(simulator)
    weak var playbackProbe: PreviewIntroPlaybackProbe?
    #endif

    func start(reducedMotion: Bool) {
        guard !started, !stopped, !isFinished else { return }
        started = true
        if reducedMotion {
            state = "static"
            deadline = Task { [weak self] in
                try? await Task.sleep(nanoseconds: 350_000_000)
                guard !Task.isCancelled else { return }
                self?.finish(reason: "reduced-motion")
            }
            return
        }
        guard let url = Bundle.main.url(forResource: "AsanIntro", withExtension: "mp4"), url.isFileURL else {
            fail(reason: "missing-asset")
            return
        }
        // No audio-session changes: the intro has no audio track and is muted
        // defensively, so it cannot interrupt other audio or expose credentials.
        player.isMuted = true
        player.actionAtItemEnd = .pause
        let item = AVPlayerItem(url: url)
        statusObservation = item.observe(\.status, options: [.initial, .new]) { [weak self, weak item] _, _ in
            Task { @MainActor [weak self, weak item] in
                guard let self, let item, !self.stopped, !self.isFinished else { return }
                switch item.status {
                case .readyToPlay:
                    self.updatePlaybackState()
                    self.player.play()
                case .failed: self.fail(reason: "item-failed")
                case .unknown: break
                @unknown default: self.fail(reason: "unknown-item-status")
                }
            }
        }
        timeObservation = player.observe(\.timeControlStatus, options: [.initial, .new]) { [weak self] _, _ in
            Task { @MainActor [weak self] in self?.updatePlaybackState() }
        }
        notifications.append(NotificationCenter.default.addObserver(
            forName: .AVPlayerItemDidPlayToEndTime, object: item, queue: .main
        ) { [weak self, weak item] notification in
            #if DEBUG && targetEnvironment(simulator)
            let exactItem = (notification.object as? AVPlayerItem) === item
            Task { @MainActor [weak self, weak item] in
                if let self, let item, exactItem, self.player.currentItem === item,
                   !self.stopped, !self.isFinished {
                    // Only this notification may record a natural ending.
                    // Skip, deadline, error and stop never record one.
                    self.playbackProbe?.recordNaturalEnd()
                }
                self?.finish(reason: "natural-end")
            }
            #else
            Task { @MainActor [weak self] in self?.finish(reason: "natural-end") }
            #endif
        })
        notifications.append(NotificationCenter.default.addObserver(
            forName: .AVPlayerItemFailedToPlayToEndTime, object: item, queue: .main
        ) { [weak self] _ in
            Task { @MainActor [weak self] in self?.fail(reason: "play-to-end-failed") }
        })
        player.replaceCurrentItem(with: item)
        #if DEBUG && targetEnvironment(simulator)
        playbackProbe?.recordStart()
        #endif
        player.play()
        startupDeadline = Task { [weak self] in
            try? await Task.sleep(nanoseconds: 5_000_000_000)
            guard !Task.isCancelled, let self, self.state != "playing", !self.isFinished else { return }
            self.fail(reason: "startup-timeout")
        }
        deadline = Task { [weak self] in
            try? await Task.sleep(nanoseconds: 12_000_000_000)
            guard !Task.isCancelled else { return }
            self?.finish(reason: "absolute-timeout")
        }
    }

    func frameBecameReady() {
        guard !stopped, !isFinished else { return }
        hasVideoFrame = true
        #if DEBUG && targetEnvironment(simulator)
        playbackProbe?.recordFrame()
        #endif
        updatePlaybackState()
    }

    func finishIfStarted() {
        guard started else { return }
        finish(reason: "inactive-scene")
    }

    func finish(reason: String = "user-skip") {
        guard !isFinished else { return }
        #if DEBUG && targetEnvironment(simulator)
        playbackProbe?.recordFinish(reason, itemStatus: player.currentItem?.status.rawValue,
            timeControl: player.timeControlStatus.rawValue, clock: player.currentTime().seconds)
        #endif
        if state != "error" { state = "finished" }
        isFinished = true
        stop()
    }

    func stop() {
        guard !stopped else { return }
        #if DEBUG && targetEnvironment(simulator)
        playbackProbe?.recordFinish("detached", itemStatus: player.currentItem?.status.rawValue,
            timeControl: player.timeControlStatus.rawValue, clock: player.currentTime().seconds)
        #endif
        stopped = true
        deadline?.cancel()
        startupDeadline?.cancel()
        deadline = nil
        startupDeadline = nil
        statusObservation?.invalidate()
        timeObservation?.invalidate()
        statusObservation = nil
        timeObservation = nil
        notifications.forEach { NotificationCenter.default.removeObserver($0) }
        notifications.removeAll()
        player.pause()
        player.replaceCurrentItem(with: nil)
    }

    private func updatePlaybackState() {
        guard !stopped, !isFinished else { return }
        if player.timeControlStatus == .playing && hasVideoFrame {
            state = "playing"
            #if DEBUG && targetEnvironment(simulator)
            playbackProbe?.recordPlaying()
            #endif
            startupDeadline?.cancel()
            startupDeadline = nil
        } else if player.currentItem?.status == .readyToPlay {
            state = "ready"
        } else {
            state = "loading"
        }
    }

    private func fail(reason: String) {
        guard !stopped, !isFinished else { return }
        state = "error"
        finish(reason: reason)
    }
}

private struct AsanIntroVideo: UIViewRepresentable {
    let player: AVPlayer
    let onReady: () -> Void
    let onSurfaceChanged: (CGSize, Bool) -> Void

    func makeUIView(context: Context) -> AsanIntroVideoSurface {
        let view = AsanIntroVideoSurface()
        view.onReady = onReady
        view.onSurfaceChanged = onSurfaceChanged
        view.playerLayer.player = player
        view.reportSurface()
        return view
    }

    func updateUIView(_ view: AsanIntroVideoSurface, context: Context) {
        view.onReady = onReady
        view.onSurfaceChanged = onSurfaceChanged
        if view.playerLayer.player !== player { view.playerLayer.player = player }
        view.reportSurface()
    }

    static func dismantleUIView(_ view: AsanIntroVideoSurface, coordinator: ()) {
        view.detach()
    }
}

private final class AsanIntroVideoSurface: UIView {
    override class var layerClass: AnyClass { AVPlayerLayer.self }
    var playerLayer: AVPlayerLayer { layer as! AVPlayerLayer }
    var onReady: (() -> Void)?
    var onSurfaceChanged: ((CGSize, Bool) -> Void)?
    private var displayObservation: NSKeyValueObservation?
    private var lastSurfaceSize: CGSize?
    private var lastSurfaceAttached = false

    override init(frame: CGRect) {
        super.init(frame: frame)
        configure()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        configure()
    }

    func detach() {
        displayObservation?.invalidate()
        displayObservation = nil
        onReady = nil
        onSurfaceChanged = nil
        playerLayer.player = nil
    }

    override func didMoveToWindow() {
        super.didMoveToWindow()
        reportSurface()
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        reportSurface()
    }

    func reportSurface() {
        guard onSurfaceChanged != nil else { return }
        let size = bounds.size, attached = window != nil
        guard size != lastSurfaceSize || attached != lastSurfaceAttached else { return }
        lastSurfaceSize = size
        lastSurfaceAttached = attached
        // Report actual UIKit attachment/layout after the current layout pass;
        // never assign UIView.frame or publish SwiftUI state during layout.
        Task { @MainActor [weak self] in
            guard let self, self.bounds.size == size, (self.window != nil) == attached else { return }
            self.onSurfaceChanged?(size, attached)
        }
    }

    private func configure() {
        backgroundColor = UIColor(red: 0.035, green: 0.040, blue: 0.052, alpha: 1)
        playerLayer.videoGravity = .resizeAspect
        isUserInteractionEnabled = false
        displayObservation = playerLayer.observe(\.isReadyForDisplay, options: [.initial, .new]) { [weak self] layer, _ in
            guard layer.isReadyForDisplay else { return }
            Task { @MainActor [weak self] in self?.onReady?() }
        }
    }
}
