import Foundation
import SwiftUI
import AVFoundation
import KinoCore
import TorrentRuntime

struct TorrentFileChoice: Identifiable, Sendable {
    let id: Int
    let name: String
    let size: Int64
    var isPlayable: Bool {
        TorrentDownloadPolicy.isSafeRelativePath(name) && size > 0 &&
        ["mp4", "m4v", "mov", "mkv", "webm", "avi", "ts"].contains(URL(fileURLWithPath: name).pathExtension.lowercased())
    }
}

struct TorrentLocalPlayback: Identifiable {
    let id: UUID
    let title: String
    let url: URL
}

private enum TorrentOperationError: LocalizedError {
    case message(String)
    var errorDescription: String? { if case let .message(text) = self { return text }; return nil }
}

@MainActor
final class TorrentDownloadsModel: ObservableObject {
    @Published private(set) var downloads: [TorrentDownload] = []
    @Published private(set) var candidates: [TorrentFileChoice] = []
    @Published private(set) var preparingID: UUID?
    @Published private(set) var isBusy = false
    @Published private(set) var errorMessage: String?
    @Published private(set) var availableBytes: Int64 = 0
    @Published var playback: TorrentLocalPlayback?
    private var records: [StoredTorrent] = []
    private var lastPersisted: [StoredTorrent] = []
    private var lastPersistedAt = Date.distantPast
    private let engine: LocalTorrentEngine
    private var loaded = false
    private var foreground = true
    private var epoch = 0
    private var pollTask: Task<Void, Never>?
    private var metadataStartedAt: Date?
    private var resumeOnForeground = Set<UUID>()
    private var operationRunning = false
    private var operationWaiters: [CheckedContinuation<Void, Never>] = []

    init() {
        let caches = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0]
        engine = LocalTorrentEngine(root: caches.appendingPathComponent("Asan/Torrents", isDirectory: true))
        #if DEBUG && targetEnvironment(simulator)
        if PreviewSupport.scene != nil {
            loaded = true
            availableBytes = 6 * 1_024 * 1_024 * 1_024
            if PreviewSupport.scene == .torrentList {
                var complete = TorrentDownload(id: UUID(uuidString: "00000000-0000-0000-0000-000000000001")!,
                    infoHash: String(repeating: "1", count: 40), title: "Демонстрационный фильм", fileIndex: 0,
                    fileName: "Демонстрационный фильм.mp4", totalBytes: 1_024 * 1_024 * 1_024,
                    downloadedBytes: 1_024 * 1_024 * 1_024)
                complete.markVerifiedComplete(at: Date().addingTimeInterval(-3_600))
                let partial = TorrentDownload(id: UUID(uuidString: "00000000-0000-0000-0000-000000000002")!,
                    infoHash: String(repeating: "2", count: 40),
                    title: "Очень длинное название демонстрационной серии для проверки переноса текста на экране загрузок",
                    fileIndex: 1, fileName: "Демонстрационная серия.mp4", totalBytes: 2 * 1_024 * 1_024 * 1_024,
                    downloadedBytes: 512 * 1_024 * 1_024, state: .paused)
                records = [StoredTorrent(download: complete, magnet: ""), StoredTorrent(download: partial, magnet: "")]
            }
            publish()
            if (PreviewSupport.scene == .torrentPlayer || PreviewSupport.scene == .torrentVLCPlayer),
               let url = Bundle.main.url(forResource: "PreviewClip", withExtension: "mp4") {
                playback = TorrentLocalPlayback(id: UUID(), title: "Проверка локального плеера", url: url)
            }
        }
        #endif
    }

    private var isPreview: Bool {
        #if DEBUG && targetEnvironment(simulator)
        return PreviewSupport.scene != nil
        #else
        return false
        #endif
    }

    #if DEBUG && targetEnvironment(simulator)
    private func isSearchPreviewHash(_ infoHash: String) -> Bool {
        guard let scene = PreviewSupport.scene?.rawValue,
              ["catalog", "details", "torrent-search"].contains(scene) else { return false }
        return infoHash == String(repeating: "1", count: 40) || infoHash == String(repeating: "2", count: 40)
    }
    #endif

    // An actor serializes individual native calls, but Swift actors are reentrant
    // across awaits. This gate also serializes each complete model transaction.
    private func acquireOperation(showBusy: Bool = true) async {
        if showBusy { isBusy = true }
        if operationRunning {
            await withCheckedContinuation { (continuation: CheckedContinuation<Void, Never>) in
                operationWaiters.append(continuation)
            }
        } else { operationRunning = true }
    }

    private func releaseOperation() {
        if operationWaiters.isEmpty {
            operationRunning = false
            isBusy = false
        } else { operationWaiters.removeFirst().resume() }
    }

    private func ensureActive(_ generation: Int) throws {
        try Task.checkCancellation()
        guard foreground, generation == epoch else { throw CancellationError() }
    }

    func clearError() { errorMessage = nil }
    private func publish() { downloads = records.map(\.download) }

    private func persist(force: Bool = true) async throws {
        publish()
        guard !isPreview, records != lastPersisted,
              force || Date().timeIntervalSince(lastPersistedAt) >= 15 else { return }
        let snapshot = records
        try await engine.save(snapshot)
        lastPersisted = snapshot
        lastPersistedAt = Date()
    }

    private func failure(_ error: Error) {
        guard !(error is CancellationError) else { return }
        errorMessage = (error as? LocalizedError)?.errorDescription ?? "Не удалось выполнить действие. Попробуй ещё раз."
    }

    /// Saturate corrupt totals rather than overflowing before policy validation.
    private func reservedBytes(except id: UUID) -> Int64 {
        records.filter { $0.download.id != id }.reduce(Int64(0)) { total, record in
            let (sum, overflow) = total.addingReportingOverflow(max(0, record.download.totalBytes))
            return overflow ? Int64.max : sum
        }
    }

    func refresh() async {
        if isPreview { publish(); return }
        await acquireOperation()
        defer { releaseOperation() }
        guard foreground, !Task.isCancelled else { return }
        do { try await refreshLocked(); startPolling() }
        catch { failure(error) }
    }

    private func refreshLocked() async throws {
        if !loaded {
            records = try await engine.load()
            lastPersisted = records
            // No file was selected in these interrupted add dialogs. They own no
            // user-approved film download and have no useful row-level resume.
            for id in records.filter({ $0.download.fileIndex == nil }).map({ $0.download.id }) {
                try await eraseLocked(id: id)
            }
            for index in records.indices where [.queued, .downloading].contains(records[index].download.state) {
                records[index].download.state = .paused
            }
            loaded = true
        }
        try await cleanExpiredLocked()
        for record in records.filter({ $0.download.state == .completed }) {
            if try await engine.localFile(for: record.download) == nil,
               let index = records.firstIndex(where: { $0.download.id == record.download.id }) {
                records[index].download.state = .missing
            }
        }
        availableBytes = await engine.availableBytes()
        try await persist()
    }

    func add(magnet text: String) async {
        guard !isBusy, foreground else { return }
        await acquireOperation()
        defer { releaseOperation() }
        let generation = epoch
        var addedID: UUID?
        do {
            try ensureActive(generation)
            let magnet = try TorrentMagnet(text)
            #if DEBUG && targetEnvironment(simulator)
            if isPreview, isSearchPreviewHash(magnet.infoHash) {
                guard records.count < 8, preparingID == nil,
                      !records.contains(where: { $0.download.infoHash == magnet.infoHash }) else {
                    throw TorrentOperationError.message("Демонстрационная раздача уже добавлена или ожидает выбора файла.")
                }
                let fixture = TorrentDownload(infoHash: magnet.infoHash, title: "Asan Preview Film (2026)")
                records.append(StoredTorrent(download: fixture, magnet: magnet.uri))
                preparingID = fixture.id
                metadataStartedAt = nil
                candidates = [
                    TorrentFileChoice(id: 0, name: "Asan Preview Film (2026).mp4", size: 2 * 1_024 * 1_024 * 1_024),
                    TorrentFileChoice(id: 1, name: "Информация.txt", size: 100 * 1_024),
                ]
                publish()
                return // Ephemeral UI fixture: no native session, filesystem or tracker calls.
            }
            #endif
            guard !isPreview else { throw TorrentOperationError.message("В предпросмотре сетевые загрузки отключены.") }
            if !loaded { try await refreshLocked(); try ensureActive(generation) }
            guard records.count < 8 else { throw TorrentOperationError.message("В списке уже 8 раздач. Удали ненужные загрузки.") }
            guard !records.contains(where: { $0.download.infoHash == magnet.infoHash }) else {
                throw TorrentOperationError.message("Эта раздача уже есть в загрузках.")
            }
            guard preparingID == nil else { throw TorrentOperationError.message("Сначала выбери файл в предыдущей раздаче.") }
            let download = TorrentDownload(infoHash: magnet.infoHash, title: magnet.displayName ?? "Новая раздача")
            addedID = download.id
            records.append(StoredTorrent(download: download, magnet: magnet.uri))
            preparingID = download.id
            metadataStartedAt = Date()
            try await persist()
            try ensureActive(generation)
            let snapshot = try await engine.add(id: download.id, magnet: magnet.uri)
            try ensureActive(generation)
            apply(snapshot, id: download.id)
            try await persist()
            startPolling(restart: true)
        } catch {
            if let id = addedID {
                // Includes a handle created while the UI/background cancelled add.
                do { try await eraseLocked(id: id); try await persist() } catch { failure(error) }
            }
            failure(error)
        }
    }

    func cancelPreparation() async {
        guard let id = preparingID else { return }
        await acquireOperation()
        defer { releaseOperation() }
        guard preparingID == id else { return } // A completed selection is already committed.
        do { try await eraseLocked(id: id); try await persist() }
        catch { failure(error) }
        stopPollingIfIdle()
    }

    func download(file: TorrentFileChoice) async {
        guard !isBusy, foreground else { return }
        await acquireOperation()
        defer { releaseOperation() }
        let generation = epoch
        guard let id = preparingID, records.contains(where: { $0.download.id == id }),
              candidates.contains(where: { $0.id == file.id && $0.name == file.name && $0.size == file.size }),
              file.isPlayable else { return }
        #if DEBUG && targetEnvironment(simulator)
        if isPreview {
            do {
                try ensureActive(generation)
                guard let index = records.firstIndex(where: { $0.download.id == id }),
                      isSearchPreviewHash(records[index].download.infoHash) else {
                    throw TorrentOperationError.message("В предпросмотре сетевые загрузки отключены.")
                }
                try TorrentDownloadPolicy.validateAdmission(fileBytes: file.size, usedBytes: reservedBytes(except: id),
                    availableBytes: 6 * 1_024 * 1_024 * 1_024)
                records[index].download.fileIndex = file.id
                records[index].download.fileName = file.name
                records[index].download.title = file.name
                records[index].download.totalBytes = file.size
                records[index].download.downloadedBytes = 0
                records[index].download.completedAt = nil
                records[index].download.state = .paused
                preparingID = nil; candidates = []; metadataStartedAt = nil
                publish()
            } catch { failure(error) }
            return // The fixture never claims a completed download or creates a real file.
        }
        #endif
        do {
            try ensureActive(generation)
            availableBytes = await engine.availableBytes()
            try ensureActive(generation)
            try TorrentDownloadPolicy.validateAdmission(fileBytes: file.size, usedBytes: reservedBytes(except: id),
                                                        availableBytes: availableBytes)
            try await pauseOtherDownloadsLocked(except: id)
            try ensureActive(generation)
            guard let index = records.firstIndex(where: { $0.download.id == id }) else { throw CancellationError() }
            records[index].download.fileIndex = file.id
            records[index].download.fileName = file.name
            records[index].download.title = URL(fileURLWithPath: file.name).lastPathComponent
            records[index].download.totalBytes = file.size
            records[index].download.state = .paused
            try await persist()
            try ensureActive(generation)
            let snapshot = try await engine.command(id: id, "select", index: file.id)
            try ensureActive(generation)
            guard let current = records.firstIndex(where: { $0.download.id == id }) else { throw CancellationError() }
            records[current].download.state = .downloading
            preparingID = nil; candidates = []; metadataStartedAt = nil
            apply(snapshot, id: id)
            try await persist()
            startPolling(restart: true)
        } catch {
            _ = try? await engine.command(id: id, "pause")
            if let index = records.firstIndex(where: { $0.download.id == id }), records[index].download.state == .downloading {
                records[index].download.state = .paused
            }
            try? await persist()
            failure(error)
        }
    }

    func pause(id: UUID) async {
        guard !isBusy else { return }
        await acquireOperation()
        defer { releaseOperation() }
        guard records.contains(where: { $0.download.id == id && $0.download.state == .downloading }) else { return }
        do {
            if !isPreview { _ = try await engine.command(id: id, "pause") }
            if let index = records.firstIndex(where: { $0.download.id == id }) { records[index].download.state = .paused }
            resumeOnForeground.remove(id)
            try await persist()
        } catch { failure(error) }
        stopPollingIfIdle()
    }

    func resume(id: UUID) async {
        guard !isBusy, foreground else { return }
        await acquireOperation()
        defer { releaseOperation() }
        do {
            guard !isPreview else { throw TorrentOperationError.message("В предпросмотре сетевые загрузки отключены.") }
            resumeOnForeground.remove(id)
            try await resumeLocked(id: id, generation: epoch)
        } catch { failure(error) }
    }

    private func metadata(id: UUID, magnet: String, generation: Int) async throws -> NativeTorrentSnapshot {
        var snapshot = try await engine.add(id: id, magnet: magnet)
        try ensureActive(generation)
        if snapshot.hasMetadata != true {
            // A previous background transition may have paused this same
            // metadata-only handle. This verb cannot select/download payload.
            snapshot = try await engine.command(id: id, "metadata")
        }
        let deadline = Date().addingTimeInterval(90)
        while true {
            try ensureActive(generation)
            if snapshot.hasMetadata == true { return snapshot }
            guard Date() < deadline else {
                throw TorrentOperationError.message("Раздача не передала список файлов за 90 секунд. Возможно, нет доступных участников.")
            }
            try await Task.sleep(for: .milliseconds(500))
            try ensureActive(generation)
            snapshot = try await engine.snapshot(id: id)
        }
    }

    private func restartAfterCacheLossLocked(_ record: StoredTorrent, generation: Int) async throws -> StoredTorrent {
        try ensureActive(generation)
        // Removing the native entry discards its in-memory verified-piece map.
        // Reusing a paused handle after tvOS purged its file can falsely report
        // completion or leave missing old pieces out of the new download.
        try await engine.remove(id: record.download.id)
        try ensureActive(generation)
        let replacement = StoredTorrent(download: record.download.restartedAfterCacheLoss(), magnet: record.magnet)
        guard let index = records.firstIndex(where: { $0.download.id == record.download.id }) else { throw CancellationError() }
        records[index] = replacement
        resumeOnForeground.remove(record.download.id)
        if preparingID == record.download.id { preparingID = nil; candidates = []; metadataStartedAt = nil }
        try await persist()
        return replacement
    }

    private func resumeLocked(id: UUID, generation: Int) async throws {
        var activeID = id
        do {
            try ensureActive(generation)
            guard var record = records.first(where: { $0.download.id == id }), record.download.state != .completed else { return }
            let fileExists = try await engine.selectedFileExists(for: record.download)
            try ensureActive(generation)
            if record.download.state == .missing || (!fileExists && record.download.downloadedBytes > 0) {
                record = try await restartAfterCacheLossLocked(record, generation: generation)
                activeID = record.download.id
            } else if record.download.isExpired(at: Date()) {
                try await eraseLocked(id: id); try await persist(); return
            }
            var snapshot = try await metadata(id: activeID, magnet: record.magnet, generation: generation)
            try ensureActive(generation)
            // The UI progress saved at most every 15s can still be zero when a
            // live handle has pieces. Detect that case using the native counter.
            if !fileExists, (snapshot.downloadedBytes ?? 0) > 0, activeID == id {
                record = try await restartAfterCacheLossLocked(record, generation: generation)
                activeID = record.download.id
                snapshot = try await metadata(id: activeID, magnet: record.magnet, generation: generation)
                try ensureActive(generation)
            }
            guard let fileIndex = record.download.fileIndex, let fileName = record.download.fileName else {
                preparingID = activeID; metadataStartedAt = Date()
                apply(snapshot, id: activeID)
                publish(); startPolling(restart: true); return
            }
            // Validate the resolved metadata before giving the engine a file index.
            guard snapshot.files?.contains(where: { $0.index == fileIndex && $0.name == fileName && $0.size == record.download.totalBytes }) == true else {
                throw TorrentOperationError.message("Файл раздачи изменился или больше недоступен. Добавь раздачу заново.")
            }
            availableBytes = await engine.availableBytes()
            let allocated = try await engine.allocatedBytes(for: record.download)
            try ensureActive(generation)
            let (credited, overflow) = availableBytes.addingReportingOverflow(allocated)
            try TorrentDownloadPolicy.validateAdmission(fileBytes: record.download.totalBytes,
                usedBytes: reservedBytes(except: activeID), availableBytes: overflow ? Int64.max : credited)
            try await pauseOtherDownloadsLocked(except: activeID)
            try ensureActive(generation)
            let selected = try await engine.command(id: activeID, "select", index: fileIndex)
            try ensureActive(generation)
            if let index = records.firstIndex(where: { $0.download.id == activeID }) { records[index].download.state = .downloading }
            apply(selected, id: activeID)
            try await persist()
            startPolling(restart: true)
        } catch {
            _ = try? await engine.command(id: activeID, "pause")
            if generation != epoch, records.contains(where: { $0.download.id == activeID }) { resumeOnForeground.insert(activeID) }
            if let index = records.firstIndex(where: { $0.download.id == activeID }), records[index].download.state == .downloading {
                records[index].download.state = .paused
            }
            try? await persist()
            throw error
        }
    }

    func remove(id: UUID) async {
        guard !isBusy else { return }
        await acquireOperation()
        defer { releaseOperation() }
        do { try await eraseLocked(id: id); try await persist() }
        catch { failure(error) }
        stopPollingIfIdle()
    }

    func play(id: UUID) async {
        guard !isBusy, foreground, playback == nil else { return }
        await acquireOperation()
        defer { releaseOperation() }
        let generation = epoch
        guard let record = records.first(where: { $0.download.id == id })?.download, record.state == .completed else { return }
        do {
            guard !isPreview else { throw TorrentOperationError.message("Это демонстрационная карточка без видеофайла.") }
            if record.isExpired(at: Date()) { try await eraseLocked(id: id); try await persist(); return }
            guard let url = try await engine.localFile(for: record) else {
                if let index = records.firstIndex(where: { $0.download.id == id }) { records[index].download.state = .missing }
                try await persist()
                throw TorrentOperationError.message("tvOS очистила файл. Его можно скачать повторно.")
            }
            try ensureActive(generation)
            // Player readiness/codec errors are bounded by the local player's
            // startup deadline; do not hold the transaction gate on AVAsset I/O.
            try ensureActive(generation)
            playback = TorrentLocalPlayback(id: id, title: record.title, url: url)
        } catch { failure(error) }
    }

    func activate() async {
        if isPreview { return }
        if !foreground { foreground = true; epoch += 1 }
        await acquireOperation()
        defer { releaseOperation() }
        guard foreground else { return }
        do {
            try await refreshLocked()
            let pending = records.filter { resumeOnForeground.contains($0.download.id) }.map { $0.download.id }
            resumeOnForeground.removeAll()
            for id in pending {
                let generation = epoch
                do { try await resumeLocked(id: id, generation: generation) }
                catch { failure(error) }
            }
            startPolling(restart: true)
        } catch { failure(error) }
    }

    func suspend() async {
        if isPreview { return }
        // Invalidation is deliberately immediate, before waiting for the gate.
        // In-flight add/select detects this and pauses/removes its late handle.
        foreground = false; epoch += 1
        pollTask?.cancel(); pollTask = nil
        await acquireOperation()
        defer { releaseOperation() }
        for record in records where record.download.state == .downloading || record.download.id == preparingID {
            resumeOnForeground.insert(record.download.id)
        }
        await engine.pauseAll() // Covers metadata handles too, including failed operations.
        for index in records.indices where records[index].download.state == .downloading || records[index].download.id == preparingID {
            records[index].download.state = .paused
        }
        try? await persist()
    }

    private func pauseOtherDownloadsLocked(except id: UUID) async throws {
        let others = records.filter { $0.download.id != id && $0.download.state == .downloading }.map { $0.download.id }
        for other in others {
            _ = try await engine.command(id: other, "pause")
            if let index = records.firstIndex(where: { $0.download.id == other }) { records[index].download.state = .paused }
        }
    }

    private func eraseLocked(id: UUID) async throws {
        if playback?.id == id { playback = nil }
        if !isPreview { try await engine.remove(id: id) }
        records.removeAll { $0.download.id == id }
        resumeOnForeground.remove(id)
        if preparingID == id { preparingID = nil; candidates = []; metadataStartedAt = nil }
        if !isPreview { availableBytes = await engine.availableBytes() }
    }

    private func cleanExpiredLocked() async throws {
        // Do not tear down the active AVPlayer or its full-screen cover. The next
        // tick after playback closes reclaims this expired owned file.
        let now = Date()
        for id in records.filter({ $0.download.isExpired(at: now) && $0.download.id != playback?.id }).map({ $0.download.id }) {
            try await eraseLocked(id: id)
        }
    }

    private func apply(_ snapshot: NativeTorrentSnapshot, id: UUID) {
        guard let index = records.firstIndex(where: { $0.download.id == id }) else { return }
        if id == preparingID, snapshot.hasMetadata == true {
            candidates = (snapshot.files ?? []).filter { TorrentDownloadPolicy.isSafeRelativePath($0.name) }
                .map { TorrentFileChoice(id: $0.index, name: $0.name, size: $0.size) }
        }
        if let selected = records[index].download.fileIndex, snapshot.selectedIndex == selected,
           snapshot.totalBytes == records[index].download.totalBytes {
            records[index].download.downloadedBytes = min(records[index].download.totalBytes,
                max(0, snapshot.downloadedBytes ?? 0))
            if snapshot.isVerifiedComplete == true, records[index].download.totalBytes > 0,
               records[index].download.downloadedBytes == records[index].download.totalBytes {
                records[index].download.markVerifiedComplete(at: Date())
            }
        }
    }

    private var hasPollingWork: Bool {
        !isPreview && records.contains { $0.download.state == .downloading || $0.download.id == preparingID || $0.download.expiresAt != nil }
    }

    private var pollDelay: Double {
        if records.contains(where: { $0.download.state == .downloading || $0.download.id == preparingID }) { return 2 }
        let next = records.compactMap { record -> Double? in
            guard let expiry = record.download.expiresAt else { return nil }
            let delay = expiry.timeIntervalSinceNow
            return delay <= 0 && record.download.id == playback?.id ? 30 : max(1, delay)
        }.min() ?? 60
        return min(60, next)
    }

    private func startPolling(restart: Bool = false) {
        if restart { pollTask?.cancel(); pollTask = nil }
        guard foreground, hasPollingWork, pollTask == nil else { return }
        pollTask = Task { [weak self] in
            while !Task.isCancelled {
                guard let delay = self?.pollDelay else { break }
                do { try await Task.sleep(for: .seconds(delay)) } catch { break }
                guard let self else { break }
                await self.tick()
                if !self.foreground || !self.hasPollingWork { self.pollTask = nil; break }
            }
        }
    }

    private func stopPollingIfIdle() {
        if !foreground || !hasPollingWork { pollTask?.cancel(); pollTask = nil }
    }

    private func tick() async {
        guard foreground, !isBusy, !isPreview else { return }
        await acquireOperation(showBusy: false)
        defer { releaseOperation() }
        let generation = epoch
        let before = records
        do {
            try ensureActive(generation)
            try await cleanExpiredLocked()
            let active = records.filter { $0.download.state == .downloading || $0.download.id == preparingID }.map { $0.download.id }
            for id in active {
                let snapshot = try await engine.snapshot(id: id)
                try ensureActive(generation)
                apply(snapshot, id: id)
            }
            if let began = metadataStartedAt, Date().timeIntervalSince(began) > 90, candidates.isEmpty, let id = preparingID {
                try await eraseLocked(id: id)
                errorMessage = "Раздача не передала список файлов за 90 секунд. Возможно, нет доступных участников. Попробуй другую ссылку."
            }
            availableBytes = await engine.availableBytes()
            try ensureActive(generation)
            if availableBytes < TorrentDownloadPolicy.reserveBytes {
                let active = records.filter { $0.download.state == .downloading }.map { $0.download.id }
                for id in active {
                    _ = try await engine.command(id: id, "pause")
                    if let index = records.firstIndex(where: { $0.download.id == id }) { records[index].download.state = .paused }
                    errorMessage = "Загрузка приостановлена: на Apple TV осталось мало места."
                }
            }
            let transitions = before.map { ($0.download.id, $0.download.state, $0.download.completedAt) }
            let changedState = before.count != records.count || records.contains { record in
                !transitions.contains { $0.0 == record.download.id && $0.1 == record.download.state && $0.2 == record.download.completedAt }
            }
            try await persist(force: changedState)
            stopPollingIfIdle()
        } catch {
            if generation != epoch || error is CancellationError { return }
            let active = records.filter { $0.download.state == .downloading }.map { $0.download.id }
            for id in active {
                _ = try? await engine.command(id: id, "pause")
                if let index = records.firstIndex(where: { $0.download.id == id }) { records[index].download.state = .failed }
            }
            failure(error)
            try? await persist()
            stopPollingIfIdle()
        }
    }
}
