import SwiftUI

@main
@MainActor
struct KinoHDApp: App {
    @StateObject private var model = AppModel()
    @StateObject private var downloads = TorrentDownloadsModel()
    @Environment(\.scenePhase) private var scenePhase

    var body: some Scene {
        WindowGroup {
            AsanLaunchRoot()
                .environmentObject(model)
                .environmentObject(downloads)
                .preferredColorScheme(.dark)
                .task { await model.start() }
                .onChange(of: scenePhase, initial: true) { _, phase in
                    Task {
                        if phase == .active { await downloads.activate() }
                        else if phase == .background { await downloads.suspend() }
                    }
                }
        }
    }
}

/// Keep account restoration and the download lifecycle on the outer app view:
/// the optional local movie never holds up loading the catalogue.
@MainActor
private struct AsanLaunchRoot: View {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var showsIntro = AsanLaunchRoot.shouldShowIntro

    private static var shouldShowIntro: Bool {
        #if DEBUG && targetEnvironment(simulator)
        if let scene = PreviewSupport.scene { return scene == .intro }
        #endif
        return true
    }

    var body: some View {
        ZStack {
            RootView()
                .opacity(showsIntro ? 0 : 1)
                .allowsHitTesting(!showsIntro)
                .accessibilityHidden(showsIntro)
            if showsIntro {
                AsanIntroView {
                    withAnimation(reduceMotion || AsanEffects.isPreviewReduced ? nil : .easeOut(duration: 0.25)) {
                        showsIntro = false
                    }
                }
                .transition(.opacity)
                .zIndex(1)
            }
        }
        .background(Color.black)
    }
}
