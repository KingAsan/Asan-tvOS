import SwiftUI

@main
@MainActor
struct KinoHDApp: App {
    @StateObject private var model = AppModel()
    @StateObject private var downloads = TorrentDownloadsModel()
    @Environment(\.scenePhase) private var scenePhase

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(model)
                .environmentObject(downloads)
                .preferredColorScheme(.dark)
                .task { await model.start() }
                .onChange(of: scenePhase) { _, phase in
                    Task {
                        if phase == .active { await downloads.activate() }
                        else if phase == .background { await downloads.suspend() }
                    }
                }
        }
    }
}
