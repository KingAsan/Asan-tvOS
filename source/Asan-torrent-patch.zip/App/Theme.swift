import SwiftUI
import KinoCore
import RezkaKit
import KinoArtwork

enum Theme {
    static let accent = Color(red: 0.77, green: 0.84, blue: 0.96)
    static let background = Color(red: 0.035, green: 0.040, blue: 0.052)
    static let surface = Color(red: 0.09, green: 0.105, blue: 0.13)
    static let sidebar = Color(red: 0.04, green: 0.045, blue: 0.06)
    static let text = Color.white.opacity(0.96)
    static let secondaryText = Color.white.opacity(0.72)
}

/// A cached low-resolution image, shaded with static gradients for readable
/// television text. An absent artwork URL leaves the normal graphite backdrop.
struct MediaAtmosphereBackdrop: View {
    let media: MediaItem
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    @Environment(\.colorSchemeContrast) private var contrast

    var body: some View {
        GeometryReader { geometry in
            ZStack {
                AsanBackdrop()
                if !reduceTransparency && !AsanEffects.isPreviewReduced {
                    artwork
                        .frame(width: geometry.size.width, height: geometry.size.height)
                        .clipped().opacity(contrast == .increased ? 0.22 : 0.46)
                    LinearGradient(colors: [Theme.background.opacity(0.94), Theme.background.opacity(0.63), Theme.background.opacity(0.20)],
                        startPoint: .leading, endPoint: .trailing)
                    LinearGradient(stops: [.init(color: .clear, location: 0),
                        .init(color: Theme.background.opacity(0.55), location: 0.48),
                        .init(color: Theme.background, location: 0.92)],
                        startPoint: .top, endPoint: .bottom)
                }
            }
        }
        .ignoresSafeArea().allowsHitTesting(false).accessibilityHidden(true)
    }

    @ViewBuilder private var artwork: some View {
        #if DEBUG && targetEnvironment(simulator)
        if let data = PreviewArtwork.atmosphereData(for: media) {
            AtmosphereImage(previewData: data, cacheID: media.id)
        } else {
            AtmosphereImage(backdropURL: media.backdropURL, posterURL: media.posterURL)
        }
        #else
        AtmosphereImage(backdropURL: media.backdropURL, posterURL: media.posterURL)
        #endif
    }
}

/// Display state derived exclusively from real history and known episode IDs.
/// A series without episode metadata never receives a guessed "new" badge.
struct MediaViewingStatus {
    let latest: WatchProgress?
    let isWatched: Bool
    let nextKnownEpisode: Episode?

    init(media: MediaItem, reference: MediaReference, history: [WatchProgress]) {
        let relevant = history.filter { $0.reference == reference }
        let latest = relevant.max { $0.updatedAt < $1.updatedAt }
        self.latest = latest
        guard media.kind == .series else {
            isWatched = latest?.isCompleted == true
            nextKnownEpisode = nil
            return
        }
        // Online history can contain a full known catalogue; local history may
        // contain only its selected episode. Both are real metadata, never a
        // reason to invent an ID or claim the whole series has been watched.
        let knownHistory = relevant.max {
            $0.media.seasons.reduce(0) { $0 + $1.episodes.count } < $1.media.seasons.reduce(0) { $0 + $1.episodes.count }
        }
        let seasons = media.seasons.isEmpty ? (knownHistory?.media.seasons ?? []) : media.seasons
        let episodes = seasons.sorted { $0.number < $1.number }
            .flatMap { $0.episodes.sorted { $0.number < $1.number } }
        let completed = Set(relevant.filter(\.isCompleted).compactMap(\.episodeID))
        isWatched = latest?.episodeID != nil && latest?.isCompleted == true
        if let lastCompleted = episodes.lastIndex(where: { completed.contains($0.id) }),
           episodes.indices.contains(lastCompleted + 1) {
            let next = episodes[lastCompleted + 1]
            // An already started episode is "Continue", not "New episode".
            let alreadyStarted = relevant.contains { $0.episodeID == next.id && $0.position > 5 }
                || (latest?.isCompleted == false && (latest?.position ?? 0) > 5)
            nextKnownEpisode = alreadyStarted ? nil : next
        } else {
            nextKnownEpisode = nil
        }
    }

    var resumable: WatchProgress? {
        guard let latest, !latest.isCompleted, latest.position.isFinite,
              latest.duration.isFinite, latest.position > 5, latest.duration > 0 else { return nil }
        return latest
    }
}

struct MediaStateBadge: View {
    let title: String
    let symbol: String
    var body: some View {
        Label(title, systemImage: symbol)
            .font(.system(size: 16, weight: .semibold))
            .foregroundStyle(Theme.text)
            .padding(.horizontal, 10).padding(.vertical, 7)
            .background(.black.opacity(0.82), in: Capsule())
            .accessibilityElement(children: .combine)
    }
}

/// A static, inexpensive pearl/graphite atmosphere, also on pre-Liquid-Glass TVs.
/// Native tvOS controls retain their system focus, contrast and materials.
struct AsanBackdrop: View {
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    var body: some View {
        ZStack {
            Theme.background
            if !reduceTransparency && !AsanEffects.isPreviewReduced {
                RadialGradient(colors: [Theme.accent.opacity(0.13), .clear],
                    center: .topTrailing, startRadius: 0, endRadius: 1250)
                LinearGradient(colors: [.white.opacity(0.025), .clear, .black.opacity(0.18)],
                    startPoint: .topLeading, endPoint: .bottomTrailing)
            }
        }.ignoresSafeArea().allowsHitTesting(false).accessibilityHidden(true)
    }
}

private struct AsanPanel: ViewModifier {
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    @Environment(\.colorSchemeContrast) private var contrast
    func body(content: Content) -> some View {
        content.background {
            RoundedRectangle(cornerRadius: 24, style: .continuous)
                .fill(Theme.surface.opacity(reduceTransparency || AsanEffects.isPreviewReduced ? 1 : 0.70))
                .overlay {
                    RoundedRectangle(cornerRadius: 24, style: .continuous)
                        .strokeBorder(LinearGradient(colors: [.white.opacity(contrast == .increased ? 0.5 : 0.21),
                            .white.opacity(0.035)], startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 1)
                }
        }
    }
}

extension View {
    func asanPanel() -> some View { modifier(AsanPanel()) }
}

enum AsanEffects {
    /// Native accessibility values are read-only on tvOS. The offline UI test
    /// requests the same app-level reduced-effects path without changing them.
    static var isPreviewReduced: Bool {
        #if DEBUG && targetEnvironment(simulator)
        ProcessInfo.processInfo.arguments.contains("--qa-reduce-effects")
        #else
        false
        #endif
    }
}

struct CatalogEntry: Identifiable, Hashable, Sendable {
    let providerID: String
    let providerName: String
    let media: MediaItem
    var reference: MediaReference { MediaReference(providerID: providerID, itemID: media.id) }
    var id: String { reference.stableKey }
}

enum AppTab: Hashable, CaseIterable {
    case catalog, search, favorites, watchlist, history, downloads, settings

    var title: String {
        switch self {
        case .catalog: return "Медиатека"
        case .search: return "Поиск"
        case .favorites: return "Избранное"
        case .watchlist: return "Смотреть позже"
        case .history: return "История"
        case .downloads: return "Загрузки"
        case .settings: return "Настройки"
        }
    }

    var symbol: String {
        switch self {
        case .catalog: return "square.grid.2x2"
        case .search: return "magnifyingglass"
        case .favorites: return "heart"
        case .watchlist: return "bookmark"
        case .history: return "clock"
        case .downloads: return "arrow.down.to.line"
        case .settings: return "gearshape"
        }
    }
}

struct PlaybackRequest: Identifiable {
    let id = UUID()
    let entry: CatalogEntry
    let episode: Episode?
    let streams: [StreamVariant]
    let initialStreamID: String
    let resumePosition: Double
    let tracksHistory: Bool
    let rezkaDetails: RezkaDetails?
    let translatorID: String?

    var qualityChoices: [StreamVariant] { PlaybackVariantPolicy.choices(streams) }
    func isSelectedQuality(_ choice: StreamVariant, selectedID: String) -> Bool {
        streams.first { $0.id == selectedID }.map { PlaybackVariantPolicy.sameChoice($0, choice) } ?? false
    }

    var title: String {
        guard let episode else { return entry.media.title }
        return "\(entry.media.title) · \(episode.title)"
    }

    func selecting(_ streamID: String) -> PlaybackRequest {
        PlaybackRequest(entry: entry, episode: episode, streams: streams,
            initialStreamID: streamID, resumePosition: resumePosition, tracksHistory: tracksHistory,
            rezkaDetails: rezkaDetails, translatorID: translatorID)
    }
}

struct PreparedPlayback {
    let request: PlaybackRequest
    let accountGeneration: Int
}

struct Notice: Identifiable {
    let id = UUID()
    let title: String
    let message: String
}

extension MediaItem {
    var metadataLine: String {
        var parts: [String] = [kind == .movie ? "Фильм" : "Сериал"]
        if let year { parts.append(String(year)) }
        if let rating = displayRating { parts.append(String(format: "★ %.1f", rating)) }
        if let durationMinutes { parts.append("\(durationMinutes) мин") }
        return parts.joined(separator: "  ·  ")
    }
}

func playbackTime(_ seconds: Double) -> String {
    guard seconds.isFinite, seconds >= 0 else { return "0:00" }
    let total = Int(min(seconds, 360_000))
    if total >= 3_600 {
        return String(format: "%d:%02d:%02d", total / 3_600, (total / 60) % 60, total % 60)
    }
    return String(format: "%d:%02d", total / 60, total % 60)
}
