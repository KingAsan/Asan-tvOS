import SwiftUI
import KinoCore
import RezkaKit

enum Theme {
    static let accent = Color(red: 0.77, green: 0.84, blue: 0.96)
    static let background = Color(red: 0.035, green: 0.040, blue: 0.052)
    static let surface = Color(red: 0.09, green: 0.105, blue: 0.13)
    static let sidebar = Color(red: 0.04, green: 0.045, blue: 0.06)
}

/// A static, inexpensive pearl/graphite atmosphere, also on pre-Liquid-Glass TVs.
/// Native tvOS controls retain their system focus, contrast and materials.
struct AsanBackdrop: View {
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    var body: some View {
        ZStack {
            Theme.background
            if !reduceTransparency && !AsanEffects.isPreviewReduced {
                RadialGradient(colors: [Theme.accent.opacity(0.13), .clear],
                    center: .topTrailing, startRadius: 0, endRadius: 1250)
                LinearGradient(colors: [.white.opacity(0.025), .clear, .black.opacity(0.18)],
                    startPoint: .topLeading, endPoint: .bottomTrailing)
            }
        }.ignoresSafeArea().allowsHitTesting(false).accessibilityHidden(true)
    }
}

private struct AsanPanel: ViewModifier {
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    @Environment(\.colorSchemeContrast) private var contrast
    func body(content: Content) -> some View {
        content.background {
            RoundedRectangle(cornerRadius: 24, style: .continuous)
                .fill(Theme.surface.opacity(reduceTransparency || AsanEffects.isPreviewReduced ? 1 : 0.70))
                .overlay {
                    RoundedRectangle(cornerRadius: 24, style: .continuous)
                        .strokeBorder(LinearGradient(colors: [.white.opacity(contrast == .increased ? 0.5 : 0.21),
                            .white.opacity(0.035)], startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 1)
                }
        }
    }
}

extension View {
    func asanPanel() -> some View { modifier(AsanPanel()) }
}

enum AsanEffects {
    /// Native accessibility values are read-only on tvOS. The offline UI test
    /// requests the same app-level reduced-effects path without changing them.
    static var isPreviewReduced: Bool {
        #if DEBUG && targetEnvironment(simulator)
        ProcessInfo.processInfo.arguments.contains("--qa-reduce-effects")
        #else
        false
        #endif
    }
}

struct CatalogEntry: Identifiable, Hashable, Sendable {
    let providerID: String
    let providerName: String
    let media: MediaItem
    var reference: MediaReference { MediaReference(providerID: providerID, itemID: media.id) }
    var id: String { reference.stableKey }
}

enum AppTab: Hashable, CaseIterable {
    case catalog, search, favorites, watchlist, history, downloads, settings

    var title: String {
        switch self {
        case .catalog: return "Медиатека"
        case .search: return "Поиск"
        case .favorites: return "Избранное"
        case .watchlist: return "Смотреть позже"
        case .history: return "История"
        case .downloads: return "Загрузки"
        case .settings: return "Настройки"
        }
    }

    var symbol: String {
        switch self {
        case .catalog: return "square.grid.2x2"
        case .search: return "magnifyingglass"
        case .favorites: return "heart"
        case .watchlist: return "bookmark"
        case .history: return "clock"
        case .downloads: return "arrow.down.to.line"
        case .settings: return "gearshape"
        }
    }
}

struct PlaybackRequest: Identifiable {
    let id = UUID()
    let entry: CatalogEntry
    let episode: Episode?
    let streams: [StreamVariant]
    let initialStreamID: String
    let resumePosition: Double
    let tracksHistory: Bool
    let rezkaDetails: RezkaDetails?
    let translatorID: String?

    var qualityChoices: [StreamVariant] { PlaybackVariantPolicy.choices(streams) }
    func isSelectedQuality(_ choice: StreamVariant, selectedID: String) -> Bool {
        streams.first { $0.id == selectedID }.map { PlaybackVariantPolicy.sameChoice($0, choice) } ?? false
    }

    var title: String {
        guard let episode else { return entry.media.title }
        return "\(entry.media.title) · \(episode.title)"
    }

    func selecting(_ streamID: String) -> PlaybackRequest {
        PlaybackRequest(entry: entry, episode: episode, streams: streams,
            initialStreamID: streamID, resumePosition: resumePosition, tracksHistory: tracksHistory,
            rezkaDetails: rezkaDetails, translatorID: translatorID)
    }
}

struct PreparedPlayback {
    let request: PlaybackRequest
    let accountGeneration: Int
}

struct Notice: Identifiable {
    let id = UUID()
    let title: String
    let message: String
}

extension MediaItem {
    var metadataLine: String {
        var parts: [String] = [kind == .movie ? "Фильм" : "Сериал"]
        if let year { parts.append(String(year)) }
        if let rating { parts.append(String(format: "★ %.1f", rating)) }
        if let durationMinutes { parts.append("\(durationMinutes) мин") }
        return parts.joined(separator: "  ·  ")
    }
}

func playbackTime(_ seconds: Double) -> String {
    guard seconds.isFinite, seconds >= 0 else { return "0:00" }
    let total = Int(min(seconds, 360_000))
    if total >= 3_600 {
        return String(format: "%d:%02d:%02d", total / 3_600, (total / 60) % 60, total % 60)
    }
    return String(format: "%d:%02d", total / 60, total % 60)
}
