import Foundation
import XCTest
import KinoCore
@testable import TorrentRuntime

final class LocalTorrentStorageTests: XCTestCase {
    private let infoHashHex = String(repeating: "1", count: 40)

    private func temporaryRoot() throws -> URL {
        let parent = FileManager.default.temporaryDirectory.standardizedFileURL.resolvingSymlinksInPath()
        let directory = parent.appendingPathComponent("AsanTorrentStorageTests-" + UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: false)
        addTeardownBlock {
            guard directory.deletingLastPathComponent() == parent,
                  directory.lastPathComponent.hasPrefix("AsanTorrentStorageTests-"),
                  directory.resolvingSymlinksInPath() == directory else {
                XCTFail("Refusing unsafe temporary-directory cleanup"); return
            }
            if FileManager.default.fileExists(atPath: directory.path) { try FileManager.default.removeItem(at: directory) }
        }
        return directory
    }

    private func record(id: UUID = UUID(), size: Int64 = 4) -> StoredTorrent {
        var download = TorrentDownload(id: id, infoHash: infoHashHex, title: "Storage test", fileIndex: 0,
            fileName: "movie.mp4", totalBytes: size, downloadedBytes: size)
        download.markVerifiedComplete(at: Date(timeIntervalSince1970: 1_800_000_000))
        return StoredTorrent(download: download, magnet: "magnet:?xt=urn:btih:" + infoHashHex)
    }

    private func payload(root: URL, record: StoredTorrent, bytes: Data = Data([1, 2, 3, 4])) throws -> URL {
        let directory = root.appendingPathComponent(record.download.id.uuidString.lowercased(), isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let file = directory.appendingPathComponent("movie.mp4")
        try bytes.write(to: file)
        return file
    }

    private func expectFailure(_ work: () async throws -> Void, file: StaticString = #filePath, line: UInt = #line) async {
        do { try await work(); XCTFail("Expected storage operation to reject this input", file: file, line: line) }
        catch { }
    }

    func testManifestRoundTripAcrossEngineInstancesPreservesCompletionAndIdentity() async throws {
        let root = try temporaryRoot().appendingPathComponent("owned", isDirectory: true)
        let value = record()
        try await LocalTorrentEngine(root: root).save([value])
        let restored = try await LocalTorrentEngine(root: root).load()
        XCTAssertEqual(restored, [value])
        XCTAssertTrue(FileManager.default.fileExists(atPath: root.appendingPathComponent("manifest.json").path))
    }

    func testLocalPayloadUsesLowercaseUUIDAndExactFileSize() async throws {
        let root = try temporaryRoot().appendingPathComponent("owned", isDirectory: true)
        let value = record(id: UUID(uuidString: "ABCDEFAB-CDEF-4ABC-8DEF-ABCDEFABCDEF")!)
        let expected = try payload(root: root, record: value)
        let engine = LocalTorrentEngine(root: root)
        let local = try await engine.localFile(for: value.download)
        let exists = try await engine.selectedFileExists(for: value.download)
        XCTAssertEqual(local, expected)
        XCTAssertTrue(exists)
        XCTAssertTrue(expected.path.contains("abcdefab-cdef-4abc-8def-abcdefabcdef"))
    }

    func testMissingAndWrongSizedPayloadAreNeverPlayable() async throws {
        let root = try temporaryRoot().appendingPathComponent("owned", isDirectory: true)
        let value = record()
        let engine = LocalTorrentEngine(root: root)
        let missing = try await engine.localFile(for: value.download)
        let exists = try await engine.selectedFileExists(for: value.download)
        XCTAssertNil(missing)
        XCTAssertFalse(exists)
        _ = try payload(root: root, record: value, bytes: Data([1, 2]))
        let wrongSize = try await engine.localFile(for: value.download)
        XCTAssertNil(wrongSize)
    }

    func testSymlinkPayloadCannotBePlayedAndRemovalPreservesTarget() async throws {
        let temp = try temporaryRoot()
        let root = temp.appendingPathComponent("owned", isDirectory: true)
        let value = record()
        let file = try payload(root: root, record: value)
        try FileManager.default.removeItem(at: file)
        let outside = temp.appendingPathComponent("outside.mp4")
        let original = Data([7, 8, 9, 10])
        try original.write(to: outside)
        try FileManager.default.createSymbolicLink(at: file, withDestinationURL: outside)
        let engine = LocalTorrentEngine(root: root)
        let local = try await engine.localFile(for: value.download)
        XCTAssertNil(local)
        await expectFailure { _ = try await engine.selectedFileExists(for: value.download) }
        try await engine.remove(id: value.download.id)
        XCTAssertEqual(try Data(contentsOf: outside), original)
    }

    func testSymlinkUUIDDirectoryIsRejectedWithoutDeletingTarget() async throws {
        let temp = try temporaryRoot()
        let root = temp.appendingPathComponent("owned", isDirectory: true)
        let outside = temp.appendingPathComponent("outside", isDirectory: true)
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        try FileManager.default.createDirectory(at: outside, withIntermediateDirectories: true)
        let target = outside.appendingPathComponent("movie.mp4")
        let bytes = Data([5, 6, 7, 8])
        try bytes.write(to: target)
        let value = record()
        try FileManager.default.createSymbolicLink(at: root.appendingPathComponent(value.download.id.uuidString.lowercased()), withDestinationURL: outside)
        let engine = LocalTorrentEngine(root: root)
        await expectFailure { _ = try await engine.localFile(for: value.download) }
        await expectFailure { try await engine.remove(id: value.download.id) }
        XCTAssertEqual(try Data(contentsOf: target), bytes)
    }

    func testSymlinkManifestIsRejectedForReadAndWriteAndTargetStaysUnchanged() async throws {
        let temp = try temporaryRoot()
        let root = temp.appendingPathComponent("owned", isDirectory: true)
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        let outside = temp.appendingPathComponent("outside.json")
        let bytes = Data("[]".utf8)
        try bytes.write(to: outside)
        try FileManager.default.createSymbolicLink(at: root.appendingPathComponent("manifest.json"), withDestinationURL: outside)
        let engine = LocalTorrentEngine(root: root)
        await expectFailure { _ = try await engine.load() }
        await expectFailure { try await engine.save([self.record()]) }
        XCTAssertEqual(try Data(contentsOf: outside), bytes)
    }

    func testRemoveTouchesOnlyRequestedOwnedUUIDDirectory() async throws {
        let root = try temporaryRoot().appendingPathComponent("owned", isDirectory: true)
        let first = record()
        let second = record()
        let firstFile = try payload(root: root, record: first)
        let secondFile = try payload(root: root, record: second)
        let unrelated = root.appendingPathComponent("keep.txt")
        try Data("keep".utf8).write(to: unrelated)
        try await LocalTorrentEngine(root: root).remove(id: first.download.id)
        XCTAssertFalse(FileManager.default.fileExists(atPath: firstFile.deletingLastPathComponent().path))
        XCTAssertEqual(try Data(contentsOf: secondFile), Data([1, 2, 3, 4]))
        XCTAssertEqual(try Data(contentsOf: unrelated), Data("keep".utf8))
    }

    func testCapacityWorksBeforeNestedCacheRootExists() async throws {
        let root = try temporaryRoot().appendingPathComponent("missing/Asan/Torrents", isDirectory: true)
        XCTAssertFalse(FileManager.default.fileExists(atPath: root.path))
        let bytes = await LocalTorrentEngine(root: root).availableBytes()
        XCTAssertGreaterThan(bytes, 0)
        XCTAssertFalse(FileManager.default.fileExists(atPath: root.path))
    }

    func testStoredProgressCannotCreditMissingOrEmptyPayloadSpace() async throws {
        let root = try temporaryRoot().appendingPathComponent("owned", isDirectory: true)
        let value = record(size: 1_024 * 1_024 * 1_024)
        let engine = LocalTorrentEngine(root: root)
        let missingCredit = try await engine.allocatedBytes(for: value.download)
        XCTAssertEqual(missingCredit, 0)
        _ = try payload(root: root, record: value, bytes: Data())
        let emptyCredit = try await engine.allocatedBytes(for: value.download)
        XCTAssertEqual(emptyCredit, 0)
    }

    func testMalformedAndOversizedManifestAreRejected() async throws {
        let root = try temporaryRoot().appendingPathComponent("owned", isDirectory: true)
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        let manifest = root.appendingPathComponent("manifest.json")
        try Data("not JSON".utf8).write(to: manifest)
        let engine = LocalTorrentEngine(root: root)
        await expectFailure { _ = try await engine.load() }
        try Data(repeating: 32, count: 512_001).write(to: manifest)
        await expectFailure { _ = try await engine.load() }
    }

    func testManifestDuplicateIDsInvalidSizesAndHashMismatchAreRejected() async throws {
        let root = try temporaryRoot().appendingPathComponent("owned", isDirectory: true)
        let engine = LocalTorrentEngine(root: root)
        let value = record()
        try await engine.save([value, value])
        await expectFailure { _ = try await engine.load() }
        var invalid = value
        invalid.download.totalBytes = -1
        try await engine.save([invalid])
        await expectFailure { _ = try await engine.load() }
        invalid = value
        invalid.download.infoHash = String(repeating: "2", count: 40)
        try await engine.save([invalid])
        await expectFailure { _ = try await engine.load() }
    }

    func testTraversalInManifestIsRejectedAndCannotResolveAnOutsideFile() async throws {
        let temp = try temporaryRoot()
        let root = temp.appendingPathComponent("owned", isDirectory: true)
        var value = record()
        value.download.fileName = "../../outside.mp4"
        let outside = temp.appendingPathComponent("outside.mp4")
        let bytes = Data([9, 9, 9, 9])
        try bytes.write(to: outside)
        let engine = LocalTorrentEngine(root: root)
        try await engine.save([value])
        await expectFailure { _ = try await engine.load() }
        let file = try await engine.localFile(for: value.download)
        XCTAssertNil(file)
        XCTAssertEqual(try Data(contentsOf: outside), bytes)
    }
}
