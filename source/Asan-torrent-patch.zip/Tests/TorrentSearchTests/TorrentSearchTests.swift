import Foundation
import XCTest
import KinoCore
@testable import TorrentSearch

private let origin = URL(string: "https://rutor.info")!
private let firstHash = String(repeating: "1", count: 40)
private let secondHash = String(repeating: "2", count: 40)
private let query = TorrentSearchQuery(title: "Тестовый фильм", originalTitle: "Example Movie", year: 2024)

private func row(_ title: String = "Тестовый фильм / Example Movie (2024) WEB-DL 1080p",
                 infoHash: String = firstHash, seeds: Int = 12, size: String = "1.46&nbsp;GB",
                 comments: Bool = true, topic: String = "/torrent/123/fixture") -> String {
    """
    <tr class="gai"><td>Дата</td><td><a href="//d.rutor.info/download/123">D</a>
    <a href="magnet:?xt=urn:btih:\(infoHash)&amp;dn=Fixture&amp;tr=udp://tracker.example:80/announce&amp;xs=https://evil.example/file">M</a>
    <a href="\(topic)">\(title)</a></td>\(comments ? "<td>3</td>" : "")
    <td align="right">\(size)</td><td><span class="green"><img alt="S">&nbsp;\(seeds)</span><span class="red">&nbsp;999</span></td></tr>
    """
}
private func page(_ rows: String) -> String { "<html><div id=index><table>\(rows)</table></div></html>" }
private func response(_ html: String, finalURL: URL = origin, status: Int = 200, mime: String? = "text/html") -> TorrentSearchHTTPResponse {
    TorrentSearchHTTPResponse(data: Data(html.utf8), statusCode: status, finalURL: finalURL, mimeType: mime)
}

private actor StubTransport: TorrentSearchTransport {
    struct Call: Sendable { let url: URL?; let maximumBytes: Int; let timeout: TimeInterval }
    private let responses: [TorrentSearchHTTPResponse]
    private let cancelBeforeReturn: Bool
    private(set) var calls: [Call] = []
    init(_ responses: [TorrentSearchHTTPResponse], cancelBeforeReturn: Bool = false) {
        self.responses = responses; self.cancelBeforeReturn = cancelBeforeReturn
    }
    func fetch(_ request: URLRequest, maximumBytes: Int) async throws -> TorrentSearchHTTPResponse {
        let index = calls.count
        calls.append(Call(url: request.url, maximumBytes: maximumBytes, timeout: request.timeoutInterval))
        guard responses.indices.contains(index) else { throw URLError(.cannotConnectToHost) }
        if cancelBeforeReturn { withUnsafeCurrentTask { $0?.cancel() } }
        return responses[index]
    }
}

final class TorrentSearchTests: XCTestCase {
    func testActualRutorColumnShapesAndCanonicalMagnet() throws {
        let values = try RutorSearchParser.parse(page(row() + row(infoHash: secondHash, comments: false)), origin: origin, query: query)
        XCTAssertEqual(values.count, 2)
        XCTAssertEqual(values[0].title, "Тестовый фильм / Example Movie (2024) WEB-DL 1080p")
        XCTAssertEqual(values[0].sizeBytes, 1_567_663_063)
        XCTAssertEqual(values[0].seeders, 12) // green seeders, never red leechers
        XCTAssertEqual(values[0].year, 2024)
        XCTAssertEqual(values[0].matchConfidence, 1)
        XCTAssertEqual(values[0].infoHash, firstHash)
        XCTAssertEqual(values[0].id, firstHash)
        XCTAssertEqual(values[0].sourceURL.absoluteString, "https://rutor.info/torrent/123/fixture")
        XCTAssertTrue(values[0].magnet.contains("tr="))
        XCTAssertFalse(values[0].magnet.contains("xs="))
        XCTAssertFalse(values[0].magnet.contains("&amp;"))
    }

    func testStrictBilingualTitleYearAndSequelMatching() throws {
        let html = page(row("Другой фильм / Other Movie (2024) WEB-DL")
            + row("Тестовый фильм 2 / Example Movie 2 (2024) WEB-DL")
            + row("Тестовый фильм / Example Movie (1999) WEB-DL")
            + row("Несовпадающий перевод / Example Movie (2024) BDRip", infoHash: secondHash))
        let values = try RutorSearchParser.parse(html, origin: origin, query: query)
        XCTAssertEqual(values.map(\.infoHash), [secondHash])
    }

    func testCasePunctuationYoAndSeriesTags() throws {
        let q = TorrentSearchQuery(title: "Ёлки: Начало", year: 2024, isSeries: true)
        let values = try RutorSearchParser.parse(page(row("ЕЛКИ — НАЧАЛО [S01] (2024) WEB-DL")), origin: origin, query: q)
        XCTAssertEqual(values.count, 1)
    }

    func testLaterSeriesSeasonMatchesPremiereIdentityAndRejectsEarlierShow() throws {
        let q = TorrentSearchQuery(title: "Тестовый сериал", originalTitle: "Example Series", year: 2021, isSeries: true)
        let values = try RutorSearchParser.parse(page(
            row("Тестовый сериал / Example Series [Сезон: 2 / Серии: 01-08] (2026) WEB-DL", infoHash: firstHash)
            + row("Тестовый сериал / Example Series [Сезон: 1] (1999) WEB-DL", infoHash: secondHash)
        ), origin: origin, query: q)
        XCTAssertEqual(values.map(\.infoHash), [firstHash])
        XCTAssertEqual(values.first?.year, 2026)
        XCTAssertEqual(values.first?.matchConfidence, 0.95)
    }

    func testSeriesUnbracketedSeasonOrnamentsAndIndependentAliases() throws {
        let q = TorrentSearchQuery(title: "Тестовый сериал", originalTitle: "Example Series", year: 2021, isSeries: true)
        for title in ["Тестовый сериал / Example Series. Season 2 (2026) WEB-DL",
                      "Тестовый сериал 2 сезон / Серии: 01-08 (2026) WEB-DL",
                      "Тестовый сериал / Example Series S02E01 (2026) WEB-DL",
                      "Другой перевод. Сезон: 2 / Example Series (2026) WEB-DL",
                      "Тестовый сериал / Example Series (Сезон 2: 1-8 серии) (2026) WEB-DL"] {
            XCTAssertEqual(try RutorSearchParser.parse(page(row(title)), origin: origin, query: q).count, 1, title)
        }
        XCTAssertTrue(try RutorSearchParser.parse(page(row("Тестовый сериал 2 / Example Series 2 (2026) WEB-DL")), origin: origin, query: q).isEmpty)
    }

    func testSeriesYearRangesUseStartYearAndMovieRemakeStillRequiresExactYear() throws {
        let series = TorrentSearchQuery(title: "Тестовый сериал", year: 2021, isSeries: true)
        let values = try RutorSearchParser.parse(page(row("Тестовый сериал [Сезоны: 1-3] (2021-2026) WEB-DL")), origin: origin, query: series)
        XCTAssertEqual(values.first?.year, 2021)
        XCTAssertEqual(values.first?.matchConfidence, 1)
        let movie = TorrentSearchQuery(title: "Тестовый фильм", year: 2021)
        XCTAssertFalse(movie.isSeries)
        XCTAssertTrue(try RutorSearchParser.parse(page(row("Тестовый фильм (2026) WEB-DL")), origin: origin, query: movie).isEmpty)
    }

    func testMediaQueryPreservesMovieAndAnimatedSeriesKind() {
        XCTAssertTrue(TorrentSearchQuery(media: MediaItem(id: "series", title: "Animation", kind: .series, year: 2021)).isSeries)
        XCTAssertFalse(TorrentSearchQuery(media: MediaItem(id: "movie", title: "Film", kind: .movie, year: 2021)).isSeries)
    }

    func testSeriesSearchOmitsPremiereYearFromBothTitleRequests() async throws {
        let q = TorrentSearchQuery(title: "Тестовый сериал", originalTitle: "Example Series", year: 2021, isSeries: true)
        let html = page(row("Тестовый сериал / Example Series [S02] (2026) WEB-DL"))
        let network = StubTransport([response(page(row("Другой сериал (2026) WEB-DL"))), response(html)])
        let values = try await TorrentSearchService(transport: network).search(q)
        XCTAssertEqual(values.count, 1)
        let calls = await network.calls
        XCTAssertEqual(calls.map { $0.url?.lastPathComponent }, ["Тестовый сериал", "Example Series"])
    }

    func testMissingYearIsLowerConfidenceButExplicitWrongYearRejected() throws {
        let values = try RutorSearchParser.parse(page(row("Тестовый фильм / Example Movie")), origin: origin, query: query)
        XCTAssertEqual(values.first?.matchConfidence, 0.85)
        XCTAssertNil(values.first?.year)
    }

    func testUnknownSizesRemainUnknownAndMalformedMagnitudeCannotTrap() {
        XCTAssertEqual(RutorSearchParser.parseSize("1,5 ГБ"), 1_610_612_736)
        XCTAssertEqual(RutorSearchParser.parseSize("750 MB"), 786_432_000)
        for value in ["-1 GB", "NaN GB", "inf GB", "999999999999999999999 TB", "?", "0 GB", "1 unknown"] {
            XCTAssertNil(RutorSearchParser.parseSize(value), value)
        }
    }

    func testUnknownAndChallengePagesDoNotBecomeSuccessfulEmptySearches() throws {
        XCTAssertThrowsError(try RutorSearchParser.parse("<html><h1>Maintenance</h1></html>", origin: origin, query: query))
        XCTAssertThrowsError(try RutorSearchParser.parse("<html><script src='/cdn-cgi/challenge-platform/test'></script></html>", origin: origin, query: query)) {
            XCTAssertEqual($0 as? TorrentSearchError, .challengeRequired)
        }
        XCTAssertEqual(try RutorSearchParser.parse("<html>Результатов поиска 0</html>", origin: origin, query: query), [])
    }

    func testRejectsBadMagnetsOffProviderTopicsAndOversizedBodies() throws {
        let values = try RutorSearchParser.parse(page(row(infoHash: "bad")
            + row(topic: "//evil.example/torrent/123/x")), origin: origin, query: query)
        XCTAssertTrue(values.isEmpty)
        XCTAssertThrowsError(try RutorSearchParser.parse(String(repeating: "x", count: 2 * 1024 * 1024 + 1), origin: origin, query: query)) {
            XCTAssertEqual($0 as? TorrentSearchError, .responseTooLarge)
        }
        for address in ["http://rutor.info", "https://rutor.info.evil.example", "https://user:secret@rutor.info", "https://rutor.info:444"] {
            XCTAssertFalse(RutorURL.accepts(URL(string: address)!))
        }
    }

    func testQueriesEscapePathSyntaxAndValidateBeforeNetwork() throws {
        let value = try RutorURL.searchURL(origin: origin, term: "Фильм / test?x=1#fake")
        XCTAssertNil(value.query)
        XCTAssertNil(value.fragment)
        XCTAssertTrue(value.absoluteString.contains("%2F"))
        XCTAssertTrue(value.path.hasPrefix("/search/0/0/100/2/"))
        XCTAssertThrowsError(try TorrentTitleMatch.titles(TorrentSearchQuery(title: "Bad\nTitle")))
        XCTAssertThrowsError(try TorrentTitleMatch.titles(TorrentSearchQuery(title: "", year: 9999)))
    }

    func testServiceDeduplicatesCanonicalHashAndSortsBySeeds() async throws {
        let zeroBase32 = String(repeating: "A", count: 32)
        let zeroHex = String(repeating: "0", count: 40)
        let network = StubTransport([
            response(page(row(infoHash: firstHash, seeds: 3) + row(infoHash: zeroBase32, seeds: 5)
                + row(infoHash: zeroHex, seeds: 90) + row(infoHash: firstHash, seeds: 4)))
        ])
        let values = try await TorrentSearchService(transport: network).search(query)
        XCTAssertEqual(values.map(\.infoHash), [zeroHex, firstHash])
        XCTAssertEqual(values.map(\.seeders), [90, 4])
        let calls = await network.calls
        XCTAssertEqual(calls.count, 1)
        XCTAssertTrue(calls.allSatisfy { $0.maximumBytes == 2 * 1024 * 1024 && $0.timeout <= 10 })
        XCTAssertEqual(calls.first?.url?.lastPathComponent, "Тестовый фильм 2024")
    }

    func testValidFirstAliasReturnsWithoutRequestingAnotherAliasOrMirror() async throws {
        let network = StubTransport([response(page(row()))])
        let values = try await TorrentSearchService(transport: network).search(query)
        XCTAssertEqual(values.count, 1)
        let calls = await network.calls
        XCTAssertEqual(calls.count, 1)
    }

    func testFallbackUsesOnlyKnownMirrorAndNoThirdPartyServer() async throws {
        let q = TorrentSearchQuery(title: "Тестовый фильм", year: 2024)
        let network = StubTransport([response("Unavailable", status: 503), response(page(row()), finalURL: URL(string: "https://rutor.is")!)])
        let values = try await TorrentSearchService(transport: network).search(q)
        XCTAssertEqual(values.count, 1)
        let hosts = await network.calls.map { $0.url?.host }
        XCTAssertEqual(hosts, ["rutor.info", "rutor.is"])
    }

    func testServiceRejectsOffsiteRedirectAndNonHTMLAndHonorsBodyCap() async throws {
        for bad in [response(page(row()), finalURL: URL(string: "https://evil.example")!),
                    response(page(row()), mime: "application/octet-stream"),
                    response(String(repeating: "x", count: 2 * 1024 * 1024 + 1))] {
            let network = StubTransport([bad, bad])
            do { _ = try await TorrentSearchService(transport: network).search(TorrentSearchQuery(title: "Тестовый фильм")); XCTFail("Accepted unsafe response") }
            catch { XCTAssertTrue(error is TorrentSearchError) }
        }
    }

    func testCancellationNeverStartsFallbackOrReturnsStaleMatches() async throws {
        let network = StubTransport([response(page(row()))], cancelBeforeReturn: true)
        let task = Task { try await TorrentSearchService(transport: network).search(query) }
        do { _ = try await task.value; XCTFail("Cancellation returned results") }
        catch { XCTAssertTrue(error is CancellationError) }
        let calls = await network.calls
        XCTAssertEqual(calls.count, 1)
    }

    func testResultCapRemainsBounded() async throws {
        let rows = (1...100).map { index in row(infoHash: String(format: "%040x", index), seeds: index) }.joined()
        let network = StubTransport([response(page(rows))])
        let values = try await TorrentSearchService(transport: network).search(TorrentSearchQuery(title: "Тестовый фильм", year: 2024))
        XCTAssertEqual(values.count, 60)
        XCTAssertEqual(values.first?.seeders, 100)
    }

    func testLivePublicSearchOnlyWhenExplicitlyEnabled() async throws {
        guard ProcessInfo.processInfo.environment["ASAN_LIVE_TORRENT_SEARCH"] == "1" else {
            throw XCTSkip("Live public-index request requires explicit ASAN_LIVE_TORRENT_SEARCH=1")
        }
        let values = try await TorrentSearchService().search(TorrentSearchQuery(
            title: "Ночь живых мертвецов", originalTitle: "Night of the Living Dead", year: 1968))
        XCTAssertFalse(values.isEmpty, "Live index returned no matching releases for the public-domain fixture title")
        XCTAssertTrue(values.allSatisfy { $0.infoHash.count == 40 && $0.year == 1968 })
        print("Live native RuTor HTML search: \(values.count) matched releases; no download was started")
    }
}
