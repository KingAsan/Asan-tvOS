import Foundation
import XCTest
import KinoCore
@testable import TorrentSearch

final class ReleasePresentationTests: XCTestCase {
    private func result(_ digit: String, title: String, size: Int64? = 2_000_000_000, seeds: Int = 20) -> TorrentSearchResult {
        let infoHash = String(repeating: digit, count: 40)
        return TorrentSearchResult(title: title, magnet: "magnet:?xt=urn:btih:" + infoHash,
            infoHash: infoHash, sizeBytes: size, seeders: seeds, sourceURL: URL(string: "https://example.invalid/fixture")!,
            matchConfidence: 1, year: 2026)
    }

    func testOnlyExplicitResolutionCodecAndVoiceArePresented() {
        let hints = TorrentReleasePresentation(title: "Пример (2026) WEB-DL 1080p x264 AAC | LostFilm")
        XCTAssertEqual(hints.quality, "1080p")
        XCTAssertEqual(hints.codec, "H.264")
        XCTAssertEqual(hints.voice, "LostFilm")
        XCTAssertTrue(hints.prefersAppleTVHD)
    }

    func testMissingHintsNeverInventAudioQualityOrCompatibility() {
        let hints = TorrentReleasePresentation(title: "Пример / Example (2026) WEB-DL RUS ENG")
        XCTAssertNil(hints.quality)
        XCTAssertNil(hints.codec)
        XCTAssertNil(hints.voice)
        XCTAssertFalse(hints.prefersAppleTVHD)
    }

    func testExplicitTranslationMarkersAndTokenBoundaries() {
        XCTAssertEqual(TorrentReleasePresentation(title: "Movie 720p H.264 DUB").voice, "Дублированный")
        XCTAssertNil(TorrentReleasePresentation(title: "Dubious avclub 1080people").voice)
        XCTAssertNil(TorrentReleasePresentation(title: "Dubious avclub 1080people").codec)
        XCTAssertNil(TorrentReleasePresentation(title: "Dubious avclub 1080people").quality)
    }

    func testHighResolutionAndAmbiguousCodecAreNotPreferred() {
        for title in ["Movie 2160p H264", "Movie 4K H264", "Movie 1080p H264 HEVC", "Movie 1080i H264", "Movie 1080p AV1"] {
            XCTAssertFalse(TorrentReleasePresentation(title: title).prefersAppleTVHD, title)
        }
        XCTAssertEqual(TorrentReleasePresentation(title: "Movie 1080p H.265").codec, "HEVC")
    }

    func testRankingPrefersStatedCompactH264OverLarge4K() {
        let preferred = result("1", title: "Movie 1080p H264", seeds: 20)
        let large = result("2", title: "Movie 2160p HEVC", size: 20_000_000_000, seeds: 1_000)
        XCTAssertEqual(TorrentReleasePresentation.ranked([large, preferred]).first?.id, preferred.id)
        XCTAssertEqual(TorrentReleasePresentation.recommendedResultID(in: [large, preferred]), preferred.id)
    }

    func testRecommendationRequiresSeedsAndKnownFittingSize() {
        for item in [result("1", title: "1080p H264", size: nil), result("2", title: "1080p H264", seeds: 0),
                     result("3", title: "1080p H264", size: -1), result("4", title: "1080p H264", size: 4_294_967_297)] {
            XCTAssertNil(TorrentReleasePresentation.recommendedResultID(in: [item]))
        }
    }

    func testDeduplicationKeepsMostAvailableHashAndStableOrder() {
        let first = result("1", title: "Movie 1080p H264", seeds: 5)
        let duplicate = result("1", title: "Movie 1080p H264 DUB", seeds: 50)
        let second = result("2", title: "Movie 1080p H264", seeds: 50)
        let ranked = TorrentReleasePresentation.ranked([second, first, duplicate])
        XCTAssertEqual(ranked.count, 2)
        XCTAssertEqual(ranked.map(\.id), [first.id, second.id])
        XCTAssertEqual(ranked.first?.title, duplicate.title)
    }

    func testBoundedHostileReleaseTitleAndNegativeSeeds() {
        let hints = TorrentReleasePresentation(title: String(repeating: "x", count: 10_000) + " 1080p H264")
        XCTAssertNil(hints.quality)
        XCTAssertFalse(hints.prefersAppleTVHD)
        XCTAssertEqual(TorrentReleasePresentation.ranked([result("1", title: "Movie", seeds: Int.min)]).count, 1)
    }
}
