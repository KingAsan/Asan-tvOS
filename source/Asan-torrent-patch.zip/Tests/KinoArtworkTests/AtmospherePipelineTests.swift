import CoreGraphics
import ImageIO
import Foundation
import Nuke
import XCTest
@testable import KinoArtwork

private actor AtmosphereLoadCounter {
    private(set) var count = 0
    func increment() { count += 1 }
}

final class AtmospherePipelineTests: XCTestCase {
    private func artwork() throws -> Data {
        let context = try XCTUnwrap(CGContext(data: nil, width: 2400, height: 1600, bitsPerComponent: 8,
            bytesPerRow: 0, space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.noneSkipLast.rawValue))
        context.setFillColor(CGColor(red: 0.9, green: 0.1, blue: 0.2, alpha: 1))
        context.fill(CGRect(x: 0, y: 0, width: 1200, height: 1600))
        context.setFillColor(CGColor(red: 0.1, green: 0.2, blue: 0.9, alpha: 1))
        context.fill(CGRect(x: 1200, y: 0, width: 1200, height: 1600))
        let image = try XCTUnwrap(context.makeImage())
        let data = NSMutableData()
        let destination = try XCTUnwrap(CGImageDestinationCreateWithData(data, "public.png" as CFString, 1, nil))
        CGImageDestinationAddImage(destination, image, nil)
        XCTAssertTrue(CGImageDestinationFinalize(destination))
        return data as Data
    }

    func testAtmosphereUsesActualBackdropAndFallsBackOnlyToValidPoster() throws {
        let backdrop = try XCTUnwrap(URL(string: "https://images.example.invalid/backdrop.jpg"))
        let poster = try XCTUnwrap(URL(string: "https://images.example.invalid/poster.jpg"))
        XCTAssertEqual(AtmospherePipeline.request(backdropURL: backdrop, posterURL: poster)?.url, backdrop)
        XCTAssertEqual(AtmospherePipeline.request(backdropURL: URL(string: "http://images.example.invalid/a.jpg"), posterURL: poster)?.url, poster)
        XCTAssertNil(AtmospherePipeline.request(backdropURL: nil, posterURL: URL(string: "https://user:secret@images.example.invalid/a.jpg")))
        XCTAssertNil(AtmospherePipeline.request(backdropURL: nil, posterURL: nil))
    }

    func testAtmosphereIsDownsampledProcessedAndCached() async throws {
        let bytes = try artwork()
        let loads = AtmosphereLoadCounter()
        var configuration = PosterPipeline.configuration()
        configuration.dataCache = nil
        let pipeline = ImagePipeline(configuration: configuration)
        let original = ImageRequest(id: UUID().uuidString, data: {
            await loads.increment()
            return bytes
        })
        let request = AtmospherePipeline.thumbnail(original)
        let image = try await pipeline.image(for: request)
        XCTAssertEqual(request.processors.count, 1)
        XCTAssertEqual(request.processors.first?.identifier, "com.github.kean/nuke/gaussian_blur?radius=12")
        XCTAssertLessThanOrEqual(max(image.size.width, image.size.height), 480)
        XCTAssertGreaterThan(max(image.size.width, image.size.height), 400)
        _ = try await pipeline.image(for: request)
        let count = await loads.count
        XCTAssertEqual(count, 1, "A repeated details background should use the cached processed derivative")
    }
}
