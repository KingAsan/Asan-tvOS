import Foundation
import XCTest
@testable import KinoCore

final class TorrentDownloadsTests: XCTestCase {
    private let infoHashHex = "00112233445566778899aabbccddeeff00112233"
    private let completed = Date(timeIntervalSince1970: 1_800_000_000)

    private func download(total: Int64 = 1_000, downloaded: Int64 = 0) -> TorrentDownload {
        TorrentDownload(infoHash: infoHashHex, title: "Тест", totalBytes: total, downloadedBytes: downloaded,
                        addedAt: completed.addingTimeInterval(-100_000))
    }

    private func assertError<T>(_ expected: TorrentDownloadError, _ operation: @autoclosure () throws -> T,
                                file: StaticString = #filePath, line: UInt = #line) {
        XCTAssertThrowsError(try operation(), file: file, line: line) { error in
            XCTAssertEqual(error as? TorrentDownloadError, expected, file: file, line: line)
        }
    }

    func testQueuedAndPartiallyDownloadedFilmHasNoExpiry() {
        var value = download(downloaded: 700)
        XCTAssertNil(value.expiresAt)
        value.state = .downloading
        XCTAssertFalse(value.isExpired(at: completed.addingTimeInterval(100_000)))
        XCTAssertNil(value.completedAt)
    }

    func testHundredPercentCounterDoesNotClaimVerifiedCompletion() {
        let value = download(downloaded: 1_000)
        XCTAssertEqual(value.progress, 1)
        XCTAssertNil(value.expiresAt)
        XCTAssertEqual(value.state, .queued)
    }

    func testExpiryStartsAtVerifiedCompletionRatherThanAddition() {
        var value = download(downloaded: 1_000)
        value.markVerifiedComplete(at: completed)
        XCTAssertEqual(value.completedAt, completed)
        XCTAssertEqual(value.state, .completed)
        XCTAssertEqual(value.expiresAt, completed.addingTimeInterval(36_000))
    }

    func testExpiryBoundaryIsTenHoursInclusive() {
        var value = download()
        value.markVerifiedComplete(at: completed)
        XCTAssertFalse(value.isExpired(at: completed.addingTimeInterval(35_999.999)))
        XCTAssertTrue(value.isExpired(at: completed.addingTimeInterval(36_000)))
        XCTAssertTrue(value.isExpired(at: completed.addingTimeInterval(36_001)))
    }

    func testRepeatedCompletionAndPauseDoNotRenewRetention() {
        var value = download()
        value.markVerifiedComplete(at: completed)
        value.state = .paused
        XCTAssertEqual(value.expiresAt, completed.addingTimeInterval(36_000))
        value.markVerifiedComplete(at: completed.addingTimeInterval(35_000))
        XCTAssertEqual(value.completedAt, completed)
        XCTAssertTrue(value.isExpired(at: completed.addingTimeInterval(36_000)))
    }

    func testMissingCachedFileDoesNotRenewRetention() {
        var value = download()
        value.markVerifiedComplete(at: completed)
        value.state = .missing
        XCTAssertTrue(value.isExpired(at: completed.addingTimeInterval(36_000)))
    }

    func testCacheLossRestartReplacesIdentityAndCountersButKeepsSelectedFile() {
        var original = download(downloaded: 1_000)
        original.fileIndex = 4
        original.fileName = "Season 1/episode.mp4"
        original.markVerifiedComplete(at: completed)
        original.state = .missing
        let restartedAt = completed.addingTimeInterval(34_200)
        let replacement = original.restartedAfterCacheLoss(at: restartedAt)
        XCTAssertNotEqual(replacement.id, original.id)
        XCTAssertEqual(replacement.infoHash, original.infoHash)
        XCTAssertEqual(replacement.title, original.title)
        XCTAssertEqual(replacement.fileIndex, original.fileIndex)
        XCTAssertEqual(replacement.fileName, original.fileName)
        XCTAssertEqual(replacement.totalBytes, original.totalBytes)
        XCTAssertEqual(replacement.downloadedBytes, 0)
        XCTAssertEqual(replacement.state, .paused)
        XCTAssertEqual(replacement.addedAt, restartedAt)
        XCTAssertNil(replacement.completedAt)
        XCTAssertNil(replacement.expiresAt)
        XCTAssertEqual(original.completedAt, completed)
    }

    func testCacheLossRestartLifetimeStartsOnlyAfterTheNewVerifiedCompletion() {
        var original = download(downloaded: 1_000)
        original.markVerifiedComplete(at: completed)
        var replacement = original.restartedAfterCacheLoss(at: completed.addingTimeInterval(35_000))
        XCTAssertTrue(original.isExpired(at: completed.addingTimeInterval(36_001)))
        XCTAssertFalse(replacement.isExpired(at: completed.addingTimeInterval(36_001)))
        let finishedAgain = completed.addingTimeInterval(40_000)
        replacement.markVerifiedComplete(at: finishedAgain)
        XCTAssertEqual(replacement.expiresAt, finishedAgain.addingTimeInterval(36_000))
        replacement.markVerifiedComplete(at: finishedAgain.addingTimeInterval(100))
        XCTAssertEqual(replacement.completedAt, finishedAgain)
    }

    func testRelaunchRoundTripKeepsOriginalExpiryAndIdentifier() throws {
        var value = download(downloaded: 1_000)
        value.fileIndex = 3
        value.fileName = "Season 1/episode.mp4"
        value.markVerifiedComplete(at: completed)
        let restored = try JSONDecoder().decode(TorrentDownload.self, from: JSONEncoder().encode(value))
        XCTAssertEqual(restored, value)
        XCTAssertTrue(restored.isExpired(at: completed.addingTimeInterval(36_001)))
    }

    func testProgressHandlesUnknownNegativeAndOvershootingCounters() {
        XCTAssertEqual(download(total: 0, downloaded: 100).progress, 0)
        XCTAssertEqual(download(total: -1, downloaded: 100).progress, 0)
        XCTAssertEqual(download(downloaded: -1).progress, 0)
        XCTAssertEqual(download(downloaded: 250).progress, 0.25)
        XCTAssertEqual(download(downloaded: 1_100).progress, 1)
        XCTAssertTrue(download(total: .max, downloaded: .max).progress.isFinite)
    }

    func testHexMagnetCanonicalizesHashAndDisplayName() throws {
        let value = try TorrentMagnet("  MAGNET:?xt=urn:btih:\(infoHashHex.uppercased())&dn=%D0%A2%D0%B5%D1%81%D1%82  ")
        XCTAssertEqual(value.infoHash, infoHashHex)
        XCTAssertEqual(value.displayName, "Тест")
        let reparsed = try TorrentMagnet(value.uri)
        XCTAssertEqual(reparsed, value)
    }

    func testBase32MagnetProducesSameTwentyByteHash() throws {
        let value = try TorrentMagnet("magnet:?xt=urn:btih:AAISEM2EKVTHPCEZVK54ZXPO74ABCIRT")
        XCTAssertEqual(value.infoHash, infoHashHex)
        XCTAssertEqual(try TorrentMagnet("magnet:?xt=urn:btih:aaisem2ekvthpcezvk54zxpo74abcirt").infoHash, infoHashHex)
    }

    func testDuplicateEquivalentHashesAreCollapsed() throws {
        let value = try TorrentMagnet("magnet:?xt=urn:btih:\(infoHashHex)&xt=urn:btih:AAISEM2EKVTHPCEZVK54ZXPO74ABCIRT")
        let topics = URLComponents(string: value.uri)?.queryItems?.filter { $0.name == "xt" }
        XCTAssertEqual(topics?.count, 1)
    }

    func testConflictingHashesAreRejected() {
        assertError(.conflictingHashes, try TorrentMagnet("magnet:?xt=urn:btih:\(infoHashHex)&xt=urn:btih:\(String(repeating: "0", count: 40))"))
    }

    func testMissingAndV2OnlyHashesAreExplicitlyUnsupported() {
        assertError(.unsupportedHash, try TorrentMagnet("magnet:?dn=Film"))
        assertError(.unsupportedHash, try TorrentMagnet("magnet:?xt=urn:btmh:1220abcdef"))
    }

    func testInvalidHashAlphabetAndLengthAreRejected() {
        for candidate in ["short", String(repeating: "g", count: 40), String(repeating: "0", count: 32),
                          String(repeating: "A", count: 31), String(repeating: "ß", count: 16)] {
            assertError(.invalidMagnet, try TorrentMagnet("magnet:?xt=urn:btih:\(candidate)"))
        }
    }

    func testPlainHttpFileAndMagnetHostOrPathAreRejected() {
        for input in ["https://example.invalid/file.torrent", "file:///tmp/file.torrent", infoHashHex,
                      "magnet://example.invalid?xt=urn:btih:\(infoHashHex)",
                      "magnet:/payload?xt=urn:btih:\(infoHashHex)", "magnet:?xt=urn:btih:\(infoHashHex)#fragment"] {
            assertError(.invalidMagnet, try TorrentMagnet(input))
        }
    }

    func testMalformedEscapesAndControlCharactersAreRejected() {
        for suffix in ["&dn=%", "&dn=%0", "&dn=%XY", "&dn=a\nb"] {
            assertError(.invalidMagnet, try TorrentMagnet("magnet:?xt=urn:btih:\(infoHashHex)" + suffix))
        }
    }

    func testOversizedInputAndExcessiveParametersAreRejected() {
        assertError(.invalidMagnet, try TorrentMagnet("magnet:?xt=urn:btih:\(infoHashHex)&dn=" + String(repeating: "x", count: 16_384)))
        assertError(.invalidMagnet, try TorrentMagnet("magnet:?xt=urn:btih:\(infoHashHex)" + String(repeating: "&a=b", count: 128)))
    }

    func testSafeTrackersAreKeptOnceAndOtherSourcesAreNotForwarded() throws {
        let input = "magnet:?xt=urn:btih:\(infoHashHex)&tr=udp%3A%2F%2Ftracker.example.invalid%3A6969%2Fannounce"
            + "&tr=udp%3A%2F%2Ftracker.example.invalid%3A6969%2Fannounce"
            + "&tr=https%3A%2F%2Ftracker.example.invalid%2Fannounce%3Fkey%3Da%252Bb"
            + "&xs=file%3A%2F%2F%2Fprivate%2Ffile&ws=http%3A%2F%2Fexample.invalid%2F&x.pe=127.0.0.1%3A22"
        let value = try TorrentMagnet(input)
        let items = try XCTUnwrap(URLComponents(string: value.uri)?.queryItems)
        XCTAssertEqual(items.filter { $0.name == "tr" }.count, 2)
        XCTAssertEqual(items.first { $0.name == "tr" }?.value, "udp://tracker.example.invalid:6969/announce")
        XCTAssertEqual(Set(items.map(\.name)), ["xt", "tr"])
        XCTAssertTrue(items.contains { $0.value == "https://tracker.example.invalid/announce?key=a%2Bb" })
    }

    func testUnsafeTrackerSchemesCredentialsAndFragmentsAreDropped() throws {
        var components = URLComponents()
        components.scheme = "magnet"
        components.queryItems = [URLQueryItem(name: "xt", value: "urn:btih:" + infoHashHex)] +
            ["file:///private/file", "javascript:alert(1)", "https://user:secret@example.invalid/a",
             "https://example.invalid/a#fragment", "udp://example.invalid:0/a", "https://example.invalid/a\nb"]
            .map { URLQueryItem(name: "tr", value: $0) }
        let value = try TorrentMagnet(try XCTUnwrap(components.string))
        XCTAssertEqual(URLComponents(string: value.uri)?.queryItems?.count, 1)
        XCTAssertFalse(value.uri.contains("secret"))
    }

    func testEncodedControlNameDoesNotReachEngineOrDisplay() throws {
        let value = try TorrentMagnet("magnet:?xt=urn:btih:\(infoHashHex)&dn=Film%00Name")
        XCTAssertNil(value.displayName)
        XCTAssertEqual(URLComponents(string: value.uri)?.queryItems?.count, 1)
    }

    func testAdmissionPreservesOneGiBReserveAtExactBoundary() throws {
        let size: Int64 = 500
        try TorrentDownloadPolicy.validateAdmission(fileBytes: size, usedBytes: 0,
            availableBytes: TorrentDownloadPolicy.reserveBytes + size)
        assertError(.insufficientSpace, try TorrentDownloadPolicy.validateAdmission(fileBytes: size, usedBytes: 0,
            availableBytes: TorrentDownloadPolicy.reserveBytes + size - 1))
    }

    func testAdmissionReservesOtherJobsFullSelectedSizes() throws {
        let budget = TorrentDownloadPolicy.defaultBudgetBytes
        try TorrentDownloadPolicy.validateAdmission(fileBytes: 1_000, usedBytes: budget - 1_000, availableBytes: .max)
        assertError(.budgetExceeded, try TorrentDownloadPolicy.validateAdmission(fileBytes: 1_001,
            usedBytes: budget - 1_000, availableBytes: .max))
    }

    func testUnknownAndNegativeMetadataNeverAdmitAFile() {
        assertError(.unknownFileSize, try TorrentDownloadPolicy.validateAdmission(fileBytes: 0, usedBytes: 0, availableBytes: .max))
        assertError(.invalidSize, try TorrentDownloadPolicy.validateAdmission(fileBytes: -1, usedBytes: 0, availableBytes: .max))
        assertError(.invalidSize, try TorrentDownloadPolicy.validateAdmission(fileBytes: 1, usedBytes: -1, availableBytes: .max))
        assertError(.invalidSize, try TorrentDownloadPolicy.validateAdmission(fileBytes: 1, usedBytes: 0, availableBytes: -1))
    }

    func testInvalidBudgetsAreRejected() {
        for budget in [Int64(0), -1, TorrentDownloadPolicy.maximumBudgetBytes + 1] {
            assertError(.invalidBudget, try TorrentDownloadPolicy.validateAdmission(fileBytes: 1, usedBytes: 0,
                availableBytes: .max, budgetBytes: budget))
        }
    }

    func testExtremeMetadataCannotOverflowAdmissionMath() {
        assertError(.budgetExceeded, try TorrentDownloadPolicy.validateAdmission(fileBytes: .max, usedBytes: 0, availableBytes: .max))
        assertError(.budgetExceeded, try TorrentDownloadPolicy.validateAdmission(fileBytes: 1, usedBytes: .max, availableBytes: .max))
    }

    func testMaximumBudgetCanBeChosenExplicitly() throws {
        try TorrentDownloadPolicy.validateAdmission(fileBytes: TorrentDownloadPolicy.maximumBudgetBytes,
            usedBytes: 0, availableBytes: .max, budgetBytes: TorrentDownloadPolicy.maximumBudgetBytes)
    }

    func testSafeRelativeMoviePathsRemainUsable() {
        for path in ["film.mp4", "Film 2026/film.mkv", "Сезон 1/Серия 2.mp4", "100%.mp4"] {
            XCTAssertTrue(TorrentDownloadPolicy.isSafeRelativePath(path), path)
        }
    }

    func testAbsoluteTraversalWindowsAndControlPathsAreRejected() {
        for path in ["", "/film.mp4", "../film.mp4", "a/../../film.mp4", "a/./film.mp4", "a//film.mp4", "a/",
                     "C:/film.mp4", "a\\film.mp4", "\\\\server\\film.mp4", "~/film.mp4", "a/fi\0lm.mp4"] {
            XCTAssertFalse(TorrentDownloadPolicy.isSafeRelativePath(path), path)
        }
    }

    func testEncodedPathTraversalAndSeparatorsAreRejected() {
        for path in ["%2e%2e/film.mp4", "a/%2e%2e/film.mp4", "%252e%252e/film.mp4", "%2ffilm.mp4", "a%5c..%5cfilm.mp4", "a/%00film.mp4"] {
            XCTAssertFalse(TorrentDownloadPolicy.isSafeRelativePath(path), path)
        }
    }

    func testExcessivePathAndComponentLengthsAreRejected() {
        XCTAssertFalse(TorrentDownloadPolicy.isSafeRelativePath(String(repeating: "a", count: 256) + ".mp4"))
        XCTAssertFalse(TorrentDownloadPolicy.isSafeRelativePath(String(repeating: "a/", count: 513) + "f.mp4"))
    }
}
