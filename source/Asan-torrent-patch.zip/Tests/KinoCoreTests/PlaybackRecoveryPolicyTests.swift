import XCTest
@testable import KinoCore

final class PlaybackRecoveryPolicyTests: XCTestCase {
    func testInitialConnectionAndUserPauseNeverOfferTorrents() {
        var policy = PlaybackRecoveryPolicy()
        for time in [0.0, 4, 10, 30] { XCTAssertFalse(policy.observe(isWaiting: true, hasStarted: false, at: time)) }
        for time in [31.0, 40, 50] { XCTAssertFalse(policy.observe(isWaiting: false, hasStarted: true, at: time)) }
    }

    func testTwoDistinctThreeSecondWaitsOfferOnce() {
        var policy = PlaybackRecoveryPolicy()
        XCTAssertFalse(policy.observe(isWaiting: true, hasStarted: true, at: 10))
        XCTAssertFalse(policy.observe(isWaiting: true, hasStarted: true, at: 12))
        XCTAssertFalse(policy.observe(isWaiting: true, hasStarted: true, at: 13))
        XCTAssertFalse(policy.observe(isWaiting: true, hasStarted: true, at: 18), "One continuous stall must count once")
        XCTAssertFalse(policy.observe(isWaiting: false, hasStarted: true, at: 19))
        XCTAssertFalse(policy.observe(isWaiting: true, hasStarted: true, at: 25))
        XCTAssertTrue(policy.observe(isWaiting: true, hasStarted: true, at: 28))
        XCTAssertFalse(policy.observe(isWaiting: true, hasStarted: true, at: 40))
        XCTAssertTrue(policy.hasOffered)
    }

    func testOldStallExpiresAndSeekClearsCurrentWait() {
        var policy = PlaybackRecoveryPolicy()
        _ = policy.observe(isWaiting: true, hasStarted: true, at: 1)
        _ = policy.observe(isWaiting: true, hasStarted: true, at: 4)
        _ = policy.observe(isWaiting: false, hasStarted: true, at: 5)
        _ = policy.observe(isWaiting: true, hasStarted: true, at: 70)
        XCTAssertFalse(policy.observe(isWaiting: true, hasStarted: true, at: 73))
        policy.suppressForSeek(at: 74)
        XCTAssertFalse(policy.observe(isWaiting: true, hasStarted: true, at: 78))
        XCTAssertFalse(policy.observe(isWaiting: true, hasStarted: true, at: 79))
        XCTAssertFalse(policy.observe(isWaiting: true, hasStarted: true, at: 82), "A seek must not recount the pre-seek stall")
        _ = policy.observe(isWaiting: false, hasStarted: true, at: 83)
        _ = policy.observe(isWaiting: true, hasStarted: true, at: 90)
        XCTAssertTrue(policy.observe(isWaiting: true, hasStarted: true, at: 93))
    }

    func testSkipIsAbsoluteAndCannotRewindOrSkipWholeEpisode() {
        XCTAssertEqual(IntroPlaybackPolicy.target(position: 12, duration: 1800, introSeconds: 90), 90)
        XCTAssertNil(IntroPlaybackPolicy.target(position: 95, duration: 1800, introSeconds: 90))
        XCTAssertNil(IntroPlaybackPolicy.target(position: 0, duration: 60, introSeconds: 90))
        XCTAssertNil(IntroPlaybackPolicy.target(position: 0, duration: .infinity, introSeconds: 90))
        XCTAssertNil(IntroPlaybackPolicy.target(position: .nan, duration: 1800, introSeconds: 90))
        XCTAssertNil(IntroPlaybackPolicy.target(position: 0, duration: 1800, introSeconds: 601))
    }

    func testCompletedOrInvalidLocalResumeRestarts() {
        XCTAssertEqual(IntroPlaybackPolicy.resume(position: 12, duration: 30), 12)
        XCTAssertEqual(IntroPlaybackPolicy.resume(position: 29, duration: 30), 0)
        XCTAssertEqual(IntroPlaybackPolicy.resume(position: .nan, duration: 30), 0)
        XCTAssertEqual(IntroPlaybackPolicy.resume(position: 12, duration: 0), 0)
    }
}
