import Foundation
import XCTest
@testable import KinoCore

final class QueueResumeIntentTests: XCTestCase {
    private func download(state: TorrentDownloadState = .paused, order: Int? = nil) -> TorrentDownload {
        TorrentDownload(infoHash: String(repeating: "1", count: 40), title: "Series S01E01",
            fileIndex: 0, fileName: "Series/S01E01.mp4", totalBytes: 1_024,
            downloadedBytes: 512, state: state, queueOrder: order)
    }

    func testSavedActiveDownloadResumesEvenFromLegacyManifest() {
        XCTAssertTrue(TorrentQueuePolicy.shouldResumeAfterLaunch(download(state: .downloading)))
    }

    func testBackgroundPausedQueueMemberResumesBeforeNextPendingFile() {
        let paused = download(order: 0)
        var pending = download(state: .queued, order: 1)
        pending.downloadedBytes = 0
        XCTAssertTrue(TorrentQueuePolicy.shouldResumeAfterLaunch(paused))
        XCTAssertFalse(TorrentQueuePolicy.shouldResumeAfterLaunch(pending))
        XCTAssertEqual(TorrentQueuePolicy.ordered([pending, paused]).map(\.id), [pending.id])
    }

    func testExplicitUserPauseClearsDurableAutomaticResumeIntent() {
        var item = download(order: 0)
        XCTAssertTrue(TorrentQueuePolicy.shouldResumeAfterLaunch(item))
        item.queueOrder = nil
        XCTAssertFalse(TorrentQueuePolicy.shouldResumeAfterLaunch(item))
        XCTAssertEqual(item.downloadedBytes, 512)
        XCTAssertEqual(TorrentQueuePolicy.reservedBytes(in: [item]), 1_024)
    }

    func testTerminalAndPendingStatesNeverResumeAsInterruptedActivePayload() {
        for state in [TorrentDownloadState.queued, .completed, .failed, .missing] {
            XCTAssertFalse(TorrentQueuePolicy.shouldResumeAfterLaunch(download(state: state, order: 0)), state.rawValue)
        }
    }

    func testMissingOrUnsafeSelectedMetadataNeverStartsAutomatically() {
        var item = download(order: 0)
        item.queueOrder = -1
        XCTAssertFalse(TorrentQueuePolicy.shouldResumeAfterLaunch(item))
        item.queueOrder = 0
        item.fileIndex = nil
        XCTAssertFalse(TorrentQueuePolicy.shouldResumeAfterLaunch(item))
        item.fileIndex = -1
        XCTAssertFalse(TorrentQueuePolicy.shouldResumeAfterLaunch(item))
        item.fileIndex = 0
        item.fileName = "../outside.mp4"
        XCTAssertFalse(TorrentQueuePolicy.shouldResumeAfterLaunch(item))
        item.fileName = "Series/S01E01.mp4"
        item.totalBytes = 0
        XCTAssertFalse(TorrentQueuePolicy.shouldResumeAfterLaunch(item))
    }

    func testCompletionTimestampCannotBeResetThroughAutomaticResume() {
        var item = download(order: 0)
        item.markVerifiedComplete(at: Date(timeIntervalSince1970: 100))
        item.state = .paused
        XCTAssertFalse(TorrentQueuePolicy.shouldResumeAfterLaunch(item))
        XCTAssertEqual(item.completedAt, Date(timeIntervalSince1970: 100))
    }

    func testPausedQueueIntentSurvivesActualCodableRoundTrip() throws {
        let item = download(order: 3)
        let restored = try JSONDecoder().decode(TorrentDownload.self, from: JSONEncoder().encode(item))
        XCTAssertEqual(restored, item)
        XCTAssertTrue(TorrentQueuePolicy.shouldResumeAfterLaunch(restored))
    }

    func testLegacyPausedManifestWithoutNewFieldsDoesNotBecomeAutoQueue() throws {
        let data = try JSONEncoder().encode(download())
        var object = try XCTUnwrap(JSONSerialization.jsonObject(with: data) as? [String: Any])
        for key in ["queueOrder", "mediaAssociation", "localPosition", "localDuration"] { object.removeValue(forKey: key) }
        let restored = try JSONDecoder().decode(TorrentDownload.self, from: JSONSerialization.data(withJSONObject: object))
        XCTAssertNil(restored.queueOrder)
        XCTAssertFalse(TorrentQueuePolicy.shouldResumeAfterLaunch(restored))
    }

    func testBlockedPartialHeadCannotBeBypassedBySmallerLaterEpisode() {
        var head = download(order: 0)
        head.totalBytes = 2 * 1_024 * 1_024 * 1_024
        var later = download(state: .queued, order: 1)
        later.downloadedBytes = 0
        later.totalBytes = 1_024 * 1_024
        XCTAssertEqual(TorrentQueuePolicy.automaticHead(in: [later, head])?.id, head.id)
        XCTAssertThrowsError(try TorrentQueuePolicy.automaticAdmission(in: [later, head],
            availableBytes: TorrentDownloadPolicy.reserveBytes + head.totalBytes - 1, headAllocatedBytes: 0)) {
            XCTAssertEqual($0 as? TorrentDownloadError, .insufficientSpace)
        }
    }

    func testPhysicalAllocationCreditAdmitsElevenGiBPartialHeadAtExactReserveBoundary() throws {
        var head = download(order: 0)
        head.totalBytes = 11 * 1_024 * 1_024 * 1_024
        head.downloadedBytes = head.totalBytes // Saved progress alone must never authorize admission.
        let free = TorrentDownloadPolicy.reserveBytes + head.totalBytes / 2
        XCTAssertThrowsError(try TorrentQueuePolicy.automaticAdmission(in: [head], availableBytes: free, headAllocatedBytes: 0))
        XCTAssertEqual(try TorrentQueuePolicy.automaticAdmission(in: [head], availableBytes: free,
            headAllocatedBytes: head.totalBytes / 2)?.id, head.id)
        XCTAssertEqual(head.downloadedBytes, head.totalBytes)
        XCTAssertNil(head.completedAt)
    }

    func testAllocationCreditCannotEvadeTotalCacheBudgetOrRetainedCompletedFile() {
        var head = download(order: 0)
        head.totalBytes = 2 * 1_024 * 1_024 * 1_024
        var complete = download(state: .completed)
        complete.totalBytes = 10 * 1_024 * 1_024 * 1_024
        complete.markVerifiedComplete()
        XCTAssertThrowsError(try TorrentQueuePolicy.automaticAdmission(in: [head, complete],
            availableBytes: 100 * 1_024 * 1_024 * 1_024, headAllocatedBytes: head.totalBytes)) {
            XCTAssertEqual($0 as? TorrentDownloadError, .budgetExceeded)
        }
    }

    func testUserPauseAllowsFollowingHeadButRetainsActualCacheReservation() throws {
        var paused = download(order: nil)
        var later = download(state: .queued, order: 1)
        later.downloadedBytes = 0
        paused.totalBytes = 1_024
        XCTAssertEqual(TorrentQueuePolicy.automaticHead(in: [paused, later])?.id, later.id)
        XCTAssertEqual(TorrentQueuePolicy.reservedBytes(in: [paused, later]), paused.totalBytes)
        XCTAssertEqual(try TorrentQueuePolicy.automaticAdmission(in: [paused, later],
            availableBytes: TorrentDownloadPolicy.reserveBytes + later.totalBytes, headAllocatedBytes: 0)?.id, later.id)
    }

    func testFailedAutomaticHeadBlocksLaterPayloadUntilExplicitUserAction() throws {
        let failed = download(state: .failed, order: 0)
        var later = download(state: .queued, order: 1)
        later.downloadedBytes = 0
        XCTAssertEqual(TorrentQueuePolicy.automaticHead(in: [later, failed])?.id, failed.id)
        XCTAssertNil(try TorrentQueuePolicy.automaticAdmission(in: [later, failed], availableBytes: Int64.max, headAllocatedBytes: 0))
        XCTAssertEqual(try TorrentQueuePolicy.automaticAdmission(in: [later], availableBytes: Int64.max, headAllocatedBytes: 0)?.id, later.id)
    }

    func testActivePayloadAndInvalidPhysicalCreditCannotAuthorizeAnotherStart() throws {
        let active = download(state: .downloading, order: 0)
        var later = download(state: .queued, order: 1)
        later.downloadedBytes = 0
        XCTAssertNil(try TorrentQueuePolicy.automaticAdmission(in: [active, later], availableBytes: Int64.max, headAllocatedBytes: 0))
        XCTAssertThrowsError(try TorrentQueuePolicy.automaticAdmission(in: [later], availableBytes: Int64.max, headAllocatedBytes: -1))
    }
}
