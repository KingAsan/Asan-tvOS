import Foundation
import XCTest
@testable import KinoCore

private struct Core07StoredEnvelope: Codable { var download: TorrentDownload; var magnet: String }
private struct Core06Download: Encodable {
    var id: UUID; var infoHash: String; var title: String; var fileIndex: Int?; var fileName: String?
    var totalBytes: Int64; var downloadedBytes: Int64; var state: TorrentDownloadState
    var addedAt: Date; var completedAt: Date?
}
private struct Core06StoredEnvelope: Encodable { var download: Core06Download; var magnet: String }
private struct Core06Library: Encodable {
    var schemaVersion = 1; var favorites: [SavedMedia]; var watchlist: [SavedMedia]; var history: [WatchProgress]
}

final class Core07StateTests: XCTestCase {
    private let hashText = "00112233445566778899aabbccddeeff00112233"
    private let now = Date(timeIntervalSince1970: 1_800_000_000)
    private let gib: Int64 = 1_073_741_824
    private var series: MediaItem {
        MediaItem(id: "series", title: "Owned series", kind: .series, seasons: [
            Season(id: "s1", title: "One", number: 1, episodes: [
                Episode(id: "rezka-101", title: "First", number: 1), Episode(id: "rezka-102", title: "Second", number: 2)
            ]),
            Season(id: "s2", title: "Two", number: 2, episodes: [Episode(id: "rezka-201", title: "Next season", number: 1)])
        ])
    }
    private func queued(order: Int, size: Int64? = nil, association: TorrentMediaAssociation? = nil) -> TorrentDownload {
        TorrentDownload(infoHash: hashText, title: "File", fileIndex: order, fileName: "Series/file\(order).mp4",
            totalBytes: size ?? gib, state: .queued, addedAt: now, mediaAssociation: association, queueOrder: order)
    }
    private func complete(_ input: TorrentDownload, at date: Date? = nil) -> TorrentDownload {
        var value = input
        value.downloadedBytes = value.totalBytes
        value.markVerifiedComplete(at: date ?? now)
        return value
    }

    func testLegacy06StoredEnvelopeDecodesWithoutChangingDownloadIdentityOrTTL() throws {
        let old = Core06Download(id: UUID(), infoHash: hashText, title: "Legacy film", fileIndex: 2,
            fileName: "legacy.mp4", totalBytes: 1234, downloadedBytes: 1234, state: .completed,
            addedAt: now.addingTimeInterval(-100), completedAt: now)
        let bytes = try JSONEncoder().encode(Core06StoredEnvelope(download: old, magnet: "magnet:?xt=urn:btih:" + hashText))
        let restored = try JSONDecoder().decode(Core07StoredEnvelope.self, from: bytes)
        XCTAssertEqual(restored.download.id, old.id)
        XCTAssertEqual(restored.download.fileName, old.fileName)
        XCTAssertEqual(restored.download.infoHash, old.infoHash)
        XCTAssertEqual(restored.download.completedAt, old.completedAt)
        XCTAssertEqual(restored.download.expiresAt, now.addingTimeInterval(36_000))
        XCTAssertNil(restored.download.mediaAssociation)
        XCTAssertNil(restored.download.queueOrder)
        XCTAssertEqual(restored.download.localPosition, 0)
        XCTAssertEqual(restored.download.localDuration, 0)
        XCTAssertEqual(try JSONDecoder().decode(Core07StoredEnvelope.self, from: JSONEncoder().encode(restored)), restored)
    }

    func testLocalPositionDecodeClampsOvershootAndRejectsMalformedNewValues() throws {
        let original = queued(order: 0)
        let bytes = try JSONEncoder().encode(original)
        var fields = try XCTUnwrap(JSONSerialization.jsonObject(with: bytes) as? [String: Any])
        fields["localPosition"] = 200
        fields["localDuration"] = 100
        let restored = try JSONDecoder().decode(TorrentDownload.self, from: JSONSerialization.data(withJSONObject: fields))
        XCTAssertEqual(restored.localPosition, 100)
        for key in ["localPosition", "localDuration", "queueOrder"] {
            var invalid = fields
            invalid[key] = -1
            XCTAssertThrowsError(try JSONDecoder().decode(TorrentDownload.self, from: JSONSerialization.data(withJSONObject: invalid)))
        }
        fields["localPosition"] = "NaN"
        let decoder = JSONDecoder()
        decoder.nonConformingFloatDecodingStrategy = .convertFromString(positiveInfinity: "Infinity", negativeInfinity: "-Infinity", nan: "NaN")
        XCTAssertThrowsError(try decoder.decode(TorrentDownload.self, from: JSONSerialization.data(withJSONObject: fields)))
    }

    func testRecordLocalProgressRejectsInvalidInputWithoutMutationAndSupportsUnknownDuration() throws {
        var value = queued(order: 0)
        try value.recordLocalProgress(position: 200, duration: 100)
        XCTAssertEqual(value.localPosition, 100)
        let before = value
        XCTAssertThrowsError(try value.recordLocalProgress(position: .infinity, duration: 100))
        XCTAssertEqual(value, before)
        try value.recordLocalProgress(position: 250, duration: 0)
        XCTAssertEqual(value.localPosition, 250)
        XCTAssertEqual(value.localDuration, 0)
    }

    func testCacheLossRestartKeepsMediaAndLocalProgressButNotQueueOrOldLifetime() throws {
        let association = try TorrentMediaAssociation(media: series, providerID: "rezka", episodeID: "rezka-102")
        var value = complete(queued(order: 4, association: association))
        try value.recordLocalProgress(position: 70, duration: 100)
        let replacement = value.restartedAfterCacheLoss(at: now.addingTimeInterval(30_000))
        XCTAssertNotEqual(replacement.id, value.id)
        XCTAssertEqual(replacement.mediaAssociation, association)
        XCTAssertEqual(replacement.localPosition, 70)
        XCTAssertEqual(replacement.localDuration, 100)
        XCTAssertNil(replacement.queueOrder)
        XCTAssertNil(replacement.completedAt)
        XCTAssertEqual(replacement.state, .paused)
    }

    func testAssociationCompactsStreamsAndOnlyResolvedEpisodeForExistingHistory() async throws {
        var original = series
        original.streams = [StreamVariant(id: "secret", title: "Runtime", url: URL(string: "https://example.invalid/expiring.m3u8")!)]
        let association = try TorrentMediaAssociation(media: original, providerID: "rezka", episodeID: "rezka-102")
        XCTAssertTrue(association.canRecordProgress)
        XCTAssertEqual(association.seasonNumber, 1)
        XCTAssertEqual(association.episodeNumber, 2)
        XCTAssertEqual(association.media.seasons.flatMap(\.episodes).map(\.id), ["rezka-102"])
        XCTAssertTrue(association.media.streams.isEmpty)
        let data = try JSONEncoder().encode(association)
        XCTAssertFalse(String(decoding: data, as: UTF8.self).contains("expiring"))
        XCTAssertEqual(try JSONDecoder().decode(TorrentMediaAssociation.self, from: data), association)
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: directory) }
        let store = LibraryStore(fileURL: directory.appendingPathComponent("library.json"))
        try await store.recordProgress(media: association.media, providerID: association.reference.providerID,
            episodeID: association.episodeID, position: 25, duration: 100)
        let progress = try await store.progress(for: association.reference, episodeID: association.episodeID)
        XCTAssertEqual(progress?.id, association.progressID)
        XCTAssertEqual(progress?.position, 25)
    }

    func testUnknownSeriesContextCannotClaimCanonicalEpisodeHistory() throws {
        let value = try TorrentMediaAssociation(media: series, providerID: "rezka")
        XCTAssertFalse(value.canRecordProgress)
        XCTAssertNil(value.resolvedEpisode)
        XCTAssertThrowsError(try TorrentMediaAssociation(media: series, providerID: "rezka", episodeID: "not-real"))
        XCTAssertThrowsError(try TorrentMediaAssociation(reference: MediaReference(providerID: "rezka", itemID: "wrong"), media: series))
    }

    func testFilenameMappingRequiresSingleExplicitKnownCatalogEpisode() {
        let value = TorrentMediaAssociation.resolvingFile(name: "Season 1/Owned.Show.S01E02-1080p.mkv", media: series, providerID: "rezka")
        XCTAssertEqual(value?.episodeID, "rezka-102")
        for filename in ["Owned.Show.02.mkv", "Owned.Show.S01E99.mkv", "Owned.Show.S01E01-E02.mkv",
                         "Owned.Show.S01E01E02.mkv", "Owned.Show.S01E01-S01E02.mkv", "Owned.Show.S01E02bonus.mkv", "../S01E01.mkv"] {
            XCTAssertNil(TorrentMediaAssociation.resolvingFile(name: filename, media: series, providerID: "rezka"), filename)
        }
    }

    func testFilenameMappingDoesNotPickOneOfDuplicateCatalogNumbers() {
        var ambiguous = series
        ambiguous.seasons[0].episodes.append(Episode(id: "duplicate-number", title: "Ambiguous", number: 2))
        XCTAssertNil(TorrentMediaAssociation.resolvingFile(name: "show.S01E02.mp4", media: ambiguous, providerID: "rezka"))
    }

    func testMovieFileAssociationUsesReferenceWithoutInventingAnEpisode() {
        let movie = MediaItem(id: "film", title: "Film", kind: .movie)
        let value = TorrentMediaAssociation.resolvingFile(name: "feature.mp4", media: movie, providerID: "rezka")
        XCTAssertTrue(value?.canRecordProgress == true)
        XCTAssertNil(value?.episodeID)
    }

    func testCacheLookupIsEpisodeAndProviderSpecificAndNeverTrustsLegacyTitleGuessing() throws {
        let association = try TorrentMediaAssociation(media: series, providerID: "rezka", episodeID: "rezka-102")
        let good = complete(queued(order: 0, association: association))
        let other = complete(queued(order: 1, association: try TorrentMediaAssociation(media: series, providerID: "other", episodeID: "rezka-102")))
        let legacy = complete(queued(order: 2))
        XCTAssertEqual(TorrentDownloadPolicy.cachedDownload(in: [other, legacy, good], reference: association.reference,
            episodeID: "rezka-102", at: now)?.id, good.id)
        XCTAssertNil(TorrentDownloadPolicy.cachedDownload(in: [good], reference: association.reference, episodeID: "rezka-101", at: now))
        XCTAssertNil(TorrentDownloadPolicy.cachedDownload(in: [legacy], reference: association.reference, episodeID: "rezka-102", at: now))
    }

    func testCacheLookupRequiresCompletionMetadataSafePathAndUnexpiredLifetime() throws {
        let association = try TorrentMediaAssociation(media: MediaItem(id: "film", title: "Film", kind: .movie), providerID: "rezka")
        let good = complete(queued(order: 0, association: association))
        XCTAssertNotNil(TorrentDownloadPolicy.cachedDownload(in: [good], reference: association.reference, at: now.addingTimeInterval(35_999)))
        XCTAssertNil(TorrentDownloadPolicy.cachedDownload(in: [good], reference: association.reference, at: now.addingTimeInterval(36_000)))
        var missing = good; missing.state = .missing
        var noTimestamp = good; noTimestamp.completedAt = nil
        var unsafe = good; unsafe.fileName = "../file.mp4"
        var noSelected = good; noSelected.fileIndex = nil
        var noBytes = good; noBytes.downloadedBytes = 0
        for value in [missing, noTimestamp, unsafe, noSelected, noBytes] {
            XCTAssertNil(TorrentDownloadPolicy.cachedDownload(in: [value], reference: association.reference, at: now))
        }
    }

    func testPendingSixEpisodeQueueDoesNotReserveEveryFuturePayload() throws {
        let values = (0..<6).map { queued(order: $0) }
        XCTAssertEqual(TorrentQueuePolicy.reservedBytes(in: values), 0)
        XCTAssertEqual(try TorrentQueuePolicy.nextAdmission(in: values, availableBytes: 8 * gib)?.id, values[0].id)
    }

    func testQueueWaitsAtBudgetAndOnlyReschedulesAfterConfirmedDeletionNotTTLMetadata() throws {
        var values = (0..<6).map { queued(order: $0, size: 3 * gib) }
        values[3].totalBytes = 2 * gib
        for index in 0..<4 { values[index] = complete(values[index]) }
        XCTAssertEqual(TorrentQueuePolicy.reservedBytes(in: values), 11 * gib)
        XCTAssertThrowsError(try TorrentQueuePolicy.nextAdmission(in: values, availableBytes: 8 * gib)) {
            XCTAssertEqual($0 as? TorrentDownloadError, .budgetExceeded)
        }
        XCTAssertTrue(values[0].isExpired(at: now.addingTimeInterval(36_001)))
        XCTAssertEqual(TorrentQueuePolicy.reservedBytes(in: values), 11 * gib)
        values.removeFirst() // Model calls this only after actual owned-file deletion.
        XCTAssertEqual(try TorrentQueuePolicy.nextAdmission(in: values, availableBytes: 8 * gib)?.id, values[3].id)
    }

    func testQueuePreservesFreeSpaceMarginAndHeadOrderInsteadOfSkippingToSmallerFile() throws {
        let head = queued(order: 0, size: 2 * gib)
        let smaller = queued(order: 1, size: gib / 2)
        let held = complete(queued(order: 9, size: 10 * gib))
        XCTAssertThrowsError(try TorrentQueuePolicy.nextAdmission(in: [head, smaller, held], availableBytes: 8 * gib)) {
            XCTAssertEqual($0 as? TorrentDownloadError, .budgetExceeded)
        }
        XCTAssertThrowsError(try TorrentQueuePolicy.nextAdmission(in: [head], availableBytes: 3 * gib - 1)) {
            XCTAssertEqual($0 as? TorrentDownloadError, .insufficientSpace)
        }
        XCTAssertNotNil(try TorrentQueuePolicy.nextAdmission(in: [head], availableBytes: 3 * gib))
    }

    func testQueueDoesNotStartLegacyPreparationPausedRecordOrSecondActiveTransfer() throws {
        var legacy = queued(order: 0); legacy.queueOrder = nil
        var paused = queued(order: 1); paused.state = .paused
        XCTAssertTrue(TorrentQueuePolicy.ordered([legacy, paused]).isEmpty)
        var active = queued(order: 2); active.state = .downloading
        XCTAssertNil(try TorrentQueuePolicy.nextAdmission(in: [queued(order: 3), active], availableBytes: .max))
        XCTAssertEqual(TorrentQueuePolicy.reservedBytes(in: [legacy, paused]), 2 * gib)
    }

    func testQueueRecordLimitSelectedMetadataAndPartialReservationsFailClosed() throws {
        XCTAssertThrowsError(try TorrentQueuePolicy.nextAdmission(in: (0..<9).map { queued(order: $0) }, availableBytes: .max)) {
            XCTAssertEqual($0 as? TorrentQueueError, .tooManyRecords)
        }
        var missing = queued(order: 0); missing.fileIndex = nil
        XCTAssertThrowsError(try TorrentQueuePolicy.nextAdmission(in: [missing], availableBytes: .max))
        let duplicate = queued(order: 0)
        XCTAssertThrowsError(try TorrentQueuePolicy.nextAdmission(in: [duplicate, duplicate], availableBytes: .max)) {
            XCTAssertEqual($0 as? TorrentQueueError, .invalidEntry)
        }
        var partial = queued(order: 0); partial.downloadedBytes = 100
        XCTAssertEqual(TorrentQueuePolicy.reservedBytes(in: [partial]), gib)
        XCTAssertTrue(TorrentQueuePolicy.ordered([partial]).isEmpty)
    }

    func testQueueReservationOverflowSaturatesAndEpisodeBatchSortIsStable() throws {
        let huge = complete(queued(order: 0, size: .max))
        XCTAssertEqual(TorrentQueuePolicy.reservedBytes(in: [huge, complete(queued(order: 1, size: .max))]), .max)
        let first = queued(order: 3, association: try TorrentMediaAssociation(media: series, providerID: "rezka", episodeID: "rezka-101"))
        let second = queued(order: 1, association: try TorrentMediaAssociation(media: series, providerID: "rezka", episodeID: "rezka-102"))
        let next = queued(order: 0, association: try TorrentMediaAssociation(media: series, providerID: "rezka", episodeID: "rezka-201"))
        XCTAssertEqual(TorrentQueuePolicy.orderedEpisodeBatch([next, second, first]).map(\.id), [first.id, second.id, next.id])
        let mixed = [next, queued(order: 9), first]
        XCTAssertEqual(TorrentQueuePolicy.orderedEpisodeBatch(mixed).map(\.id), mixed.map(\.id))
    }

    func testLegacyLibraryMigrationPreservesFavoritesWatchlistHistoryAndSchemaOnIntroMutation() async throws {
        let association = try TorrentMediaAssociation(media: series, providerID: "rezka", episodeID: "rezka-102")
        let saved = SavedMedia(reference: association.reference, media: association.media, addedAt: now)
        let progress = WatchProgress(reference: association.reference, media: association.media, episodeID: association.episodeID,
            position: 25, duration: 100, updatedAt: now)
        let old = Core06Library(favorites: [saved], watchlist: [saved], history: [progress])
        let encoder = JSONEncoder(); encoder.dateEncodingStrategy = .iso8601
        let bytes = try encoder.encode(old)
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: directory) }
        let url = directory.appendingPathComponent("library.json")
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        try bytes.write(to: url)
        let store = LibraryStore(fileURL: url)
        let migrated = try await store.snapshot()
        XCTAssertEqual(try Data(contentsOf: url), bytes) // Reading alone must not rewrite original storage.
        XCTAssertEqual(migrated.schemaVersion, 1)
        XCTAssertEqual(migrated.favorites, [saved]); XCTAssertEqual(migrated.watchlist, [saved]); XCTAssertEqual(migrated.history, [progress])
        XCTAssertTrue(migrated.introSkips.isEmpty)
        try await store.setIntroSkipDuration(85, for: association.reference)
        let restored = try await LibraryStore(fileURL: url).snapshot()
        XCTAssertEqual(restored.schemaVersion, 1)
        XCTAssertEqual(restored.favorites, migrated.favorites); XCTAssertEqual(restored.watchlist, migrated.watchlist); XCTAssertEqual(restored.history, migrated.history)
        XCTAssertEqual(restored.introSkips, [SeriesIntroSkipPreference(reference: association.reference, duration: 85)])
    }

    func testIntroPreferencesArePerReferenceRemovableAndRejectInvalidWithoutMutation() async throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: directory) }
        let store = LibraryStore(fileURL: directory.appendingPathComponent("library.json"))
        let first = MediaReference(providerID: "a:b", itemID: "c")
        let second = MediaReference(providerID: "a", itemID: "b:c")
        try await store.setIntroSkipDuration(80, for: first)
        try await store.setIntroSkipDuration(90, for: second)
        let firstDuration = try await store.introSkipDuration(for: first)
        let secondDuration = try await store.introSkipDuration(for: second)
        XCTAssertEqual(firstDuration, 80); XCTAssertEqual(secondDuration, 90)
        let before = try await store.snapshot()
        for value in [-1, Double.nan, Double.infinity, 601] {
            do { try await store.setIntroSkipDuration(value, for: first); XCTFail("Invalid intro accepted") }
            catch { XCTAssertEqual(error as? LibraryError, .invalidIntroDuration) }
        }
        let after = try await store.snapshot()
        XCTAssertEqual(before, after)
        try await store.setIntroSkipDuration(0, for: first)
        let removedDuration = try await store.introSkipDuration(for: first)
        XCTAssertEqual(removedDuration, 0)
        let remaining = try await store.snapshot()
        XCTAssertEqual(remaining.introSkips.map(\.reference), [second])
    }
}

extension Core07StoredEnvelope: Equatable {}
