# Результаты проверки — 30 октября 2026

**Текущий выпуск: Asan0.4.0/build5.**113 XCTest,11 Python и11 UITests прошли. Нативные кадры/запись и device IPA проверены: [VALIDATION-0.4.md](VALIDATION-0.4.md).

**Предыдущий выпуск: 0.2.1 Asan.** Выход Back/Menu, новое название и иконка: [VALIDATION-0.2.1.md](VALIDATION-0.2.1.md). Результаты предыдущей 0.2 «Медиатека»: [VALIDATION-0.2.md](VALIDATION-0.2.md). Ниже сохранены исторические результаты 0.1.

Первая нативная сборка подтверждена [успешным GitHub Actions run 40944080586](https://github.com/3asanali-bit/KinoHD-tvOS/actions/runs/40944080586). Проверенный source commit: `cbb935f7abf3365788456c718c9e4a812b88ab05`. Последующие коммиты только Markdown не изменяют исполняемый код и не перезапускают CI.

## Выполнено на macOS

Runner `macos-26-intel`, Xcode 26.6 (17F113), Apple Swift 6.3.3, tvOS SDK 26.5.

| Проверка | Фактический результат |
|---|---|
| Python packaging tests | 7 прошли, без пропусков; включая реальную компиляцию arm64/x86_64 fixtures и вызов CLI |
| XCTest KinoCore + RezkaKit | 84 выполнены, 0 failures |
| tvOS Simulator Debug | BUILD SUCCEEDED; приложение и ресурсы скомпилированы, UI не запускался |
| tvOS device Release | ARCHIVE SUCCEEDED, arm64 |
| IPA packaging | Успех; проверены platform, family, executable, arm64 и ZIP CRC |
| Артефакты | KinoHD-unsigned-IPA, KinoHD-unsigned-tvOS, журналы; срок GitHub 14 дней |

Журнал: [job 123694708926](https://github.com/3asanali-bit/KinoHD-tvOS/actions/runs/40944080586/job/123694708926). ZIP-артефакт IPA: [12929111308](https://github.com/3asanali-bit/KinoHD-tvOS/actions/runs/40944080586/artifacts/12929111308).

## Проверка скачанного IPA в Windows

- GitHub artifact ZIP SHA256 совпал с опубликованным digest, CRC проверен.
- Внешний ZIP содержит только `KinoHD-unsigned.ipa`; внутри проверены безопасные пути `Payload/KinoHD.app/` и CRC.
- Info.plist: platform AppleTVOS, family 3, bundle `dev.local.KinoHD`, версия 0.1.0, minimum tvOS 17.0.
- Основной бинарный файл — arm64 Mach-O executable; Unix execute bit сохранён.
- Размер IPA: **1 926 834 байта**.
- SHA256 IPA: `d3a1ed58a112609f242ffd5062bb6c010c4e6c5d750370e465c4a66b966eb4ca`.
- Подпись и provisioning profile не создавались. Сам по себе этот IPA ещё нельзя считать установленным или готовым к запуску на устройстве.

## Дополнительные проверки и ограничения

Структурный разбор Windows: 28 Swift-файлов без Tree-sitter ERROR/missing, 43 объекта Xcode, ссылки/актуальность генерации, XML/plist/JSON/assets; Ruff Python и Bash-синтаксис. actool/ibtool затем прошли в настоящей сборке Xcode.

Сборка прошла с предупреждениями: лишний await у некоторых immutable test actor properties, deprecated одноаргументный onChange в двух UI-местах, отсутствие AppIntents metadata и обновление Node runtime у GitHub actions. Они не остановили проверки; отсутствие ошибок не означает отсутствие предупреждений.

**Ещё не выполнены:** подпись, установка и запуск A1625, проверка управления пультом/клавиатуры, настоящий вход rezka.fi, Premium-видео, смена качества/озвучек, перемотка, resume и переходы серий на реальном сервисе. Fixtures не содержат настоящих аккаунтов, cookies или видео. Публичная login-форма проверена; пользовательские credentials не вводились.

## Исправленные проблемы CI

- ARM hosted runner не выделялся; GitHub подтвердил capacity constraints/internal error. Использован стандартный Intel runner.
- HTTP fixtures ошибочно использовали URL.path с ожиданием завершающего слеша. URLComponents сохраняет HTTP path; исправлен также fake logout, который из-за сравнения мог зависнуть.
- macOS канонизирует tempfile `/var` в `/private/var`; тест сравнивает разрешённые пути.
- lipo принимает входной файл перед `-verify_arch arm64`, поскольку флаг потребляет оставшиеся аргументы. Проверено реальным CLI и [исходником Apple](https://github.com/apple-oss-distributions/cctools/blob/main/misc/lipo.c).
