# Asan0.4.0/build5 — проверенный выпуск,31 октября2026

**Обновление готово.** Качества объединены без потери запасных URL, оформление обновлено, нативный UI и запись переходов просмотрены. Имя Asan/сердце и bundle dev.local.KinoHD сохранены.

## Фактические проверки

| Проверка | Результат |
|---|---|
| [Основное build-задание](https://github.com/KingAsan/Asan-tvOS/actions/runs/41127279643/job/124308955222) | Success,10m13s |
| XCTest KinoCore/RezkaKit/KinoArtwork |113 passed,0 failures |
| Python packaging / Simulator selection |11 passed,OK,без skips на macOS |
| Simulator Debug | BUILD SUCCEEDED |
| Device Release arm64 | ARCHIVE SUCCEEDED |
| [Повторный UI-прогон](https://github.com/KingAsan/Asan-tvOS/actions/runs/41130729493) |11 passed,0 failed,0 skipped |
| Native PNG |18 XCTest attachments; интерфейс просмотрен вручную |
| Переходы |Настоящий simctl H.264 tour, проверенный по записи/последовательности исходных кадров |

Среда: Apple TV1080p Simulator, tvOS26.5, стандартный macos-26-intel. UI-прогон повторён отдельно: менялись только UITests и скрипт диагностики. App/Sources/Tests/Package.swift/Xcode project побайтово совпадают с исходником успешного device Release. Повторная Release-сборка намеренно пропущена, прошедшие113 XCTest/11 Python относятся к неизменившимся исходникам.

## Исходники и целостность

- Device build source ZIP SHA256: `618557e13261a2b55d73407ee8364e893e528b708dd88b0cfad5e030247915de`.
- Проверенный UI source ZIP SHA256: `daee692f4219ae2f17ec0fb6b7e9ef01e57a7a51e8901279d52f2e4fd6a3a93b`; source commit `1e456f3cbc8b46e68f20a9c0b186ac7efc9b0246`, workflow commit `83aa283e2c04692f0d347e4a5dc38e424efa60de`.
- После приёмки изменены только Markdown-отчёты.78 файлов кода/ресурсов/тестов/инструментов проверены по замороженному SHA256-манифесту. Полный source ZIP с актуальными отчётами имеет отдельную контрольную сумму в delivery JSON.
- IPA **Asan-0.4.0-unsigned.ipa**, 4521027bytes, SHA256 `52f84f03740bb7c1e7ae967e472e0bcb23f04b6acd5e11443a691c966eb52b7d`. Проверены внешний artifact digest, ZIP CRC/пути/execute bits, Asan0.4/build5, AppleTVOS/family3, thin arm64 Mach-O, min tvOS17, Assets.car, отсутствие проверяемого Simulator-fixture marker и provisioning.
- IPA artifact13012410710: SHA256 `90a517b93f57b44604cbab0f62765aa9116dc17fd1d34f77af95e5802a41a09b`. Build logs artifact13010719756: SHA256 `0fabfc2f958694331559833766ebd17536c3decb4a66d3142ea166c12981993f`. UI artifact13013860975: SHA256 `b8a97019d5547a0b47b04ed1e7ec1d0eb92da7c53d2894cb304551f436ad7673`.

## Что проверено

Восемь server-alias fixtures превращаются в четыре видимых качества —1080p/720p/480p/360p — и до запуска, и в плеере. Сохранены различия Ultra/HDR/озвучек, подписанные URL не меняются. Кандидаты одного качества позволяют до трёх разных HTTPS-подключений без молчаливого изменения качества. Обновлённая ссылка сопоставляется по качеству/озвучке, не по истёкшему id.

Проверены native sidebar expanded/collapsed, focus/подъём постеров, один жанр/рейтинг, длинные и неполные карточки, прокрутка 240 элементов, details/Back, озвучки и качества, выход из AVKit-контейнера, guest/settings/login, сохранённый каталог при проверке аккаунта. Запись tour проходит вперёд и назад через выбор озвучки и качества. Сезоны и серии покрыты отдельными Core/parser-тестами; полноценный просмотр сериала в этом UI-прогоне не выполнялся. Отдельно проверен app-level reduced-effects preview, native accessibility значения читаются без попытки их перезаписать.

Причина первоначального сбоя tour была в проверке: tvOS List держит focus на Cell, а Button внутри неё является действием accessibility. Фактическая failure hierarchy это подтвердила; проверка принимает сфокусированную строку с нужной кнопкой и подтверждает реальный переход Select/Back. Ошибки компиляции до приёмки исправлены: Nuke cancellation modifier перед SwiftUI transaction, отсутствие неподдерживаемого scrollContentBackground на tvOS, только чтение системных accessibility values.

## Измерения и границы

Один offline Simulator sample целевого приложения при прокрутке240 вымышленных карточек:

```json
{
  "Absolute Memory Physical (KinoHD), kB": 51167.232,
  "Clock Monotonic Time, s": 4.605,
  "Memory Physical (KinoHD), kB": 266.24,
  "CPU Cycles (KinoHD), kC": 0.0,
  "CPU Instructions Retired (KinoHD), kI": 0.0,
  "CPU Time (KinoHD), s": 2.698,
  "Memory Peak Physical (KinoHD), kB": 51781.632
}
```

Это данные Simulator, без реального CDN/аккаунта; они не являются FPS/памятью A8 и не доказывают отсутствие любых фризов на физической A1625. Частота закодированного VFR-видео тоже не равна app FPS. Реальные Premium, сеть и видео не проверены этими fixtures. Player test проверяет выход из контейнера без настоящего потока. DEBUG/Simulator fixtures в Release не включены.

## Оформление

Графитовый фон, жемчужные акценты и лёгкие полупрозрачные панели, стандартные focus/sidebar/AVKit. Пользовательские переходы короткие и учитывают Reduce Motion; Reduce Transparency делает панели непрозрачными. Это облегчённое оформление для A1625. По [Apple](https://developer.apple.com/documentation/technologyoverviews/adopting-liquid-glass) настоящий Liquid Glass в tvOS поддерживается Apple TV4K2ndgen и новее. [Materials](https://developer.apple.com/design/human-interface-guidelines/materials) и [Motion](https://developer.apple.com/design/human-interface-guidelines/motion) — основания умеренного использования эффектов.

Установка: выбрать новый IPA в Sideloadly, подписать тем же Apple Account и установить поверх существующего Asan без удаления. Репозиторий KingAsan/Asan-tvOS остаётся приватным. Пароли, APK, provisioning и credentials в исходники не включены.
