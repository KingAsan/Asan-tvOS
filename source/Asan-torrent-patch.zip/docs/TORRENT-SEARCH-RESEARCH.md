# Native torrent search in Asan 0.6

Reviewed against the live provider and Apple documentation on 2026-11-06. This feature searches a public index directly from the app; it does not require a PC, NAS, account, API key or hosted search gateway. A result is a candidate release, not a download instruction. The existing metadata/file-selection flow remains responsible for admission and starting the selected file.

## Provider and observed HTML

The provider's own [rutor.info homepage](https://rutor.info/) and [rutor.is homepage](https://rutor.is/) identify these two addresses as mirrors. Both homepages were visible through the web browser research tool. That tool could not open deep search URLs; its failure is not recorded as evidence that the provider is blocked.

Separate bounded direct HTTPS reads from the Windows workspace, without cookies or browser challenge workarounds, returned HTTP 200 from both mirrors for a search request. Each returned approximately 86 KB and 100 result rows. Actual HTML places releases in `#index tr.gai` / `tr.tum`, a magnet and topic link in the second cell, optional comments in an extra cell, size in the penultimate cell and seeders in `span.green` in the last cell. Red peer counts are leechers. Magnets are available in the listing, so no topic, image, ad, script or torrent-file request is necessary.

The live search form's `search_submit()` constructs the path from method, scope and sort controls. Method 1 means all query words; scope 0 limits matching to the title. Sort 2 chooses seed count, and the descending direction adds 0. The implemented path is therefore `/search/0/0/100/2/<encoded-term>`. The previous draft's `010/0` meant phrase search across title and description, ordered by date; reviewing the actual form caught and corrected that mistake before CI publication.

A direct read of [the public-domain fixture-title search](https://rutor.info/search/0/0/100/2/Night%20of%20the%20Living%20Dead%201968) returned HTTP 200 and 10 rows. Its first seed counts were `2,1,1,1,1,1,1,1,0,0`, confirming descending provider order at observation time. A deliberately nonexistent query returned HTTP 200, no result rows and the provider's explicit zero-results marker. These checks fetched HTML only; no release payload or torrent metadata was requested. They are not yet proof of native URLSession or physical Apple TV operation.

Category 0 covers all categories because the form has separate foreign/domestic movie and series categories plus animation/anime categories, with no combined video category. The parser strictly matches normalized bilingual title identity, movie year, and series premiere/release years. It does not prove that every release contains a supported video file; the subsequent existing native metadata/file chooser still validates that. Only the first provider result page is searched.

## Network API and review

Apple documents [bytes(for:delegate:)](https://developer.apple.com/documentation/foundation/urlsession/bytes(for:delegate:)) and the public [AsyncBytes.task property](https://developer.apple.com/documentation/foundation/urlsession/asyncbytes/task). Apple's corresponding [method metadata](https://developer.apple.com/tutorials/data/documentation/foundation/urlsession/bytes(for:delegate:).json) and [task-property metadata](https://developer.apple.com/tutorials/data/documentation/foundation/urlsession/asyncbytes/task.json) both report tvOS 15.0 / macOS 12.0 introduction, below this package's tvOS 17 / macOS 13 floors. The transport uses these existing APIs, with normal system TLS validation.

The URLSession is reused per transport and explicitly invalidated on deinitialization. Each request gets a separate redirect delegate. [URLSession's configuration initializer](https://developer.apple.com/documentation/foundation/urlsession/init(configuration:delegate:delegatequeue:)) provides a serial delegate queue when none is supplied, so the request-local redirect counter is not shared between concurrent tasks. Redirects are limited to four and accepted only for the two fixed HTTPS mirror hosts on the default HTTPS port, without user info or fragments. Off-provider redirects are refused before following them and the final response URL is independently checked.

Both the advertised content length and streamed body are capped at 2 MiB; the body cap also covers responses without a content length. `defer` cancels the underlying data task on every exit, and cancellation is checked during accumulation and after transport/parsing. Cookie storage and URL caching are disabled. [Apple's resource timeout](https://developer.apple.com/documentation/foundation/urlsessionconfiguration/timeoutintervalforresource) limits each complete transfer to 18 seconds; the request idle timeout is 10 seconds. A structured, cooperative 20-second search deadline cancels the operation. It is not a hard real-time interruption of synchronous HTML parsing or an arbitrary injected transport that ignores cancellation.

Matching results from the first title terminate the search immediately. The original-language title is tried only when the first title has no matches; the mirror is tried on an error. This avoids losing already valid matches while a redundant alias request times out. Canonical magnets and hashes use the existing KinoCore `TorrentMagnet`; hash-equivalent rows are deduplicated, sorted by seeders and capped at 60 results. No engine is linked into this search target.

## Tests and limits

The source includes 19 offline tests for both column layouts, URL and byte limits, cancellation, canonical hash deduplication, title/year/remake identity, series season ornaments/year ranges, mirror/alias fallback and early return. They still require macOS CI execution; source inspection and Python network reads are not a Swift test pass.

The separate live diagnostic is skipped unless explicitly enabled:

```sh
ASAN_LIVE_TORRENT_SEARCH=1 swift test --filter TorrentSearchTests.testLivePublicSearchOnlyWhenExplicitlyEnabled
```

Run it as a separate nonblocking diagnostic, not as a release unit-test gate: the provider, DNS, region, TLS reachability, HTML and result inventory can change independently of the app. Unknown/challenge HTML produces a clear error and is never solved or bypassed. Missing release years yield a lower-confidence candidate; titles that differ beyond normalization and numeric season ornaments are deliberately not fuzzily matched. Seed counts and listing sizes are provider estimates, not guarantees of availability or the selected file's size. The displayed candidate must still be selected by the user and validated through actual torrent metadata before downloading.
