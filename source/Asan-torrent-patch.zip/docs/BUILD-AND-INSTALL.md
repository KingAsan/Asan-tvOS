# Asan0.4.0 — установка проверенного обновления

Выберите **Asan-0.4.0-unsigned.ipa** в Sideloadly, подпишите тем же Apple Account и установите поверх текущего приложения. Bundle ID сохранён, удалять Asan не нужно. Проверки и хеши: [VALIDATION-0.4.md](VALIDATION-0.4.md).

# История сборки0.3 и общие инструкции

Предыдущий выпуск — **Asan0.3.0/build4**. [Финальная нативная сборка](https://github.com/KingAsan/Asan-tvOS/actions/runs/41104547915) успешна;107 XCTest,11 Python,7 UITests и15 вручную просмотренных native PNG. Проверка IPA и SHA256: [VALIDATION-0.3.md](VALIDATION-0.3.md).

Для установки с Windows выберите `Asan-0.3.0-unsigned.ipa` в Sideloadly и используйте **тот же Apple Account**, которым подписано текущее Asan. Устанавливайте поверх приложения, без удаления: bundle ID и локальная библиотека сохранены. GitHub artifact называется `Asan-unsigned-IPA`; внутренний файл `KinoHD-unsigned.ipa` идентичен локальному Asan IPA. Старые имена проекта/схемы — технические идентификаторы.

Проект рассчитан на tvOS 17 и новее. `Package.swift` описывает библиотеки `KinoCore`, `RezkaKit`, `KinoArtwork` и их тесты; приложение собирается из `KinoHD.xcodeproj`, общая схема — `KinoHD`.

**Исторический статус первой версии0.1:** [macOS CI успешна](https://github.com/3asanali-bit/KinoHD-tvOS/actions/runs/40944080586): 84 XCTest, 7 packaging tests, Simulator build, Release device archive и unsigned IPA. Подпись, запуск на приставке и реальный аккаунт ещё не проверены.

Подтверждённая модель — **Apple TV HD A1625, tvOS 26.6**. Для этой приставки есть USB‑C путь установки с Windows через Sideloadly после локального подписания IPA. Порядок и ограничения: [APPLE-TV-HD.md](APPLE-TV-HD.md). Следующие разделы о Xcode описывают сборку/официальную установку с Mac, а не обязательное наличие Mac у пользователя.

## Проверка на Mac

Нужен полный Xcode с поддержкой tvOS и tvOS Simulator SDK, а также Swift 6 или новее (Xcode 16+). Одних Command Line Tools недостаточно для сборки tvOS-приложения. Версия Xcode должна поддерживать macOS этого Mac и tvOS целевой приставки: [таблица Apple](https://developer.apple.com/xcode/system-requirements).

Установи Xcode из [Mac App Store по ссылке Apple](https://developer.apple.com/tvos/get-started/), открой его и заверши первоначальную настройку. Если поддержка tvOS отсутствует, добавь её в настройках Xcode согласно [инструкции Apple по компонентам](https://developer.apple.com/documentation/xcode/downloading-and-installing-additional-xcode-components).

Из корня папки `KinoHD-tvOS` выполни:

```bash
bash scripts/check-macos.sh
```

Скрипт проверяет выбранный Xcode, Swift и Simulator SDK, затем запускает тесты пакета на macOS и собирает приложение для общего назначения tvOS Simulator:

```bash
swift test
xcodebuild build \
  -project KinoHD.xcodeproj \
  -scheme KinoHD \
  -configuration Debug \
  -sdk appletvsimulator \
  -destination 'generic/platform=tvOS Simulator' \
  -derivedDataPath .build/xcode \
  CODE_SIGNING_ALLOWED=NO
```

Скрипт использует Swift из выбранного Xcode через `xcrun`. Если тест или сборка завершаются с ошибкой, он возвращает ненулевой код. Для этих проверок не нужны Apple Account, сертификат, provisioning profile или подключённая Apple TV.

`swift test` проверяет ядро на macOS. Команда `xcodebuild build` проверяет компиляцию приложения, но не запускает его. Нативные UI-тесты приложения эта схема проверки не выполняет; `xcodebuild test` здесь намеренно не используется. Simulator-сборка без подписи не подходит для установки на физическую приставку.

## Проверка без собственного Mac

Можно подготовить исходники в Windows и собрать их на доверенном macOS CI. В проекте есть `.github/workflows/tvos.yml`: он рассчитан на размещение **содержимого папки `KinoHD-tvOS` в корне репозитория**, чтобы `.github/workflows` находилась в ожидаемом GitHub месте. Вложенную в произвольный репозиторий папку GitHub автоматически не обнаружит как workflow.

Текущий приватный репозиторий — [KingAsan/Asan-tvOS](https://github.com/KingAsan/Asan-tvOS). Его wrapper `.github/workflows/asan-build.yml` восстанавливает исходники из шести частей `.transfer/` в `project/`, проверяет SHA256/ZIP CRC/пути и выполняет оригинальные скрипты на стандартном macos-26-intel. Jobs `build` и `native-ui` завершились успешно в [run41104547915](https://github.com/KingAsan/Asan-tvOS/actions/runs/41104547915). Артефакты: `Asan-check-log-1`, `Asan-native-preview`, `Asan-unsigned-tvOS`, `Asan-unsigned-IPA`. Время хранения14 дней.

Полный локальный source ZIP содержит обычные App/Sources/Tests/UITests/scripts и `KinoHD.xcodeproj`; для разработки распакуйте его в отдельную папку, например Asan-tvOS. Встроенные исходные `.github/workflows/tvos.yml` и `tvos-preview.yml` работают при размещении дерева исходников непосредственно в корне другого репозитория. Не путайте такую структуру с `.transfer/` текущего CI wrapper.

Apple Account, пароли, сертификаты и пользовательские GitHub secrets для этого workflow не требуются. Checkout использует штатный токен GitHub Actions с `contents: read` и не сохраняет credentials в конфигурации Git. Workflow не подписывает, не публикует и не устанавливает приложение. Учётные данные нужны только при выборе конкретного следующего шага, например подписи для устройства; передавать их в исходниках или в чат не требуется.

**Текущий успешный run41104547915** проверяет source ZIP SHA256 `08e80089062f0ed1451f68523041bcd9d9235e1a207e474921f9f5d4db3c193f`. Все результаты0.3 — в [VALIDATION-0.3.md](VALIDATION-0.3.md). После тестов менялись только Markdown-отчёты. Исторический аккаунт3asanali-bit исчерпал возможность запуска, поэтому использован собственный KingAsan; репозиторий остался приватным.

## Запуск в Simulator и на Apple TV

После успешной сборки открой `KinoHD.xcodeproj` в Xcode, выбери схему `KinoHD` и подходящий Apple TV Simulator, затем Run. Для проверки управления используй экранный пульт Simulator. Проверь поиск, переходы между карточками, возврат назад, ошибки сети и воспроизведение. Сборка для общего назначения в скрипте сама Simulator не запускает.

Для физической Apple TV нужен отдельный шаг подписи и проверки на устройстве:

1. Уточни модель приставки и установленную tvOS. Она должна поддерживать tvOS 17 или новее и быть совместимой с выбранным Xcode.
2. Открой `Settings → Remotes and Devices → Remote App and Devices` на Apple TV и выполни pairing с Xcode на Mac по [инструкции Apple](https://developer.apple.com/documentation/xcode/pairing-your-devices-with-your-mac). Текущая инструкция требует общей сети и IPv6 для беспроводного pairing tvOS.
3. В Xcode добавь свой Apple Account локально, выбери Team в `Signing & Capabilities`, проверь уникальный Bundle Identifier и доступность нужных возможностей. Применимость Personal Team или членства Apple Developer Program, срок профиля и доступные entitlements необходимо проверить для конкретной учётной записи. Постоянная установка или работа любого capability в бесплатном либо платном режиме здесь не обещаются.
4. Выбери сопряжённую Apple TV как Run Destination. Собери и запусти приложение в Xcode с настройками подписи для устройства. Параметр `CODE_SIGNING_ALLOWED=NO` из проверки Simulator к этому запуску не относится.

В tvOS нет переключателя Developer Mode из настроек iPhone: [Apple уточняет](https://developer.apple.com/documentation/xcode/enabling-developer-mode-on-a-device), что Developer Settings появляются после pairing. Порядок подписания и автоматическое создание development profile описаны в [Running your app on simulated or physical devices](https://developer.apple.com/documentation/xcode/running-your-app-on-simulated-or-physical-devices); ограничения Personal Team — в [Developer account overview](https://developer.apple.com/help/account/basics/about-your-developer-account/).

TestFlight и App Store — отдельные способы распространения готовой tvOS-сборки, а не конвертеры Android APK. Для TestFlight нужна подготовленная разработчиком сборка и приглашение: [инструкция Apple](https://testflight.apple.com/). Этот проект не загружается туда автоматически.

## Первоисточники команд и workflow

- [Swift Package Manager](https://docs.swift.org/main/documentation/packagemanagerdocs/) — назначение `swift test`.
- [Apple TN2339: Building from the Command Line with Xcode](https://developer.apple.com/library/archive/technotes/tn2339/_index.html) — `xcrun`, выбор инструментов и команды `xcodebuild`; точные параметры установленной версии также доступны через `man xcodebuild`.
- [GitHub workflow syntax](https://docs.github.com/en/actions/reference/workflows-and-actions/workflow-syntax) — `shell: bash` и поведение `pipefail`.
- [actions/checkout v4: action.yml](https://github.com/actions/checkout/blob/v4/action.yml) — проверенные входы action, включая `persist-credentials`.
- [actions/upload-artifact v4: action.yml](https://github.com/actions/upload-artifact/blob/v4/action.yml) — `path`, `if-no-files-found` и `retention-days`.

Пароли, токены, private keys и сертификаты в эти файлы не добавлять.
