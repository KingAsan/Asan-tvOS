# Встроенные загрузки Asan 0.7

Новые возможности и статус сборки: [FEATURES-0.7](FEATURES-0.7.md), [VALIDATION-0.7](VALIDATION-0.7.md). GitHub Actions доступен; нативная сборка 0.7 прошла, но полный UI-прогон выявил ошибки. Исправленный кандидат ожидает повторной нативной проверки перед выпуском.

Asan включает собственный C ABI bridge к libtorrent v2.0.15 (BSD-3-Clause) внутри процесса tvOS. ПК, NAS и отдельный TorrServer не нужны. Каталог, аккаунт Premium и потоковый плеер Rezka сохраняются. Кнопка «Торрент» в карточке ищет раздачи на публичном RuTor; ручная magnet-ссылка остаётся доступна. Выбранный файл скачивается полностью перед просмотром.

## Поведение

- Скачивание выполняется при открытом Asan, по одному файлу. Несколько выбранных серий образуют последовательную очередь. Явная пауза исключает файл из автоматической очереди; системная фоновая пауза сохраняет намерение продолжить. Поддерживаются magnet v1 btih, включая base32 и hybrid с v1; DHT, UDP и HTTP-трекеры. HTTPS-only/private trackers и обязательное шифрование протокола этим source-build пока не поддерживаются.
- Лимит списка — 8 файлов, общий бюджет кэша — 11 ГиБ, запас свободного места — 1 ГиБ. Один файл может занимать до 11 ГиБ, если в бюджет помещаются также сохранённые загрузки и на диске остаётся резерв. Размер и свободный диск проверяются перед каждым стартом. При нехватке места очередь ждёт; готовые предыдущие фильмы не удаляются досрочно. Повторный magnet не создаёт вторую случайную копию; разные выбранные файлы одной раздачи имеют отдельный кэш.
- Полный файл не загружается в RAM. Нативный движок пишет его на диск, а проверенные части и состояние читаются с рабочего actor. Прогресс сохраняется не чаще раза в 15 секунд; изменения состояния сохраняются сразу.
- «Готово» появляется только по подтверждению проверенных хешей выбранного файла. Сохранённый `completedAt` запускает 10-часовой срок; пауза и перезапуск не продлевают его. Просроченное удаляется при работающем приложении и при запуске/возврате. Идущий просмотр не обрывается: его просроченный файл очищается после выхода из плеера.
- При сворачивании загрузки и VLC ставятся на паузу. tvOS не гарантирует фоновые таймеры или сохранность большого кэша; система может удалить файл раньше. Отсутствующий файл отмечается в списке и доступен для повторной загрузки.
- MP4/M4V/MOV используют AVKit. MKV/WebM/AVI/TS используют официальный TVVLCKit 3.7.3, внутренний LibVLC 3.0.23. Это не обещает поддержку любой комбинации кодеков или плавность 4K/HEVC/AV1 на Apple TV HD A8. В VLC есть Play/Pause, перемотка, выбор аудио/субтитров и скрытие панели через 5 секунд; Back закрывает плеер.
- Кэш изолирован по UUID. Пути и симлинки проверяются; удаление нативной раздачи ждёт подтверждения остановки файловых операций. Не удаляются произвольные пользовательские каталоги.

## Воспроизводимая сборка

На macOS с Xcode и tvOS SDK:

```bash
bash scripts/build-torrent-engine.sh
python3 scripts/prepare-tvos-vlc.py
swift scripts/make-torrent-preview.swift "$PWD/App/PreviewClip.mp4"
bash scripts/check-macos.sh
```

Native source build: libtorrent v2.0.15 commit `1eb18faeae156d8dbbab42935c082f8b81f50989`; Boost 1.85.0 source SHA256 `7009fe1faa1697476bdc7027703a2badb84e849b7b0baad5086b087b971f8617`. XCFramework slices: tvOS17 arm64, tvOS17 x86_64 Simulator, macOS13 x86_64 for tests. Writable mmap disabled on tvOS. No external process/HTTP server or download of a prebuilt torrent engine.

VideoLAN archive: https://download.videolan.org/pub/cocoapods/prod/TVVLCKit-3.7.3-319ed2c0-79128878.tar.xz ; SHA256 `b5f90c226ed54d9dc1c03901c60dc7749b74a53caace2c3047e4c0b7a063e46c`. Dynamic framework is embedded so the signed app can load it; LGPL notice and upstream BSD/Boost notices are bundled under TorrentLicenses. Upstream sources: https://code.videolan.org/videolan/VLCKit and https://code.videolan.org/videolan/vlc .

`PreviewClip.mp4` is generated original silent H.264 test footage, never a downloaded film. The clip is excluded from Release resources; fictional fixtures and forced player routing compile only for DEBUG/Simulator. Native integration tests generate their own byte fixture and transfer it from a localhost seed, checking metadata-only gating, selected-file download, hash/content equality, restart and deletion. Real playback/UI tests use the generated H.264 clip through both AVKit and VLC; this is not a test of every MKV codec or physical A8 performance.

Apple storage/background references: https://developer.apple.com/videos/play/wwdc2023/10256/ and https://developer.apple.com/documentation/xcode/configuring-background-execution-modes .
