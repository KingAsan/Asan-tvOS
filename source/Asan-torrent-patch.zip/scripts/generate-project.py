#!/usr/bin/env python3
"""Generate the small checked-in Xcode project without a third-party generator."""
import argparse
import hashlib
import json
import plistlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OBJECTS = {}


def oid(name):
    return hashlib.sha256(("KinoHD.tvOS/" + name).encode()).hexdigest()[:24].upper()


def add(object_name, **attributes):
    identifier = oid(object_name)
    if identifier in OBJECTS:
        raise ValueError("Duplicate project object: " + object_name)
    OBJECTS[identifier] = attributes
    return identifier


def render(value, indent=0):
    prefix = "\t" * indent
    if isinstance(value, dict):
        return "{\n" + "".join(f"{prefix}\t{key} = {render(item, indent + 1)};\n" for key, item in value.items()) + prefix + "}"
    if isinstance(value, list):
        return "(\n" + "".join(f"{prefix}\t{render(item, indent + 1)},\n" for item in value) + prefix + ")"
    if isinstance(value, int):
        return str(value)
    return json.dumps(str(value), ensure_ascii=False)


def generate():
    source_refs, source_builds = [], []
    for source in sorted((ROOT / "App").glob("*.swift")):
        reference = add("file/" + source.name, isa="PBXFileReference", lastKnownFileType="sourcecode.swift", path=source.name, sourceTree="<group>")
        source_refs.append(reference)
        source_builds.append(add("build/" + source.name, isa="PBXBuildFile", fileRef=reference))
    info_ref = add("file/Info.plist", isa="PBXFileReference", lastKnownFileType="text.plist.xml", path="Info.plist", sourceTree="<group>")
    privacy_ref = add("file/PrivacyInfo.xcprivacy", isa="PBXFileReference", lastKnownFileType="text.xml", path="PrivacyInfo.xcprivacy", sourceTree="<group>")
    privacy_build = add("build/PrivacyInfo", isa="PBXBuildFile", fileRef=privacy_ref)
    assets_ref = add("file/Assets.xcassets", isa="PBXFileReference", lastKnownFileType="folder.assetcatalog", path="Assets.xcassets", sourceTree="<group>")
    launch_ref = add("file/LaunchScreen.storyboard", isa="PBXFileReference", lastKnownFileType="file.storyboard", path="LaunchScreen.storyboard", sourceTree="<group>")
    assets_build = add("build/Assets", isa="PBXBuildFile", fileRef=assets_ref)
    launch_build = add("build/Launch", isa="PBXBuildFile", fileRef=launch_ref)
    app_ref = add("product", isa="PBXFileReference", explicitFileType="wrapper.application", includeInIndex=0, path="KinoHD.app", sourceTree="BUILT_PRODUCTS_DIR")
    package = add("package", isa="XCLocalSwiftPackageReference", relativePath=".")
    core = add("core", isa="XCSwiftPackageProductDependency", package=package, productName="KinoCore")
    core_build = add("core/build", isa="PBXBuildFile", productRef=core)
    rezka = add("rezka", isa="XCSwiftPackageProductDependency", package=package, productName="RezkaKit")
    rezka_build = add("rezka/build", isa="PBXBuildFile", productRef=rezka)
    artwork = add("artwork", isa="XCSwiftPackageProductDependency", package=package, productName="KinoArtwork")
    artwork_build = add("artwork/build", isa="PBXBuildFile", productRef=artwork)
    sources = add("sources", isa="PBXSourcesBuildPhase", buildActionMask=2147483647, files=source_builds, runOnlyForDeploymentPostprocessing=0)
    frameworks = add("frameworks", isa="PBXFrameworksBuildPhase", buildActionMask=2147483647, files=[core_build, rezka_build, artwork_build], runOnlyForDeploymentPostprocessing=0)
    resources = add("resources", isa="PBXResourcesBuildPhase", buildActionMask=2147483647, files=[privacy_build, assets_build, launch_build], runOnlyForDeploymentPostprocessing=0)
    app_group = add("group/app", isa="PBXGroup", children=source_refs + [info_ref, privacy_ref, assets_ref, launch_ref], path="App", sourceTree="<group>")
    ui_ref = add("ui/file", isa="PBXFileReference", lastKnownFileType="sourcecode.swift", path="AsanUITests.swift", sourceTree="<group>")
    ui_build = add("ui/build", isa="PBXBuildFile", fileRef=ui_ref)
    ui_group = add("group/ui", isa="PBXGroup", children=[ui_ref], path="UITests", sourceTree="<group>")
    ui_product = add("ui/product", isa="PBXFileReference", explicitFileType="wrapper.cfbundle", includeInIndex=0, path="AsanUITests.xctest", sourceTree="BUILT_PRODUCTS_DIR")
    products = add("group/products", isa="PBXGroup", children=[app_ref, ui_product], name="Products", sourceTree="<group>")
    main = add("group/main", isa="PBXGroup", children=[app_group, ui_group, products], sourceTree="<group>")

    project_configs, target_configs = [], []
    for configuration in ("Debug", "Release"):
        debug = configuration == "Debug"
        project_settings = {
            "ALWAYS_SEARCH_USER_PATHS": "NO", "CLANG_ENABLE_MODULES": "YES", "CLANG_ENABLE_OBJC_ARC": "YES",
            "ENABLE_STRICT_OBJC_MSGSEND": "YES", "GCC_C_LANGUAGE_STANDARD": "gnu17",
            "GCC_OPTIMIZATION_LEVEL": "0" if debug else "s", "SDKROOT": "appletvos",
            "SWIFT_VERSION": "5.0", "TVOS_DEPLOYMENT_TARGET": "17.0",
            "ONLY_ACTIVE_ARCH": "YES" if debug else "NO",
            "DEBUG_INFORMATION_FORMAT": "dwarf" if debug else "dwarf-with-dsym",
        }
        if debug:
            project_settings["SWIFT_ACTIVE_COMPILATION_CONDITIONS"] = "DEBUG $(inherited)"
        project_configs.append(add("project/" + configuration, isa="XCBuildConfiguration", name=configuration, buildSettings=project_settings))
        target_settings = {
            "ASSETCATALOG_COMPILER_APPICON_NAME": "KinoHDBrand",
            "CODE_SIGN_STYLE": "Automatic", "CURRENT_PROJECT_VERSION": "5", "DEVELOPMENT_TEAM": "",
            "ENABLE_USER_SCRIPT_SANDBOXING": "YES", "GENERATE_INFOPLIST_FILE": "NO", "INFOPLIST_FILE": "App/Info.plist",
            "LD_RUNPATH_SEARCH_PATHS": ["$(inherited)", "@executable_path/Frameworks"],
            "MARKETING_VERSION": "0.4.0", "PRODUCT_BUNDLE_IDENTIFIER": "dev.local.KinoHD",
            "PRODUCT_NAME": "$(TARGET_NAME)", "SDKROOT": "appletvos", "SUPPORTED_PLATFORMS": "appletvos appletvsimulator",
            "SWIFT_OPTIMIZATION_LEVEL": "-Onone" if debug else "-O", "SWIFT_STRICT_CONCURRENCY": "targeted",
            "SWIFT_VERSION": "5.0", "TARGETED_DEVICE_FAMILY": "3", "TVOS_DEPLOYMENT_TARGET": "17.0",
        }
        target_configs.append(add("target/" + configuration, isa="XCBuildConfiguration", name=configuration, buildSettings=target_settings))
    project_list = add("project/configurations", isa="XCConfigurationList", buildConfigurations=project_configs, defaultConfigurationIsVisible=0, defaultConfigurationName="Release")
    target_list = add("target/configurations", isa="XCConfigurationList", buildConfigurations=target_configs, defaultConfigurationIsVisible=0, defaultConfigurationName="Release")
    target = add("target", isa="PBXNativeTarget", buildConfigurationList=target_list, buildPhases=[sources, frameworks, resources], buildRules=[], dependencies=[], name="KinoHD", packageProductDependencies=[core, rezka, artwork], productName="KinoHD", productReference=app_ref, productType="com.apple.product-type.application")
    ui_sources = add("ui/sources", isa="PBXSourcesBuildPhase", buildActionMask=2147483647, files=[ui_build], runOnlyForDeploymentPostprocessing=0)
    ui_frameworks = add("ui/frameworks", isa="PBXFrameworksBuildPhase", buildActionMask=2147483647, files=[], runOnlyForDeploymentPostprocessing=0)
    ui_resources = add("ui/resources", isa="PBXResourcesBuildPhase", buildActionMask=2147483647, files=[], runOnlyForDeploymentPostprocessing=0)
    ui_configs = []
    for configuration in ("Debug", "Release"):
        settings = {"GENERATE_INFOPLIST_FILE": "YES", "PRODUCT_BUNDLE_IDENTIFIER": "dev.local.KinoHD.UITests",
                    "PRODUCT_NAME": "$(TARGET_NAME)", "SDKROOT": "appletvos", "SWIFT_VERSION": "5.0",
                    "SUPPORTED_PLATFORMS": "appletvos appletvsimulator", "TARGETED_DEVICE_FAMILY": "3",
                    "TVOS_DEPLOYMENT_TARGET": "17.0", "TEST_TARGET_NAME": "KinoHD",
                    "CODE_SIGNING_ALLOWED": "NO", "SWIFT_OPTIMIZATION_LEVEL": "-Onone"}
        ui_configs.append(add("ui/config/" + configuration, isa="XCBuildConfiguration", name=configuration, buildSettings=settings))
    ui_list = add("ui/configurations", isa="XCConfigurationList", buildConfigurations=ui_configs, defaultConfigurationIsVisible=0, defaultConfigurationName="Debug")
    ui_proxy = add("ui/proxy", isa="PBXContainerItemProxy", containerPortal=oid("project"), proxyType=1, remoteGlobalIDString=target, remoteInfo="KinoHD")
    ui_dependency = add("ui/dependency", isa="PBXTargetDependency", target=target, targetProxy=ui_proxy)
    ui_target = add("ui/target", isa="PBXNativeTarget", buildConfigurationList=ui_list, buildPhases=[ui_sources, ui_frameworks, ui_resources], buildRules=[], dependencies=[ui_dependency], name="AsanUITests", productName="AsanUITests", productReference=ui_product, productType="com.apple.product-type.bundle.ui-testing")
    project = add("project", isa="PBXProject", attributes={"BuildIndependentTargetsInParallel": "YES", "LastUpgradeCheck": "1600", "TargetAttributes": {target: {"CreatedOnToolsVersion": "16.0"}, ui_target: {"CreatedOnToolsVersion": "16.0", "TestTargetID": target}}}, buildConfigurationList=project_list, compatibilityVersion="Xcode 14.0", developmentRegion="ru", hasScannedForEncodings=0, knownRegions=["ru", "en", "Base"], mainGroup=main, packageReferences=[package], productRefGroup=products, projectDirPath="", projectRoot="", targets=[target, ui_target])
    graph = {"archiveVersion": 1, "classes": {}, "objectVersion": 56, "objects": OBJECTS, "rootObject": project}
    project_text = "// !$*UTF8*$!\n" + render(graph) + "\n"
    scheme = f'''<?xml version="1.0" encoding="UTF-8"?>
<Scheme LastUpgradeVersion="1600" version="1.3">
  <BuildAction parallelizeBuildables="YES" buildImplicitDependencies="YES">
    <BuildActionEntries><BuildActionEntry buildForTesting="YES" buildForRunning="YES" buildForProfiling="YES" buildForArchiving="YES" buildForAnalyzing="YES">
      <BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{target}" BuildableName="KinoHD.app" BlueprintName="KinoHD" ReferencedContainer="container:KinoHD.xcodeproj"/>
    </BuildActionEntry><BuildActionEntry buildForTesting="YES" buildForRunning="NO" buildForProfiling="NO" buildForArchiving="NO" buildForAnalyzing="NO">
      <BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{ui_target}" BuildableName="AsanUITests.xctest" BlueprintName="AsanUITests" ReferencedContainer="container:KinoHD.xcodeproj"/>
    </BuildActionEntry></BuildActionEntries>
  </BuildAction>
  <TestAction buildConfiguration="Debug" shouldUseLaunchSchemeArgsEnv="YES"><Testables><TestableReference skipped="NO"><BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{ui_target}" BuildableName="AsanUITests.xctest" BlueprintName="AsanUITests" ReferencedContainer="container:KinoHD.xcodeproj"/></TestableReference></Testables></TestAction>
  <LaunchAction buildConfiguration="Debug" selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier="Xcode.IDEFoundation.Launcher.LLDB" launchStyle="0" useCustomWorkingDirectory="NO" ignoresPersistentStateOnLaunch="NO" debugDocumentVersioning="YES" allowLocationSimulation="YES">
    <BuildableProductRunnable runnableDebuggingMode="0"><BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{target}" BuildableName="KinoHD.app" BlueprintName="KinoHD" ReferencedContainer="container:KinoHD.xcodeproj"/></BuildableProductRunnable>
  </LaunchAction>
  <ProfileAction buildConfiguration="Release" shouldUseLaunchSchemeArgsEnv="YES" savedToolIdentifier="" useCustomWorkingDirectory="NO" debugDocumentVersioning="YES">
    <BuildableProductRunnable runnableDebuggingMode="0"><BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{target}" BuildableName="KinoHD.app" BlueprintName="KinoHD" ReferencedContainer="container:KinoHD.xcodeproj"/></BuildableProductRunnable>
  </ProfileAction>
  <AnalyzeAction buildConfiguration="Debug"/>
  <ArchiveAction buildConfiguration="Release" revealArchiveInOrganizer="YES"/>
</Scheme>
'''
    info = {
        "CFBundleDevelopmentRegion": "ru", "CFBundleDisplayName": "Asan", "CFBundleExecutable": "$(EXECUTABLE_NAME)",
        "CFBundleIdentifier": "$(PRODUCT_BUNDLE_IDENTIFIER)", "CFBundleInfoDictionaryVersion": "6.0", "CFBundleName": "Asan",
        "CFBundlePackageType": "APPL", "CFBundleShortVersionString": "$(MARKETING_VERSION)", "CFBundleVersion": "$(CURRENT_PROJECT_VERSION)",
        "UIUserInterfaceStyle": "Dark", "UILaunchStoryboardName": "LaunchScreen", "ITSAppUsesNonExemptEncryption": False,
    }
    privacy = {
        "NSPrivacyTracking": False, "NSPrivacyTrackingDomains": [],
        "NSPrivacyCollectedDataTypes": [
            {"NSPrivacyCollectedDataType": "NSPrivacyCollectedDataTypeEmailAddress", "NSPrivacyCollectedDataTypeLinked": True,
             "NSPrivacyCollectedDataTypeTracking": False, "NSPrivacyCollectedDataTypePurposes": ["NSPrivacyCollectedDataTypePurposeAppFunctionality"]},
            {"NSPrivacyCollectedDataType": "NSPrivacyCollectedDataTypeUserID", "NSPrivacyCollectedDataTypeLinked": True,
             "NSPrivacyCollectedDataTypeTracking": False, "NSPrivacyCollectedDataTypePurposes": ["NSPrivacyCollectedDataTypePurposeAppFunctionality"]},
        ],
        "NSPrivacyAccessedAPITypes": [
            {"NSPrivacyAccessedAPIType": "NSPrivacyAccessedAPICategoryUserDefaults", "NSPrivacyAccessedAPITypeReasons": ["CA92.1"]},
            {"NSPrivacyAccessedAPIType": "NSPrivacyAccessedAPICategoryFileTimestamp", "NSPrivacyAccessedAPITypeReasons": ["C617.1"]},
        ],
    }
    return {
        ROOT / "KinoHD.xcodeproj/project.pbxproj": project_text.encode(),
        ROOT / "KinoHD.xcodeproj/xcshareddata/xcschemes/KinoHD.xcscheme": scheme.encode(),
        ROOT / "KinoHD.xcodeproj/project.xcworkspace/contents.xcworkspacedata": b'<?xml version="1.0" encoding="UTF-8"?><Workspace version="1.0"><FileRef location="self:"></FileRef></Workspace>\n',
        ROOT / "App/Info.plist": plistlib.dumps(info, sort_keys=False),
        ROOT / "App/PrivacyInfo.xcprivacy": plistlib.dumps(privacy, sort_keys=False),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true", help="Check generated files without rewriting them")
    options = parser.parse_args()
    current = ROOT / "KinoHD.xcodeproj/project.pbxproj"
    if current.exists() and 'Vendor/TVVLCKit.xcframework' in current.read_text(encoding="utf-8"):
        raise SystemExit("Legacy bootstrap cannot regenerate the native torrent/VLC project. Maintain the checked-in Xcode project; see README.md.")
    outputs = generate()
    mismatched = []
    for path, content in outputs.items():
        if options.check:
            if not path.exists() or path.read_bytes() != content:
                mismatched.append(str(path.relative_to(ROOT)))
        else:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(content)
    if mismatched:
        raise SystemExit("Regenerate project files: " + ", ".join(mismatched))
    print(f"Xcode project {'checked' if options.check else 'generated'}: {len(OBJECTS)} objects; {len(list((ROOT / 'App').glob('*.swift')))} Swift sources")


if __name__ == "__main__":
    main()
