#!/usr/bin/env swift
// Generates an original, silent H.264 MP4 for Debug+Simulator playback checks.
// No network, downloaded media, fonts, or external assets are used.
// swift scripts/make-torrent-preview.swift /absolute/path/App/PreviewClip.mp4
// Apple APIs: AVAssetWriter, AVAssetWriterInputPixelBufferAdaptor,
// append(_:withPresentationTime:), finishWriting(completionHandler:).
import Foundation
import AVFoundation
import CoreVideo
import CoreMedia
import Darwin

struct PreviewFailure: Error, CustomStringConvertible {
    let description: String
    init(_ description: String) { self.description = description }
}
func require(_ condition: Bool, _ message: String) throws {
    if !condition { throw PreviewFailure(message) }
}
let watchdog = DispatchWorkItem {
    let message = "Preview generation exceeded its 28-second runtime limit\n"
    FileHandle.standardError.write(Data(message.utf8))
    _exit(124)
}
DispatchQueue.global(qos: .utility).asyncAfter(deadline: .now() + 28, execute: watchdog)

do {
    try require(CommandLine.arguments.count == 2, "Usage: swift make-torrent-preview.swift OUTPUT.mp4")
    let output = URL(fileURLWithPath: CommandLine.arguments[1]).standardizedFileURL
    try require(output.pathExtension.lowercased() == "mp4", "Output must have the .mp4 extension")
    let manager = FileManager.default
    try require(!manager.fileExists(atPath: output.path), "Output already exists; refusing to overwrite it")
    try manager.createDirectory(at: output.deletingLastPathComponent(), withIntermediateDirectories: true)
    let temporary = output.deletingLastPathComponent().appendingPathComponent(".asan-preview-\(UUID().uuidString).mp4")
    defer { try? manager.removeItem(at: temporary) }

    let width = 640
    let height = 360
    let frameCount = 30
    let writer = try AVAssetWriter(outputURL: temporary, fileType: .mp4)
    writer.shouldOptimizeForNetworkUse = true
    let settings: [String: Any] = [
        AVVideoCodecKey: AVVideoCodecType.h264,
        AVVideoWidthKey: width,
        AVVideoHeightKey: height,
        AVVideoCompressionPropertiesKey: [
            AVVideoAverageBitRateKey: 256_000,
            AVVideoMaxKeyFrameIntervalKey: 1,
            AVVideoProfileLevelKey: AVVideoProfileLevelH264BaselineAutoLevel
        ]
    ]
    try require(writer.canApply(outputSettings: settings, forMediaType: .video), "H.264 output settings are not supported")
    let input = AVAssetWriterInput(mediaType: .video, outputSettings: settings)
    input.expectsMediaDataInRealTime = false
    let adaptor = AVAssetWriterInputPixelBufferAdaptor(assetWriterInput: input, sourcePixelBufferAttributes: [
        kCVPixelBufferPixelFormatTypeKey as String: Int(kCVPixelFormatType_32BGRA),
        kCVPixelBufferWidthKey as String: width,
        kCVPixelBufferHeightKey as String: height,
        kCVPixelBufferIOSurfacePropertiesKey as String: [:] as [String: Any]
    ])
    try require(writer.canAdd(input), "Cannot add the generated video track")
    writer.add(input)
    try require(writer.startWriting(), "Cannot start writing: \(String(describing: writer.error))")
    writer.startSession(atSourceTime: .zero)
    defer { if writer.status == .writing { writer.cancelWriting() } }
    guard let pool = adaptor.pixelBufferPool else { throw PreviewFailure("Pixel buffer pool is unavailable") }
    let readinessDeadline = Date().addingTimeInterval(18)

    for frame in 0..<frameCount {
        while !input.isReadyForMoreMediaData && writer.status == .writing && Date() < readinessDeadline {
            Thread.sleep(forTimeInterval: 0.005)
        }
        try require(input.isReadyForMoreMediaData && writer.status == .writing, "Encoder stalled: \(String(describing: writer.error))")
        try autoreleasepool {
            var created: CVPixelBuffer?
            try require(CVPixelBufferPoolCreatePixelBuffer(kCFAllocatorDefault, pool, &created) == kCVReturnSuccess, "Cannot allocate a preview frame")
            guard let pixel = created else { throw PreviewFailure("Empty pixel buffer") }
            try require(CVPixelBufferLockBaseAddress(pixel, []) == kCVReturnSuccess, "Cannot lock a preview frame")
            var needsUnlock = true
            defer { if needsUnlock { CVPixelBufferUnlockBaseAddress(pixel, []) } }
            guard let base = CVPixelBufferGetBaseAddress(pixel) else { throw PreviewFailure("Frame has no memory") }
            let stride = CVPixelBufferGetBytesPerRow(pixel)
            let rectX = 32 + (frame * 16) % (width - 144)
            let barEnd = (frame + 1) * width / frameCount
            for y in 0..<height {
                let row = base.advanced(by: y * stride).assumingMemoryBound(to: UInt32.self)
                for x in 0..<width {
                    // On little-endian macOS these UInt32 values are BGRA bytes.
                    var color: UInt32 = 0xff14243c
                    if x > 28 && x < width - 28 && y > 28 && y < height - 28 { color = 0xff203754 }
                    if x >= rectX && x < rectX + 112 && y >= 112 && y < 224 { color = 0xff8ed5ff }
                    if y >= height - 12 && x < barEnd { color = 0xffb5f7cb }
                    row[x] = color
                }
            }
            let unlocked = CVPixelBufferUnlockBaseAddress(pixel, [])
            needsUnlock = false
            try require(unlocked == kCVReturnSuccess, "Cannot unlock a preview frame")
            // Each frame remains on screen for one second, and the final session
            // boundary explicitly gives the last frame a full second as well.
            try require(adaptor.append(pixel, withPresentationTime: CMTime(value: Int64(frame), timescale: 1)), "Cannot append frame \(frame): \(String(describing: writer.error))")
        }
    }
    writer.endSession(atSourceTime: CMTime(value: Int64(frameCount), timescale: 1))
    input.markAsFinished()
    let finished = DispatchSemaphore(value: 0)
    writer.finishWriting { finished.signal() }
    try require(finished.wait(timeout: .now() + 8) == .success, "Timed out finishing the MP4 container")
    try require(writer.status == .completed, "MP4 writing failed: \(String(describing: writer.error))")
    let size = (try manager.attributesOfItem(atPath: temporary.path)[.size] as? NSNumber)?.intValue ?? 0
    try require(size > 1024 && size < 4 * 1024 * 1024, "Unexpected generated preview size: \(size)")
    try manager.moveItem(at: temporary, to: output)
    watchdog.cancel()
    print("Generated original 640x360 H.264 preview: 30 seconds, 30 frames, \(size) bytes → \(output.path)")
} catch {
    watchdog.cancel()
    FileHandle.standardError.write(Data("Preview generation failed: \(error)\n".utf8))
    exit(1)
}
