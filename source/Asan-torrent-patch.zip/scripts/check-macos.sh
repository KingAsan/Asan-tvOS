#!/usr/bin/env bash
set -euo pipefail

fail() {
  printf 'ERROR: %s\n' "$*" >&2
  exit 1
}

[[ "$(uname -s)" == Darwin ]] || fail 'This check requires macOS with full Xcode and the tvOS SDK.'

# The bundled torrent XCFramework currently has an Intel Simulator slice.
# Keep this validation destination aligned with that slice, without changing
# the project's architecture settings or its separate arm64 device archive.
simulator_architecture="$(uname -m)"
[[ "$simulator_architecture" == x86_64 ]] || fail 'AsanTorrent currently supports x86_64 tvOS Simulator only; run these checks on an Intel macOS host.'

for tool in xcodebuild xcrun; do
  command -v "$tool" >/dev/null 2>&1 || fail "Required tool not found: $tool"
done

script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
project_root="$(cd -- "$script_dir/.." && pwd)"
cd -- "$project_root"

[[ -f Package.swift ]] || fail "Package.swift is missing from $project_root"
[[ -f KinoHD.xcodeproj/project.pbxproj ]] || fail 'KinoHD.xcodeproj/project.pbxproj is missing.'
[[ -f KinoHD.xcodeproj/xcshareddata/xcschemes/KinoHD.xcscheme ]] || fail 'The shared KinoHD scheme is missing.'

printf '\nSelected Xcode:\n'
xcodebuild -version

swift_bin="$(xcrun --find swift)"
[[ -x "$swift_bin" ]] || fail 'Swift was not found in the selected Xcode toolchain.'
swift_version="$("$swift_bin" --version)"
printf '\n%s\n' "$swift_version"
if [[ "$swift_version" =~ Swift[[:space:]]version[[:space:]]([0-9]+)\.([0-9]+) ]]; then
  swift_major="${BASH_REMATCH[1]}"
  swift_minor="${BASH_REMATCH[2]}"
  if (( swift_major < 6 )); then
    fail 'Swift 6 or later (Xcode 16+) is required by the pinned SwiftSoup dependency.'
  fi
else
  fail 'Could not determine the selected Swift version.'
fi

printf '\ntvOS Simulator SDK:\n'
xcrun --sdk appletvsimulator --show-sdk-path
xcrun --sdk appletvsimulator --show-sdk-version

printf '\nRunning KinoCore package tests on macOS:\n'
"$swift_bin" test

printf '\nBuilding KinoHD for a generic tvOS Simulator destination:\n'
xcodebuild build \
  -project KinoHD.xcodeproj \
  -scheme KinoHD \
  -configuration Debug \
  -sdk appletvsimulator \
  -destination 'generic/platform=tvOS Simulator' \
  -derivedDataPath "$project_root/.build/xcode" \
  ARCHS="$simulator_architecture" ONLY_ACTIVE_ARCH=YES \
  CODE_SIGNING_ALLOWED=NO

printf '\nKinoCore tests and the unsigned tvOS Simulator build passed.\n'
