#!/usr/bin/env python3
"""Launch the real Debug app on a disposable tvOS Simulator and capture scenes.

Apple Simulator commands: https://developer.apple.com/library/archive/documentation/IDEs/Conceptual/iOS_Simulator_Guide/InteractingwiththeiOSSimulator/InteractingwiththeiOSSimulator.html
First-boot workaround: https://developer.apple.com/documentation/Xcode-Release-Notes/xcode-26_1-release-notes
The current installed simctl help is saved with the screenshots. No accounts,
signing certificates or credentials are supplied by this script.
Xcode readiness: https://developer.apple.com/documentation/xcode/downloading-and-installing-additional-xcode-components
The script checks first-launch status but never accepts a license or runs setup.
"""
import argparse
import json
import os
import plistlib
import re
import shlex
import signal
import subprocess
import sys
import threading
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BUNDLE_ID = "dev.local.KinoHD"
EXPECTED_UI_TEST_COUNT = 29
EXPECTED_MINIMUM_SCREENSHOTS = 50
INTRO_PROOF_LABEL = "intro-playback-proof"
UI_CAPTURE_TIMEOUT_SECONDS = 2400


def validate_ui_summary(summary):
    """An older green subset must not validate the required 0.7 feature set."""
    if summary.get("result") != "Passed" or summary.get("totalTestCount") != EXPECTED_UI_TEST_COUNT:
        raise ValueError(f"Expected all {EXPECTED_UI_TEST_COUNT} native UI tests, got {summary.get('totalTestCount')}")
    if summary.get("passedTests") != EXPECTED_UI_TEST_COUNT or any(
            summary.get(key) != 0 for key in ("failedTests", "skippedTests", "expectedFailures")):
        raise ValueError("Native UI validation requires no failures, skipped tests or expected failures")


def version_tuple(value):
    return tuple(int(part) for part in re.findall(r"\d+", str(value)))


def device_rank(name):
    if name == "Apple TV":
        return 0
    if "1080p" in name:
        return 1
    return 2


def select_simulator(catalog, sdk_version):
    """Choose an available tvOS runtime and discovered device type, never a UDID."""
    runtimes = [item for item in catalog.get("runtimes", [])
                if item.get("isAvailable") is True
                and (".tvOS-" in item.get("identifier", "")
                     or item.get("name", "").startswith("tvOS "))]
    if not runtimes:
        raise ValueError("No available tvOS Simulator runtime is installed")
    sdk = version_tuple(sdk_version)[:2]
    runtimes.sort(key=lambda item: (version_tuple(item.get("version", ""))[:2] == sdk,
                                    version_tuple(item.get("version", ""))), reverse=True)
    types = {item["identifier"]: item for item in catalog.get("devicetypes", [])
             if item.get("identifier") and item.get("name", "").startswith("Apple TV")}
    for runtime in runtimes:
        # Existing devices are evidence that the type and runtime are compatible.
        candidates = []
        for device in catalog.get("devices", {}).get(runtime["identifier"], []):
            if device.get("isAvailable") is not True:
                continue
            identifier = device.get("deviceTypeIdentifier")
            if identifier in types:
                candidates.append(types[identifier])
        if not candidates:
            supported = runtime.get("supportedDeviceTypes", [])
            for item in supported:
                identifier = item.get("identifier") if isinstance(item, dict) else item
                if identifier in types:
                    candidates.append(types[identifier])
        if candidates:
            selected_type = min(candidates, key=lambda item: (device_rank(item["name"]), item["name"]))
            return {"runtime": runtime["identifier"], "runtime_name": runtime.get("name", ""),
                    "runtime_version": runtime.get("version", ""),
                    "device_type": selected_type["identifier"], "device_name": selected_type["name"]}
    raise ValueError("No discovered compatible Apple TV device type is available")


def run(command, *, timeout=120, capture=False, check=True):
    print("$ " + shlex.join(str(part) for part in command), flush=True)
    return subprocess.run(command, cwd=ROOT, text=True, check=check, timeout=timeout,
                          stdout=subprocess.PIPE if capture else None,
                          stderr=subprocess.STDOUT if capture else None)


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def run_recorded_ui(command, device, output, timeout=UI_CAPTURE_TIMEOUT_SECONDS):
    """Record the real remote transition tour, not a reconstructed animation.

    simctl io help documents H.264 and SIGINT finalization. Only the recorder
    created here is stopped; unrelated Simulator devices/processes are untouched.
    """
    print("$ " + shlex.join(str(part) for part in command), flush=True)
    recorder = None
    recording_test = None
    recordings = {"testAMotionTour": "Asan-motion-tour.mp4", "testBIntroPlaysAndEnds": "Asan-launch-intro.mp4"}
    video_log = (output / "motion-recording.log").open("w", encoding="utf-8")
    process = subprocess.Popen(command, cwd=ROOT, text=True, stdout=subprocess.PIPE,
                               stderr=subprocess.STDOUT, env={**os.environ, "NSUnbufferedIO": "YES"})
    timed_out = threading.Event()

    def expire():
        if process.poll() is not None:
            return
        timed_out.set()
        # Let xcodebuild finish the result bundle before any forced stop. A
        # timed-out run remains a failure even if SIGINT yields exit code zero.
        try:
            process.send_signal(signal.SIGINT)
            process.wait(timeout=30)
        except (OSError, subprocess.TimeoutExpired):
            if process.poll() is None:
                process.kill()

    def stop_recording():
        nonlocal recorder
        if recorder is None:
            return
        if recorder.poll() is None:
            recorder.send_signal(signal.SIGINT)
        try:
            recorder.wait(timeout=25)
        except subprocess.TimeoutExpired:
            recorder.kill()
            recorder.wait(timeout=10)
        recorder = None

    timer = threading.Timer(timeout, expire)
    timer.start()
    try:
        for line in process.stdout:
            print(line, end="", flush=True)
            for method, filename in recordings.items():
                if method in line and "started" in line and recorder is None:
                    recording_test = method
                    recorder = subprocess.Popen(["xcrun", "simctl", "io", device, "recordVideo", "--codec=h264", "--force",
                        str(output / filename)], stdout=video_log, stderr=subprocess.STDOUT)
                if method == recording_test and method in line and ("passed" in line or "failed" in line):
                    stop_recording()
                    recording_test = None
        code = process.wait(timeout=35 if timed_out.is_set() else 15)
        if timed_out.is_set():
            raise subprocess.TimeoutExpired(command, timeout)
        return subprocess.CompletedProcess(command, code)
    finally:
        timer.cancel()
        if process.poll() is None:
            process.kill()
            process.wait(timeout=10)
        stop_recording()
        video_log.close()


def export_ui_results(output, result_bundle):
    """Preserve native attachments/summary on both success and interrupted runs."""
    if not result_bundle.exists():
        return None
    errors = []
    can_export = False
    try:
        help_result = run(["xcrun", "xcresulttool", "export", "attachments", "--help"],
                          capture=True, check=False, timeout=30)
        (output / "xcresult-attachments-help.txt").write_text(help_result.stdout, encoding="utf-8")
        can_export = help_result.returncode == 0
    except (OSError, subprocess.SubprocessError) as error:
        errors.append({"stage": "attachments-help", "error": str(error)})
    if can_export:
        try:
            result = run(["xcrun", "xcresulttool", "export", "attachments", "--path", str(result_bundle),
                          "--output-path", str(output / "ui-attachments")], check=False, timeout=60)
            if result.returncode != 0:
                errors.append({"stage": "attachments", "exit_code": result.returncode})
        except (OSError, subprocess.SubprocessError) as error:
            errors.append({"stage": "attachments", "error": str(error)})
    summary_data = None
    try:
        summary = run(["xcrun", "xcresulttool", "get", "test-results", "summary", "--path", str(result_bundle)],
                      capture=True, check=False, timeout=30)
        (output / "ui-test-summary.json").write_text(summary.stdout, encoding="utf-8")
        if summary.returncode == 0:
            summary_data = json.loads(summary.stdout)
            if not isinstance(summary_data, dict):
                raise ValueError("Native UI summary is not an object")
        else:
            errors.append({"stage": "summary", "exit_code": summary.returncode})
    except (OSError, ValueError, subprocess.SubprocessError) as error:
        errors.append({"stage": "summary", "error": str(error)})
        summary_data = None
    if errors:
        write_json(output / "xcresult-export-errors.json", errors)
    return summary_data


def capture_help(output):
    for name, arguments in {
        "simctl-help.txt": ["help"],
        "simctl-bootstatus-help.txt": ["help", "bootstatus"],
        "simctl-launch-help.txt": ["help", "launch"],
        "simctl-io-help.txt": ["io", "help"],
    }.items():
        try:
            result = run(["xcrun", "simctl", *arguments], capture=True, check=False, timeout=15)
            (output / name).write_text(result.stdout, encoding="utf-8")
        except (OSError, subprocess.SubprocessError) as error:
            # Help collection is diagnostic only, after a functional list call.
            # Do not let a cold/stalled service prevent the actual capture.
            (output / (name + ".error.txt")).write_text(str(error), encoding="utf-8")
            break


def validate_xcode(output, metadata):
    developer = run(["xcode-select", "-p"], capture=True, timeout=30).stdout.strip()
    metadata["developer_directory"] = developer
    status = run(["xcodebuild", "-checkFirstLaunchStatus"], capture=True, check=False, timeout=45)
    metadata["first_launch_status"] = status.returncode
    (output / "xcode-first-launch-status.txt").write_text(status.stdout, encoding="utf-8")
    write_json(output / "capture-metadata.json", metadata)
    if status.returncode != 0:
        raise RuntimeError("Selected Xcode has unfinished first-launch setup; no license was accepted or setup run")
    return developer


def warm_simulator_service(output, metadata):
    developer = metadata["developer_directory"]
    simulator = Path(developer) / "Applications/Simulator.app"
    if simulator.is_dir():
        # Use the selected Xcode's app, not a potentially different registered
        # Simulator version. This opens a persistent CoreSimulator client.
        opened = run(["open", "-g", "-a", str(simulator)], capture=True, check=False, timeout=30)
        metadata["simulator_open_status"] = opened.returncode
        (output / "simulator-open.txt").write_text(opened.stdout, encoding="utf-8")
    else:
        metadata["simulator_app_missing"] = str(simulator)
    write_json(output / "capture-metadata.json", metadata)


def collect_failure_logs(output, device):
    # These host diagnostics do not require a working CoreSimulator XPC
    # connection. Repeating simctl list here would only repeat the same hang.
    commands = {
        "failure-core-service.txt": ["launchctl", "print",
                                      f"gui/{os.getuid()}/com.apple.CoreSimulator.CoreSimulatorService"],
        "failure-host-processes.txt": ["ps", "-axo", "pid,ppid,state,etime,comm"],
        "failure-core-service.log": ["/usr/bin/log", "show", "--last", "5m", "--style", "compact",
                                     "--predicate", 'process == "CoreSimulatorService" OR process == "simdiskimaged" OR process == "simctl" OR process == "xcodebuild"'],
    }
    if device:
        commands["failure-app.log"] = ["xcrun", "simctl", "spawn", device, "log", "show",
                                       "--last", "3m", "--style", "compact", "--predicate",
                                       'process == "KinoHD"']
    for name, command in commands.items():
        try:
            result = run(command, capture=True, check=False, timeout=30)
            text = result.stdout
            if name == "failure-host-processes.txt":
                text = "\n".join(line for line in text.splitlines()
                                 if re.search(r"CoreSimulator|simctl|simdiskimaged|Simulator\.app|xcodebuild|SecurityAgent", line))
            (output / name).write_text(text, encoding="utf-8")
        except (OSError, subprocess.SubprocessError) as error:
            (output / (name + ".error.txt")).write_text(str(error), encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "artifacts/preview")
    arguments = parser.parse_args()
    if sys.platform != "darwin":
        parser.error("This capture requires macOS with full Xcode and a tvOS Simulator runtime")
    host_architecture = os.uname().machine
    if host_architecture != "x86_64":
        parser.error("AsanTorrent currently supports x86_64 tvOS Simulator only; run this capture on an Intel macOS host")
    output = arguments.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    created_device = None
    result_bundle = None
    results_exported = False
    metadata = {"bundle_id": BUNDLE_ID, "configuration": "Debug", "captures": [],
                "host_architecture": host_architecture, "expected_ui_tests": EXPECTED_UI_TEST_COUNT,
                "expected_minimum_screenshots": EXPECTED_MINIMUM_SCREENSHOTS,
                "intro_proof_label": INTRO_PROOF_LABEL}
    try:
        validate_xcode(output, metadata)
        sdk_version = run(["xcrun", "--sdk", "appletvsimulator", "--show-sdk-version"],
                          capture=True, timeout=120).stdout.strip()
        # Match the generic Simulator build already validated in the main CI.
        # Do all compilation before opening Simulator or starting its services.
        derived = ROOT / ".build/preview"
        run(["xcodebuild", "build", "-project", "KinoHD.xcodeproj", "-scheme", "KinoHD",
             "-configuration", "Debug", "-sdk", "appletvsimulator",
             "-destination", "generic/platform=tvOS Simulator", "-derivedDataPath", str(derived),
             f"ARCHS={host_architecture}", "ONLY_ACTIVE_ARCH=YES", "CODE_SIGNING_ALLOWED=NO"], timeout=720)
        app = derived / "Build/Products/Debug-appletvsimulator/KinoHD.app"
        with (app / "Info.plist").open("rb") as handle:
            info = plistlib.load(handle)
        if info.get("CFBundleIdentifier") != BUNDLE_ID or info.get("CFBundleSupportedPlatforms") != ["AppleTVSimulator"]:
            raise ValueError("The built bundle is not the expected tvOS Simulator application")
        # Keep Simulator.app closed: it may auto-boot an unrelated default
        # device and compete for resources with the disposable test device.
        # The first CoreSimulator client can require a cold XPC/service start.
        # A short help timeout must not be the capture's prerequisite gate.
        catalog_text = run(["xcrun", "simctl", "list", "--json"], capture=True, timeout=180).stdout
        (output / "simulator-list.json").write_text(catalog_text, encoding="utf-8")
        selection = select_simulator(json.loads(catalog_text), sdk_version)
        capture_help(output)
        metadata.update(selection)
        metadata["sdk_version"] = sdk_version
        write_json(output / "capture-metadata.json", metadata)
        name = "KinoHD-Preview-" + uuid.uuid4().hex[:8]
        result = run(["xcrun", "simctl", "create", name, selection["device_type"], selection["runtime"]],
                     capture=True, timeout=60)
        device_identifier = result.stdout.strip()
        uuid.UUID(device_identifier)
        created_device = device_identifier
        metadata["disposable_device"] = created_device
        write_json(output / "capture-metadata.json", metadata)
        # Xcode's test runner owns boot/readiness rather than a fragile
        # bootstatus/shutdown/dyld-cache retry chain.
        result_bundle = ROOT / ".build/Asan-UI.xcresult"
        ui = run_recorded_ui(["xcodebuild", "test", "-project", "KinoHD.xcodeproj", "-scheme", "KinoHD",
                  "-configuration", "Debug", "-destination", f"platform=tvOS Simulator,id={created_device},arch={host_architecture}",
                  "-destination-timeout", "180", "-derivedDataPath", str(derived),
                  "-resultBundlePath", str(result_bundle), "-parallel-testing-enabled", "NO",
                  "-test-timeouts-enabled", "YES", "-default-test-execution-time-allowance", "180",
                  "-maximum-test-execution-time-allowance", "180", f"ARCHS={host_architecture}",
                  "ONLY_ACTIVE_ARCH=YES", "CODE_SIGNING_ALLOWED=NO"],
                 created_device, output, timeout=UI_CAPTURE_TIMEOUT_SECONDS)
        metadata["ui_test_exit_code"] = ui.returncode
        write_json(output / "capture-metadata.json", metadata)
        summary_data = export_ui_results(output, result_bundle)
        results_exported = True
        if ui.returncode == 0:
            if summary_data is None:
                raise ValueError("Native UI summary missing; a green process exit is insufficient")
            validate_ui_summary(summary_data)
            video = output / "Asan-motion-tour.mp4"
            if not video.is_file() or video.stat().st_size < 10000:
                raise RuntimeError("UI tests passed but the actual transition recording is missing")
            metadata["motion_recording"] = {"file": video.name, "bytes": video.stat().st_size,
                "source": "simctl H.264 recording during testAMotionTour; Simulator, not physical A8 FPS"}
            intro_video = output / "Asan-launch-intro.mp4"
            if not intro_video.is_file() or intro_video.stat().st_size < 10000:
                raise RuntimeError("UI tests passed but the actual launch intro recording is missing")
            metadata["intro_recording"] = {"file": intro_video.name, "bytes": intro_video.stat().st_size,
                "source": "simctl H.264 recording during testBIntroPlaysAndEnds; real bundled intro, then intentional Home/reactivation after catalogue proof"}
            # XCUIApplication verifies foreground state and ready elements before
            # each attachment. Process-alive alone was insufficient: simctl's
            # terminate+launch race could capture SpringBoard instead of our UI.
            captured = sorted((output / "ui-attachments").rglob("*.png"))
            if len(captured) < EXPECTED_MINIMUM_SCREENSHOTS:
                raise RuntimeError("UI tests returned success but expected screenshot attachments are missing")
            metadata["captures"] = [{"file": str(path.relative_to(output)), "source": "XCTest foreground-checked"}
                                    for path in captured]
            metadata["result"] = "success"
            write_json(output / "capture-metadata.json", metadata)
            return
        raise RuntimeError(f"Native UI tests failed (exit {ui.returncode}); XCTest attachments retained for diagnosis")
    except (OSError, ValueError, RuntimeError, subprocess.SubprocessError) as error:
        metadata["result"] = "failure"
        metadata["error"] = str(error)
        write_json(output / "capture-metadata.json", metadata)
        if result_bundle is not None and not results_exported:
            # TimeoutExpired used to skip export entirely and then delete the
            # disposable device. Try the finalized result before that cleanup.
            export_ui_results(output, result_bundle)
        collect_failure_logs(output, created_device)
        parser.exit(1, f"Preview capture failed: {error}\n")
    finally:
        if created_device:
            # This UUID came from this invocation's create command. Never alter
            # any pre-existing simulator, or use broad shutdown/delete commands.
            for command in ("shutdown", "delete"):
                try:
                    run(["xcrun", "simctl", command, created_device], check=False, timeout=30)
                except (OSError, subprocess.SubprocessError) as error:
                    print(f"Could not {command} disposable simulator: {error}", file=sys.stderr)


if __name__ == "__main__":
    main()
