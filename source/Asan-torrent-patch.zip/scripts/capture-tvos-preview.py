#!/usr/bin/env python3
"""Launch the real Debug app on a disposable tvOS Simulator and capture scenes.

Apple Simulator commands: https://developer.apple.com/library/archive/documentation/IDEs/Conceptual/iOS_Simulator_Guide/InteractingwiththeiOSSimulator/InteractingwiththeiOSSimulator.html
First-boot workaround: https://developer.apple.com/documentation/Xcode-Release-Notes/xcode-26_1-release-notes
The current installed simctl help is saved with the screenshots. No accounts,
signing certificates or credentials are supplied by this script.
Xcode readiness: https://developer.apple.com/documentation/xcode/downloading-and-installing-additional-xcode-components
The script checks first-launch status but never accepts a license or runs setup.
"""
import argparse
import json
import os
import plistlib
import re
import shlex
import shutil
import signal
import subprocess
import sys
import threading
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BUNDLE_ID = "dev.local.KinoHD"
EXPECTED_UI_TEST_COUNT = 29
EXPECTED_MINIMUM_SCREENSHOTS = 50
INTRO_PROOF_LABEL = "intro-playback-proof"
UI_CAPTURE_TIMEOUT_SECONDS = 2400
PREFLIGHT_METHODS = (
    "testBIntroPlaysAndEnds",
    "testLocalAVKitResumesHistoryAndStartsFromZero",
    "testLocalVLCConfiguredIntroSkipSeeksActualClock",
    "testLocalVLCResumesHistoryAndStartsFromZero",
    "testRecoveryOffersTorrentForSameFilm",
    "testSearchUsesNativeKeyboardWithoutOverlappingHeading",
    "testSeriesIntroSettingSavesAndReopens",
    "testSeriesMultiselectQueuesBothEpisodesViaUp",
)


def validate_ui_summary(summary, expected_count=EXPECTED_UI_TEST_COUNT):
    """An older green subset must not validate the required 0.7 feature set."""
    if summary.get("result") != "Passed" or summary.get("totalTestCount") != expected_count:
        raise ValueError(f"Expected all {expected_count} native UI tests, got {summary.get('totalTestCount')}")
    if summary.get("passedTests") != expected_count or any(
            summary.get(key) != 0 for key in ("failedTests", "skippedTests", "expectedFailures")):
        raise ValueError("Native UI validation requires no failures, skipped tests or expected failures")


def ui_test_command(device, architecture, derived, result_bundle, methods=()):
    command = ["xcodebuild", "test", "-project", "KinoHD.xcodeproj", "-scheme", "KinoHD",
               "-configuration", "Debug", "-destination",
               f"platform=tvOS Simulator,id={device},arch={architecture}",
               "-destination-timeout", "180", "-derivedDataPath", str(derived),
               "-resultBundlePath", str(result_bundle), "-parallel-testing-enabled", "NO",
               "-test-timeouts-enabled", "YES", "-default-test-execution-time-allowance", "180",
               "-maximum-test-execution-time-allowance", "300", f"ARCHS={architecture}",
               "ONLY_ACTIVE_ARCH=YES", "CODE_SIGNING_ALLOWED=NO"]
    return command + [f"-only-testing:AsanUITests/AsanUITests/{method}" for method in methods]


def run_preflight(device, architecture, derived, output):
    """Fail early on actual regressions; this subset never replaces full capture."""
    evidence = output / "preflight"
    evidence.mkdir()
    for number, method in enumerate(PREFLIGHT_METHODS, start=1):
        case_output = evidence / method
        case_output.mkdir()
        bundle = ROOT / f".build/Asan-UI-preflight-{number}.xcresult"
        summary = None
        try:
            result = run_recorded_ui(ui_test_command(device, architecture, derived, bundle, (method,)),
                                     device, case_output, timeout=600)
        finally:
            summary = export_ui_results(case_output, bundle)
        if result.returncode != 0:
            raise RuntimeError(f"Native UI regression {method} failed (exit {result.returncode})")
        if summary is None:
            raise ValueError(f"Native UI regression summary is missing: {method}")
        # A mistyped -only-testing selector can exit zero with no tests.
        validate_ui_summary(summary, expected_count=1)
    return {"result": "Passed", "tests": len(PREFLIGHT_METHODS),
            "methods": PREFLIGHT_METHODS, "full_suite_still_required": True}


def complete_ui_methods():
    """Discover the complete registered suite; never accept the regression subset."""
    source = (ROOT / "UITests/AsanUITests.swift").read_text(encoding="utf-8")
    methods = re.findall(r"\bfunc\s+(test\w+)\s*\(", source)
    if len(methods) != EXPECTED_UI_TEST_COUNT or len(set(methods)) != len(methods):
        raise ValueError("The complete native UI method set is missing or duplicated")
    if not set(PREFLIGHT_METHODS).issubset(methods):
        raise ValueError("A required regression is absent from the native suite")
    return (*PREFLIGHT_METHODS, *sorted(set(methods) - set(PREFLIGHT_METHODS)))


def validate_native_test_tree(tree, methods):
    """Cross-check native executed identities, including tests without screenshots.

    Schema/usage: Chromium's Xcode16LogParser._xcresulttool_get_tests and
    _find_test_cases in ios/build/bots/scripts/xcode_log_parser.py.
    """
    cases = []

    def visit(node):
        if isinstance(node, list):
            for child in node:
                visit(child)
        elif isinstance(node, dict):
            if node.get("nodeType") == "Test Case":
                cases.append(node)
            else:
                visit(node.get("children", []))

    visit(tree.get("testNodes", []))
    expected = {f"AsanUITests/{method}()" for method in methods}
    actual = [case.get("nodeIdentifier") for case in cases]
    if len(actual) != len(expected) or set(actual) != expected:
        raise ValueError(f"Native executed test identities differ: {actual}")
    if any(case.get("result") != "Passed" for case in cases):
        raise ValueError("Native test tree contains a non-passing test")


def export_test_tree(output, bundle, methods):
    result = run(["xcrun", "xcresulttool", "get", "test-results", "tests", "--path", str(bundle)],
                 capture=True, timeout=60)
    (output / "ui-test-tree.json").write_text(result.stdout, encoding="utf-8")
    validate_native_test_tree(json.loads(result.stdout), methods)


def run_isolated_suite(device, architecture, derived, output, merged_bundle):
    """Run every test once in a fresh XCTest process, then merge real bundles.

    No retries, assertion changes or fabricated aggregate summary. The same
    app/build and owned Simulator are used throughout. xcresulttool itself
    produces the final 29-test summary and attachment manifest.
    Merge usage: https://github.com/a7ex/xcresultparser#how-to-use-it
    """
    methods = complete_ui_methods()
    help_result = run(["xcrun", "xcresulttool", "merge", "--help"], capture=True, timeout=30)
    (output / "xcresult-merge-help.txt").write_text(help_result.stdout, encoding="utf-8")
    evidence = output / "isolated"
    evidence.mkdir()
    bundles = []
    for number, method in enumerate(methods, start=1):
        print(f"Isolated native UI {number}/{len(methods)}: {method}", flush=True)
        case_output = evidence / method
        case_output.mkdir()
        bundle = ROOT / f".build/Asan-UI-case-{number}.xcresult"
        try:
            result = run_recorded_ui(ui_test_command(device, architecture, derived, bundle, (method,)),
                                     device, case_output, timeout=600)
        finally:
            summary = export_ui_results(case_output, bundle)
        if result.returncode != 0:
            raise RuntimeError(f"Native UI test {method} failed (exit {result.returncode}); no retry")
        if summary is None:
            raise ValueError(f"Missing native one-test summary: {method}")
        validate_ui_summary(summary, expected_count=1)
        export_test_tree(case_output, bundle, (method,))
        bundles.append(bundle)
        for filename in ("Asan-motion-tour.mp4", "Asan-launch-intro.mp4"):
            video = case_output / filename
            if video.is_file():
                if (output / filename).exists():
                    raise ValueError("Duplicate native video recording")
                shutil.copyfile(video, output / filename)
    run(["xcrun", "xcresulttool", "merge", *map(str, bundles),
         "--output-path", str(merged_bundle)], timeout=180)
    export_test_tree(output, merged_bundle, methods)
    return {"result": "Passed", "tests": len(methods), "methods": methods,
            "execution": "one fresh XCTest process per method; no retries; native xcresulttool merge"}


def version_tuple(value):
    return tuple(int(part) for part in re.findall(r"\d+", str(value)))


def device_rank(name):
    if name == "Apple TV":
        return 0
    if "1080p" in name:
        return 1
    return 2


def select_simulator(catalog, sdk_version):
    """Choose an available tvOS runtime and discovered device type, never a UDID."""
    runtimes = [item for item in catalog.get("runtimes", [])
                if item.get("isAvailable") is True
                and (".tvOS-" in item.get("identifier", "")
                     or item.get("name", "").startswith("tvOS "))]
    if not runtimes:
        raise ValueError("No available tvOS Simulator runtime is installed")
    sdk = version_tuple(sdk_version)[:2]
    runtimes.sort(key=lambda item: (version_tuple(item.get("version", ""))[:2] == sdk,
                                    version_tuple(item.get("version", ""))), reverse=True)
    types = {item["identifier"]: item for item in catalog.get("devicetypes", [])
             if item.get("identifier") and item.get("name", "").startswith("Apple TV")}
    for runtime in runtimes:
        # Existing devices are evidence that the type and runtime are compatible.
        candidates = []
        for device in catalog.get("devices", {}).get(runtime["identifier"], []):
            if device.get("isAvailable") is not True:
                continue
            identifier = device.get("deviceTypeIdentifier")
            if identifier in types:
                candidates.append(types[identifier])
        if not candidates:
            supported = runtime.get("supportedDeviceTypes", [])
            for item in supported:
                identifier = item.get("identifier") if isinstance(item, dict) else item
                if identifier in types:
                    candidates.append(types[identifier])
        if candidates:
            selected_type = min(candidates, key=lambda item: (device_rank(item["name"]), item["name"]))
            return {"runtime": runtime["identifier"], "runtime_name": runtime.get("name", ""),
                    "runtime_version": runtime.get("version", ""),
                    "device_type": selected_type["identifier"], "device_name": selected_type["name"]}
    raise ValueError("No discovered compatible Apple TV device type is available")


def run(command, *, timeout=120, capture=False, check=True):
    print("$ " + shlex.join(str(part) for part in command), flush=True)
    return subprocess.run(command, cwd=ROOT, text=True, check=check, timeout=timeout,
                          stdout=subprocess.PIPE if capture else None,
                          stderr=subprocess.STDOUT if capture else None)


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def run_recorded_ui(command, device, output, timeout=UI_CAPTURE_TIMEOUT_SECONDS):
    """Record the real remote transition tour, not a reconstructed animation.

    simctl io help documents H.264 and SIGINT finalization. Only the recorder
    created here is stopped; unrelated Simulator devices/processes are untouched.
    """
    print("$ " + shlex.join(str(part) for part in command), flush=True)
    recorder = None
    recording_test = None
    recordings = {"testAMotionTour": "Asan-motion-tour.mp4", "testBIntroPlaysAndEnds": "Asan-launch-intro.mp4"}
    video_log = (output / "motion-recording.log").open("w", encoding="utf-8")
    process = subprocess.Popen(command, cwd=ROOT, text=True, stdout=subprocess.PIPE,
                               stderr=subprocess.STDOUT, env={**os.environ, "NSUnbufferedIO": "YES"})
    timed_out = threading.Event()

    def expire():
        if process.poll() is not None:
            return
        timed_out.set()
        # Let xcodebuild finish the result bundle before any forced stop. A
        # timed-out run remains a failure even if SIGINT yields exit code zero.
        try:
            process.send_signal(signal.SIGINT)
            process.wait(timeout=30)
        except (OSError, subprocess.TimeoutExpired):
            if process.poll() is None:
                process.kill()

    def stop_recording():
        nonlocal recorder
        if recorder is None:
            return
        if recorder.poll() is None:
            recorder.send_signal(signal.SIGINT)
        try:
            recorder.wait(timeout=25)
        except subprocess.TimeoutExpired:
            recorder.kill()
            recorder.wait(timeout=10)
        recorder = None

    timer = threading.Timer(timeout, expire)
    timer.start()
    try:
        for line in process.stdout:
            print(line, end="", flush=True)
            for method, filename in recordings.items():
                if method in line and "started" in line and recorder is None:
                    recording_test = method
                    recorder = subprocess.Popen(["xcrun", "simctl", "io", device, "recordVideo", "--codec=h264", "--force",
                        str(output / filename)], stdout=video_log, stderr=subprocess.STDOUT)
                if method == recording_test and method in line and ("passed" in line or "failed" in line):
                    stop_recording()
                    recording_test = None
        code = process.wait(timeout=35 if timed_out.is_set() else 15)
        if timed_out.is_set():
            raise subprocess.TimeoutExpired(command, timeout)
        return subprocess.CompletedProcess(command, code)
    finally:
        timer.cancel()
        if process.poll() is None:
            process.kill()
            process.wait(timeout=10)
        stop_recording()
        video_log.close()


def export_ui_results(output, result_bundle):
    """Preserve native attachments/summary on both success and interrupted runs."""
    if not result_bundle.exists():
        return None
    errors = []
    can_export = False
    try:
        help_result = run(["xcrun", "xcresulttool", "export", "attachments", "--help"],
                          capture=True, check=False, timeout=30)
        (output / "xcresult-attachments-help.txt").write_text(help_result.stdout, encoding="utf-8")
        can_export = help_result.returncode == 0
    except (OSError, subprocess.SubprocessError) as error:
        errors.append({"stage": "attachments-help", "error": str(error)})
    if can_export:
        try:
            result = run(["xcrun", "xcresulttool", "export", "attachments", "--path", str(result_bundle),
                          "--output-path", str(output / "ui-attachments")], check=False, timeout=60)
            if result.returncode != 0:
                errors.append({"stage": "attachments", "exit_code": result.returncode})
        except (OSError, subprocess.SubprocessError) as error:
            errors.append({"stage": "attachments", "error": str(error)})
    summary_data = None
    try:
        summary = run(["xcrun", "xcresulttool", "get", "test-results", "summary", "--path", str(result_bundle)],
                      capture=True, check=False, timeout=30)
        (output / "ui-test-summary.json").write_text(summary.stdout, encoding="utf-8")
        if summary.returncode == 0:
            summary_data = json.loads(summary.stdout)
            if not isinstance(summary_data, dict):
                raise ValueError("Native UI summary is not an object")
        else:
            errors.append({"stage": "summary", "exit_code": summary.returncode})
    except (OSError, ValueError, subprocess.SubprocessError) as error:
        errors.append({"stage": "summary", "error": str(error)})
        summary_data = None
    if errors:
        write_json(output / "xcresult-export-errors.json", errors)
    return summary_data


def capture_help(output):
    for name, arguments in {
        "simctl-help.txt": ["help"],
        "simctl-bootstatus-help.txt": ["help", "bootstatus"],
        "simctl-launch-help.txt": ["help", "launch"],
        "simctl-io-help.txt": ["io", "help"],
    }.items():
        try:
            result = run(["xcrun", "simctl", *arguments], capture=True, check=False, timeout=15)
            (output / name).write_text(result.stdout, encoding="utf-8")
        except (OSError, subprocess.SubprocessError) as error:
            # Help collection is diagnostic only, after a functional list call.
            # Do not let a cold/stalled service prevent the actual capture.
            (output / (name + ".error.txt")).write_text(str(error), encoding="utf-8")
            break


def validate_xcode(output, metadata):
    developer = run(["xcode-select", "-p"], capture=True, timeout=30).stdout.strip()
    metadata["developer_directory"] = developer
    status = run(["xcodebuild", "-checkFirstLaunchStatus"], capture=True, check=False, timeout=45)
    metadata["first_launch_status"] = status.returncode
    (output / "xcode-first-launch-status.txt").write_text(status.stdout, encoding="utf-8")
    write_json(output / "capture-metadata.json", metadata)
    if status.returncode != 0:
        raise RuntimeError("Selected Xcode has unfinished first-launch setup; no license was accepted or setup run")
    return developer


def warm_simulator_service(output, metadata):
    developer = metadata["developer_directory"]
    simulator = Path(developer) / "Applications/Simulator.app"
    if simulator.is_dir():
        # Use the selected Xcode's app, not a potentially different registered
        # Simulator version. This opens a persistent CoreSimulator client.
        opened = run(["open", "-g", "-a", str(simulator)], capture=True, check=False, timeout=30)
        metadata["simulator_open_status"] = opened.returncode
        (output / "simulator-open.txt").write_text(opened.stdout, encoding="utf-8")
    else:
        metadata["simulator_app_missing"] = str(simulator)
    write_json(output / "capture-metadata.json", metadata)


def collect_failure_logs(output, device):
    # These host diagnostics do not require a working CoreSimulator XPC
    # connection. Repeating simctl list here would only repeat the same hang.
    commands = {
        "failure-core-service.txt": ["launchctl", "print",
                                      f"gui/{os.getuid()}/com.apple.CoreSimulator.CoreSimulatorService"],
        "failure-host-processes.txt": ["ps", "-axo", "pid,ppid,state,etime,comm"],
        "failure-core-service.log": ["/usr/bin/log", "show", "--last", "5m", "--style", "compact",
                                     "--predicate", 'process == "CoreSimulatorService" OR process == "simdiskimaged" OR process == "simctl" OR process == "xcodebuild"'],
    }
    if device:
        commands["failure-app.log"] = ["xcrun", "simctl", "spawn", device, "log", "show",
                                       "--last", "3m", "--style", "compact", "--predicate",
                                       'process == "KinoHD"']
    for name, command in commands.items():
        try:
            result = run(command, capture=True, check=False, timeout=30)
            text = result.stdout
            if name == "failure-host-processes.txt":
                text = "\n".join(line for line in text.splitlines()
                                 if re.search(r"CoreSimulator|simctl|simdiskimaged|Simulator\.app|xcodebuild|SecurityAgent", line))
            (output / name).write_text(text, encoding="utf-8")
        except (OSError, subprocess.SubprocessError) as error:
            (output / (name + ".error.txt")).write_text(str(error), encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "artifacts/preview")
    parser.add_argument("--preflight-first", action="store_true",
                        help="Check eight regressions before the required complete UI run")
    parser.add_argument("--isolated-all", action="store_true",
                        help="Run all 29 tests once in isolated XCTest processes and merge native results")
    arguments = parser.parse_args()
    if arguments.preflight_first and arguments.isolated_all:
        parser.error("Isolated all already includes every regression exactly once")
    if sys.platform != "darwin":
        parser.error("This capture requires macOS with full Xcode and a tvOS Simulator runtime")
    host_architecture = os.uname().machine
    if host_architecture != "x86_64":
        parser.error("AsanTorrent currently supports x86_64 tvOS Simulator only; run this capture on an Intel macOS host")
    output = arguments.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    created_device = None
    result_bundle = None
    results_exported = False
    metadata = {"bundle_id": BUNDLE_ID, "configuration": "Debug", "captures": [],
                "host_architecture": host_architecture, "expected_ui_tests": EXPECTED_UI_TEST_COUNT,
                "expected_minimum_screenshots": EXPECTED_MINIMUM_SCREENSHOTS,
                "intro_proof_label": INTRO_PROOF_LABEL}
    try:
        validate_xcode(output, metadata)
        sdk_version = run(["xcrun", "--sdk", "appletvsimulator", "--show-sdk-version"],
                          capture=True, timeout=120).stdout.strip()
        # Reuse the exact Debug Simulator build already validated by
        # check-macos.sh in CI. xcodebuild still validates all inputs and builds
        # the UI-test target; standalone capture also performs its normal build.
        derived = ROOT / ".build/xcode"
        run(["xcodebuild", "build", "-project", "KinoHD.xcodeproj", "-scheme", "KinoHD",
             "-configuration", "Debug", "-sdk", "appletvsimulator",
             "-destination", "generic/platform=tvOS Simulator", "-derivedDataPath", str(derived),
             f"ARCHS={host_architecture}", "ONLY_ACTIVE_ARCH=YES", "CODE_SIGNING_ALLOWED=NO"], timeout=720)
        app = derived / "Build/Products/Debug-appletvsimulator/KinoHD.app"
        with (app / "Info.plist").open("rb") as handle:
            info = plistlib.load(handle)
        if info.get("CFBundleIdentifier") != BUNDLE_ID or info.get("CFBundleSupportedPlatforms") != ["AppleTVSimulator"]:
            raise ValueError("The built bundle is not the expected tvOS Simulator application")
        # Keep Simulator.app closed: it may auto-boot an unrelated default
        # device and compete for resources with the disposable test device.
        # The first CoreSimulator client can require a cold XPC/service start.
        # A short help timeout must not be the capture's prerequisite gate.
        catalog_text = run(["xcrun", "simctl", "list", "--json"], capture=True, timeout=180).stdout
        (output / "simulator-list.json").write_text(catalog_text, encoding="utf-8")
        selection = select_simulator(json.loads(catalog_text), sdk_version)
        capture_help(output)
        metadata.update(selection)
        metadata["sdk_version"] = sdk_version
        write_json(output / "capture-metadata.json", metadata)
        name = "KinoHD-Preview-" + uuid.uuid4().hex[:8]
        result = run(["xcrun", "simctl", "create", name, selection["device_type"], selection["runtime"]],
                     capture=True, timeout=60)
        device_identifier = result.stdout.strip()
        uuid.UUID(device_identifier)
        created_device = device_identifier
        metadata["disposable_device"] = created_device
        write_json(output / "capture-metadata.json", metadata)
        if arguments.preflight_first:
            metadata["regression_preflight"] = run_preflight(created_device, host_architecture, derived, output)
            write_json(output / "capture-metadata.json", metadata)
        # Xcode's test runner owns boot/readiness rather than a fragile
        # bootstatus/shutdown/dyld-cache retry chain.
        result_bundle = ROOT / ".build/Asan-UI.xcresult"
        if arguments.isolated_all:
            metadata["isolated_suite"] = run_isolated_suite(created_device, host_architecture, derived, output, result_bundle)
            ui = subprocess.CompletedProcess([], 0)
        else:
            ui = run_recorded_ui(ui_test_command(created_device, host_architecture, derived, result_bundle),
                     created_device, output, timeout=UI_CAPTURE_TIMEOUT_SECONDS)
        metadata["ui_test_exit_code"] = ui.returncode
        write_json(output / "capture-metadata.json", metadata)
        summary_data = export_ui_results(output, result_bundle)
        results_exported = True
        if ui.returncode == 0:
            if summary_data is None:
                raise ValueError("Native UI summary missing; a green process exit is insufficient")
            validate_ui_summary(summary_data)
            video = output / "Asan-motion-tour.mp4"
            if not video.is_file() or video.stat().st_size < 10000:
                raise RuntimeError("UI tests passed but the actual transition recording is missing")
            metadata["motion_recording"] = {"file": video.name, "bytes": video.stat().st_size,
                "source": "simctl H.264 recording during testAMotionTour; Simulator, not physical A8 FPS"}
            intro_video = output / "Asan-launch-intro.mp4"
            if not intro_video.is_file() or intro_video.stat().st_size < 10000:
                raise RuntimeError("UI tests passed but the actual launch intro recording is missing")
            metadata["intro_recording"] = {"file": intro_video.name, "bytes": intro_video.stat().st_size,
                "source": "simctl H.264 recording during testBIntroPlaysAndEnds; real bundled intro, then intentional Home/reactivation after catalogue proof"}
            # XCUIApplication verifies foreground state and ready elements before
            # each attachment. Process-alive alone was insufficient: simctl's
            # terminate+launch race could capture SpringBoard instead of our UI.
            captured = sorted((output / "ui-attachments").rglob("*.png"))
            if len(captured) < EXPECTED_MINIMUM_SCREENSHOTS:
                raise RuntimeError("UI tests returned success but expected screenshot attachments are missing")
            metadata["captures"] = [{"file": str(path.relative_to(output)), "source": "XCTest foreground-checked"}
                                    for path in captured]
            metadata["result"] = "success"
            write_json(output / "capture-metadata.json", metadata)
            return
        raise RuntimeError(f"Native UI tests failed (exit {ui.returncode}); XCTest attachments retained for diagnosis")
    except (OSError, ValueError, RuntimeError, subprocess.SubprocessError) as error:
        metadata["result"] = "failure"
        metadata["error"] = str(error)
        write_json(output / "capture-metadata.json", metadata)
        if result_bundle is not None and not results_exported:
            # TimeoutExpired used to skip export entirely and then delete the
            # disposable device. Try the finalized result before that cleanup.
            export_ui_results(output, result_bundle)
        collect_failure_logs(output, created_device)
        parser.exit(1, f"Preview capture failed: {error}\n")
    finally:
        if created_device:
            # This UUID came from this invocation's create command. Never alter
            # any pre-existing simulator, or use broad shutdown/delete commands.
            for command in ("shutdown", "delete"):
                try:
                    run(["xcrun", "simctl", command, created_device], check=False, timeout=30)
                except (OSError, subprocess.SubprocessError) as error:
                    print(f"Could not {command} disposable simulator: {error}", file=sys.stderr)


if __name__ == "__main__":
    main()
