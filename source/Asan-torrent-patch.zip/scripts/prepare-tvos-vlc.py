#!/usr/bin/env python3
"""Fetch the pinned official VideoLAN tvOS framework, never a third-party IPA.

Upstream: https://download.videolan.org/pub/cocoapods/prod/
Archive API: https://docs.python.org/3/library/tarfile.html
The recorded SHA256 was computed from the inspected upstream 3.7.3 archive.
"""
import hashlib
import json
import os
import shutil
import tarfile
import tempfile
import urllib.parse
import urllib.request
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parents[1]
NAME = 'TVVLCKit-3.7.3-319ed2c0-79128878.tar.xz'
URL = 'https://download.videolan.org/pub/cocoapods/prod/' + NAME
SHA256 = 'b5f90c226ed54d9dc1c03901c60dc7749b74a53caace2c3047e4c0b7a063e46c'
SIZE = 121_449_476
PREFIX = PurePosixPath('TVVLCKit-binary/TVVLCKit.xcframework')


def extract_framework(archive, target):
    """Extract regular files from exactly the framework subtree, no links."""
    target = Path(target).resolve()
    total = 0
    count = 0
    with tarfile.open(archive, 'r:xz') as package:
        for member in package:
            path = PurePosixPath(member.name)
            if path.is_absolute() or '..' in path.parts or '\\' in member.name:
                raise ValueError('Unsafe archive path')
            if path == PREFIX:
                continue
            if not path.is_relative_to(PREFIX):
                continue
            relative = path.relative_to(PREFIX)
            destination = target.joinpath(*relative.parts)
            if not destination.resolve().is_relative_to(target):
                raise ValueError('Archive escaped framework')
            if member.isdir():
                destination.mkdir(parents=True, exist_ok=True)
            elif member.isfile():
                total += member.size
                count += 1
                if total > 1_500_000_000 or count > 20_000:
                    raise ValueError('Framework exceeds inspected bounds')
                destination.parent.mkdir(parents=True, exist_ok=True)
                with package.extractfile(member) as source, destination.open('wb') as output:
                    shutil.copyfileobj(source, output)
                os.chmod(destination, 0o755 if member.mode & 0o111 else 0o644)
            else:
                raise ValueError('Framework links/special files are not accepted')
    if not (target / 'Info.plist').is_file():
        raise ValueError('Missing XCFramework Info.plist')


def main():
    cache = ROOT / '.torrent-build/archives'
    cache.mkdir(parents=True, exist_ok=True)
    archive = cache / NAME
    if not archive.exists():
        temporary = archive.with_suffix('.download')
        try:
            digest = hashlib.sha256()
            size = 0
            with urllib.request.urlopen(URL, timeout=60) as response, temporary.open('wb') as output:
                final = urllib.parse.urlsplit(response.geturl())
                if final.scheme != 'https' or final.hostname != 'download.videolan.org':
                    raise ValueError('Unexpected framework download origin')
                while block := response.read(1_048_576):
                    size += len(block)
                    if size > SIZE:
                        raise ValueError('Unexpected framework archive size')
                    digest.update(block)
                    output.write(block)
            if size != SIZE or digest.hexdigest() != SHA256:
                raise ValueError('VideoLAN archive checksum mismatch')
            os.replace(temporary, archive)
        finally:
            temporary.unlink(missing_ok=True)
    with archive.open('rb') as source:
        if archive.stat().st_size != SIZE or hashlib.file_digest(source, 'sha256').hexdigest() != SHA256:
            raise ValueError('Cached VideoLAN archive checksum mismatch')
    # The full LGPL notice is distributed with the app, not only kept in CI.
    with tarfile.open(archive, 'r:xz') as package:
        notice = package.getmember('TVVLCKit-binary/COPYING.txt')
        if not notice.isfile() or notice.size > 100_000:
            raise ValueError('Unexpected upstream license notice')
        license_path = ROOT / 'App/TorrentLicenses/TVVLCKit-LGPL-2.1.txt'
        license_path.parent.mkdir(parents=True, exist_ok=True)
        license_path.write_bytes(package.extractfile(notice).read())
    vendor = ROOT / 'Vendor'
    vendor.mkdir(exist_ok=True)
    target = vendor / 'TVVLCKit.xcframework'
    if target.exists():
        # A CI checkout may reuse the generated framework; validate its provenance.
        provenance = target / 'ASAN-PROVENANCE.json'
        if provenance.is_file() and json.loads(provenance.read_text()).get('sha256') == SHA256:
            print('Pinned TVVLCKit 3.7.3 is already prepared')
            return
        raise ValueError('Existing framework lacks matching provenance; use a clean Vendor directory')
    with tempfile.TemporaryDirectory(prefix='vlc-', dir=vendor) as staging:
        extracted = Path(staging) / 'TVVLCKit.xcframework'
        extract_framework(archive, extracted)
        (extracted / 'ASAN-PROVENANCE.json').write_text(json.dumps({'url': URL, 'sha256': SHA256, 'version': '3.7.3'}))
        os.replace(extracted, target)
    print('Prepared official TVVLCKit 3.7.3 for Apple TV and Simulator')


if __name__ == '__main__':
    main()
