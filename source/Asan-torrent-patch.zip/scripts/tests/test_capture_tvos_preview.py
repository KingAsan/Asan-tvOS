"""Synthetic selection cases prevent choosing an iOS or unavailable runtime."""
import importlib.util
import re
import unittest
from pathlib import Path

SPEC = importlib.util.spec_from_file_location(
    "capture_tvos_preview", Path(__file__).resolve().parents[1] / "capture-tvos-preview.py"
)
CAPTURE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(CAPTURE)


class SimulatorSelectionTests(unittest.TestCase):
    def catalog(self):
        return {
            "runtimes": [
                {"identifier": "runtime.tvOS-26-4", "name": "tvOS 26.4", "version": "26.4", "isAvailable": True},
                {"identifier": "runtime.tvOS-26-5", "name": "tvOS 26.5", "version": "26.5", "isAvailable": True},
                {"identifier": "runtime.iOS-27-0", "name": "iOS 27.0", "version": "27.0", "isAvailable": True},
            ],
            "devicetypes": [
                {"identifier": "type.hd", "name": "Apple TV"},
                {"identifier": "type.1080", "name": "Apple TV 4K (3rd generation) (at 1080p)"},
                {"identifier": "type.4k", "name": "Apple TV 4K (3rd generation)"},
                {"identifier": "type.phone", "name": "iPhone 17"},
            ],
            "devices": {
                "runtime.tvOS-26-4": [{"deviceTypeIdentifier": "type.hd", "isAvailable": True}],
                "runtime.tvOS-26-5": [
                    {"deviceTypeIdentifier": "type.4k", "isAvailable": True},
                    {"deviceTypeIdentifier": "type.1080", "isAvailable": True},
                    {"deviceTypeIdentifier": "type.hd", "isAvailable": True},
                ],
                "runtime.iOS-27-0": [{"deviceTypeIdentifier": "type.phone", "isAvailable": True}],
            },
        }

    def test_prefers_matching_sdk_and_hd_over_newer_ios_or_4k(self):
        result = CAPTURE.select_simulator(self.catalog(), "26.5")
        self.assertEqual(result["runtime"], "runtime.tvOS-26-5")
        self.assertEqual(result["device_type"], "type.hd")
        result = CAPTURE.select_simulator(self.catalog(), "26.4")
        self.assertEqual(result["runtime"], "runtime.tvOS-26-4")

    def test_uses_1080p_fallback_without_hd_and_never_unavailable_runtime(self):
        catalog = self.catalog()
        catalog["devices"]["runtime.tvOS-26-5"][-1]["isAvailable"] = False
        result = CAPTURE.select_simulator(catalog, "26.5")
        self.assertEqual(result["device_type"], "type.1080")
        catalog["runtimes"][1]["isAvailable"] = False
        result = CAPTURE.select_simulator(catalog, "26.5")
        self.assertEqual(result["runtime"], "runtime.tvOS-26-4")

    def test_supported_type_metadata_can_create_device_without_existing_instance(self):
        catalog = self.catalog()
        catalog["devices"] = {}
        catalog["runtimes"][1]["supportedDeviceTypes"] = [{"identifier": "type.1080"}]
        result = CAPTURE.select_simulator(catalog, "26.5")
        self.assertEqual(result["device_type"], "type.1080")

    def test_no_available_tvos_or_discovered_compatible_type_is_an_error(self):
        catalog = self.catalog()
        catalog["runtimes"] = catalog["runtimes"][2:]
        with self.assertRaises(ValueError):
            CAPTURE.select_simulator(catalog, "26.5")
        catalog = self.catalog()
        catalog["devices"] = {}
        with self.assertRaises(ValueError):
            CAPTURE.select_simulator(catalog, "26.5")

    def test_native_summary_cannot_accept_old_subset_or_skipped_new_tests(self):
        summary = {"result": "Passed", "totalTestCount": 28, "passedTests": 28,
                   "failedTests": 0, "skippedTests": 0, "expectedFailures": 0}
        CAPTURE.validate_ui_summary(summary)
        for change in [{"totalTestCount": 20, "passedTests": 20},
                       {"passedTests": 27, "skippedTests": 1},
                       {"expectedFailures": 1}, {"result": "Failed"}]:
            with self.subTest(change=change), self.assertRaises(ValueError):
                CAPTURE.validate_ui_summary({**summary, **change})

    def test_capture_contract_matches_registered_ui_source(self):
        source = Path(__file__).resolve().parents[2] / "UITests/AsanUITests.swift"
        methods = re.findall(r"\bfunc\s+(test\w+)\s*\(", source.read_text(encoding="utf-8"))
        self.assertEqual(len(methods), len(set(methods)), "Duplicate test names")
        self.assertEqual(len(methods), CAPTURE.EXPECTED_UI_TEST_COUNT)
        self.assertGreaterEqual(CAPTURE.EXPECTED_MINIMUM_SCREENSHOTS, 48)


if __name__ == "__main__":
    unittest.main()
