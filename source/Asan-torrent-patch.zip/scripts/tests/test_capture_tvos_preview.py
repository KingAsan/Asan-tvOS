"""Synthetic selection cases prevent choosing an iOS or unavailable runtime."""
import importlib.util
import re
import signal
import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

SPEC = importlib.util.spec_from_file_location(
    "capture_tvos_preview", Path(__file__).resolve().parents[1] / "capture-tvos-preview.py"
)
CAPTURE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(CAPTURE)


class SimulatorSelectionTests(unittest.TestCase):
    def catalog(self):
        return {
            "runtimes": [
                {"identifier": "runtime.tvOS-26-4", "name": "tvOS 26.4", "version": "26.4", "isAvailable": True},
                {"identifier": "runtime.tvOS-26-5", "name": "tvOS 26.5", "version": "26.5", "isAvailable": True},
                {"identifier": "runtime.iOS-27-0", "name": "iOS 27.0", "version": "27.0", "isAvailable": True},
            ],
            "devicetypes": [
                {"identifier": "type.hd", "name": "Apple TV"},
                {"identifier": "type.1080", "name": "Apple TV 4K (3rd generation) (at 1080p)"},
                {"identifier": "type.4k", "name": "Apple TV 4K (3rd generation)"},
                {"identifier": "type.phone", "name": "iPhone 17"},
            ],
            "devices": {
                "runtime.tvOS-26-4": [{"deviceTypeIdentifier": "type.hd", "isAvailable": True}],
                "runtime.tvOS-26-5": [
                    {"deviceTypeIdentifier": "type.4k", "isAvailable": True},
                    {"deviceTypeIdentifier": "type.1080", "isAvailable": True},
                    {"deviceTypeIdentifier": "type.hd", "isAvailable": True},
                ],
                "runtime.iOS-27-0": [{"deviceTypeIdentifier": "type.phone", "isAvailable": True}],
            },
        }

    def test_prefers_matching_sdk_and_hd_over_newer_ios_or_4k(self):
        result = CAPTURE.select_simulator(self.catalog(), "26.5")
        self.assertEqual(result["runtime"], "runtime.tvOS-26-5")
        self.assertEqual(result["device_type"], "type.hd")
        result = CAPTURE.select_simulator(self.catalog(), "26.4")
        self.assertEqual(result["runtime"], "runtime.tvOS-26-4")

    def test_uses_1080p_fallback_without_hd_and_never_unavailable_runtime(self):
        catalog = self.catalog()
        catalog["devices"]["runtime.tvOS-26-5"][-1]["isAvailable"] = False
        result = CAPTURE.select_simulator(catalog, "26.5")
        self.assertEqual(result["device_type"], "type.1080")
        catalog["runtimes"][1]["isAvailable"] = False
        result = CAPTURE.select_simulator(catalog, "26.5")
        self.assertEqual(result["runtime"], "runtime.tvOS-26-4")

    def test_supported_type_metadata_can_create_device_without_existing_instance(self):
        catalog = self.catalog()
        catalog["devices"] = {}
        catalog["runtimes"][1]["supportedDeviceTypes"] = [{"identifier": "type.1080"}]
        result = CAPTURE.select_simulator(catalog, "26.5")
        self.assertEqual(result["device_type"], "type.1080")

    def test_no_available_tvos_or_discovered_compatible_type_is_an_error(self):
        catalog = self.catalog()
        catalog["runtimes"] = catalog["runtimes"][2:]
        with self.assertRaises(ValueError):
            CAPTURE.select_simulator(catalog, "26.5")
        catalog = self.catalog()
        catalog["devices"] = {}
        with self.assertRaises(ValueError):
            CAPTURE.select_simulator(catalog, "26.5")

    def test_native_summary_cannot_accept_old_subset_or_skipped_new_tests(self):
        summary = {"result": "Passed", "totalTestCount": 29, "passedTests": 29,
                   "failedTests": 0, "skippedTests": 0, "expectedFailures": 0}
        CAPTURE.validate_ui_summary(summary)
        for change in [{"totalTestCount": 20, "passedTests": 20},
                       {"totalTestCount": 28, "passedTests": 28},
                       {"passedTests": 28, "skippedTests": 1},
                       {"expectedFailures": 1}, {"result": "Failed"}]:
            with self.subTest(change=change), self.assertRaises(ValueError):
                CAPTURE.validate_ui_summary({**summary, **change})

    def test_capture_contract_matches_registered_ui_source(self):
        source = Path(__file__).resolve().parents[2] / "UITests/AsanUITests.swift"
        methods = re.findall(r"\bfunc\s+(test\w+)\s*\(", source.read_text(encoding="utf-8"))
        self.assertEqual(len(methods), len(set(methods)), "Duplicate test names")
        self.assertEqual(len(methods), CAPTURE.EXPECTED_UI_TEST_COUNT)
        self.assertEqual(CAPTURE.EXPECTED_MINIMUM_SCREENSHOTS, 50)
        self.assertEqual(CAPTURE.UI_CAPTURE_TIMEOUT_SECONDS, 2400)
        text = source.read_text(encoding="utf-8")
        self.assertIn(f'captureReady("{CAPTURE.INTRO_PROOF_LABEL}")', text)
        self.assertNotIn('frame.name = "intro-native-frame"', text)
        self.assertEqual(len(CAPTURE.PREFLIGHT_METHODS), 8)
        self.assertTrue(set(CAPTURE.PREFLIGHT_METHODS).issubset(methods))

    def test_preflight_subset_cannot_replace_the_complete_native_gate(self):
        summary = {"result": "Passed", "totalTestCount": 8, "passedTests": 8,
                   "failedTests": 0, "skippedTests": 0, "expectedFailures": 0}
        CAPTURE.validate_ui_summary(summary, expected_count=8)
        with self.assertRaises(ValueError):
            CAPTURE.validate_ui_summary(summary)
        with self.assertRaises(ValueError):
            CAPTURE.validate_ui_summary({**summary, "totalTestCount": 0, "passedTests": 0}, expected_count=8)
        full = CAPTURE.ui_test_command("owned", "x86_64", Path("derived"), Path("full.xcresult"))
        preflight = CAPTURE.ui_test_command("owned", "x86_64", Path("derived"), Path("probe.xcresult"),
                                            CAPTURE.PREFLIGHT_METHODS)
        self.assertFalse(any(argument.startswith("-only-testing:") for argument in full))
        self.assertEqual(sum(argument.startswith("-only-testing:") for argument in preflight), 8)

    def test_isolated_suite_contains_all_unique_methods_with_regressions_first(self):
        methods = CAPTURE.complete_ui_methods()
        self.assertEqual(len(methods), 29)
        self.assertEqual(len(set(methods)), 29)
        self.assertEqual(methods[:8], CAPTURE.PREFLIGHT_METHODS)

    def test_native_test_tree_rejects_duplicate_wrong_or_failed_methods(self):
        def tree(cases):
            return {"testNodes": [{"nodeType": "Test Suite", "children": cases}]}

        first = {"nodeType": "Test Case", "nodeIdentifier": "AsanUITests/testFirst()", "result": "Passed"}
        second = {"nodeType": "Test Case", "nodeIdentifier": "AsanUITests/testSecond()", "result": "Passed"}
        CAPTURE.validate_native_test_tree(tree([first, second]), ("testFirst", "testSecond"))
        for cases in ([first, first], [first], [first, {**second, "result": "Skipped"}],
                      [first, {**second, "result": "Failed"}],
                      [first, {**second, "nodeIdentifier": "AsanUITests/testWrong()"}]):
            with self.subTest(cases=cases), self.assertRaises(ValueError):
                CAPTURE.validate_native_test_tree(tree(cases), ("testFirst", "testSecond"))


class InterruptedCaptureTests(unittest.TestCase):
    def test_isolated_failure_is_exported_and_never_retried_or_merged(self):
        failed = {"result": "Failed", "totalTestCount": 1, "passedTests": 0,
                  "failedTests": 1, "skippedTests": 0, "expectedFailures": 0}
        with (tempfile.TemporaryDirectory() as directory,
              patch.object(CAPTURE, "complete_ui_methods", return_value=("testFirst", "testSecond")),
              patch.object(CAPTURE, "run", return_value=subprocess.CompletedProcess([], 0, "merge help")) as command,
              patch.object(CAPTURE, "run_recorded_ui", return_value=subprocess.CompletedProcess([], 65)) as runner,
              patch.object(CAPTURE, "export_ui_results", return_value=failed) as exporter,
              self.assertRaises(RuntimeError)):
            CAPTURE.run_isolated_suite("owned", "x86_64", Path("derived"), Path(directory), Path("merged.xcresult"))
        self.assertEqual(runner.call_count, 1)
        self.assertEqual(exporter.call_count, 1)
        self.assertEqual(command.call_count, 1, "Only merge help can run before a failed test")

    def test_regression_preflight_stops_after_first_failure_and_exports_each_attempt(self):
        one = {"result": "Passed", "totalTestCount": 1, "passedTests": 1,
               "failedTests": 0, "skippedTests": 0, "expectedFailures": 0}
        failed = {**one, "result": "Failed", "passedTests": 0, "failedTests": 1}
        with (tempfile.TemporaryDirectory() as directory,
              patch.object(CAPTURE, "run_recorded_ui", side_effect=[subprocess.CompletedProcess([], 0),
                           subprocess.CompletedProcess([], 65)]) as runner,
              patch.object(CAPTURE, "export_ui_results", side_effect=[one, failed]) as exporter,
              self.assertRaises(RuntimeError)):
            CAPTURE.run_preflight("owned", "x86_64", Path("derived"), Path(directory))
        self.assertEqual(runner.call_count, 2)
        self.assertEqual(exporter.call_count, 2)
        for invocation in runner.call_args_list:
            self.assertEqual(sum(value.startswith("-only-testing:") for value in invocation.args[0]), 1)

    @staticmethod
    def immediate_timer(_interval, callback):
        timer = MagicMock()
        timer.start.side_effect = callback
        return timer

    def test_timeout_interrupts_for_finalization_but_cannot_report_zero_exit_as_success(self):
        process = MagicMock()
        process.stdout = []
        process.poll.side_effect = [None, 0]
        process.wait.return_value = 0
        with (tempfile.TemporaryDirectory() as directory,
              patch.object(CAPTURE.subprocess, "Popen", return_value=process),
              patch.object(CAPTURE.threading, "Timer", side_effect=self.immediate_timer),
              self.assertRaises(subprocess.TimeoutExpired)):
            CAPTURE.run_recorded_ui(["xcodebuild", "test"], "owned-device", Path(directory), timeout=2400)
        process.send_signal.assert_called_once_with(signal.SIGINT)
        process.wait.assert_any_call(timeout=30)
        process.kill.assert_not_called()

    def test_unresponsive_interrupted_process_is_killed_after_bounded_grace(self):
        process = MagicMock()
        process.stdout = []
        process.poll.return_value = None
        process.wait.side_effect = [subprocess.TimeoutExpired(["xcodebuild"], 30), -9]
        process.kill.side_effect = lambda: setattr(process.poll, "return_value", -9)
        with (tempfile.TemporaryDirectory() as directory,
              patch.object(CAPTURE.subprocess, "Popen", return_value=process),
              patch.object(CAPTURE.threading, "Timer", side_effect=self.immediate_timer),
              self.assertRaises(subprocess.TimeoutExpired)):
            CAPTURE.run_recorded_ui(["xcodebuild", "test"], "owned-device", Path(directory), timeout=2400)
        process.send_signal.assert_called_once_with(signal.SIGINT)
        process.wait.assert_any_call(timeout=30)
        process.kill.assert_called_once()

    def test_attachment_export_timeout_still_preserves_native_failure_summary(self):
        responses = [subprocess.CompletedProcess([], 0, "help"),
                     subprocess.TimeoutExpired(["xcresulttool", "export"], 60),
                     subprocess.CompletedProcess([], 0, '{"result":"Failed","failedTests":1}')]
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory)
            bundle = output / "Asan-UI.xcresult"
            bundle.mkdir()
            with patch.object(CAPTURE, "run", side_effect=responses) as run:
                summary = CAPTURE.export_ui_results(output, bundle)
            self.assertEqual(summary["result"], "Failed")
            self.assertTrue((output / "xcresult-export-errors.json").is_file())
            self.assertIn('"Failed"', (output / "ui-test-summary.json").read_text(encoding="utf-8"))
            self.assertIn("summary", run.call_args.args[0])
            with self.assertRaises(ValueError):
                CAPTURE.validate_ui_summary(summary)


if __name__ == "__main__":
    unittest.main()
