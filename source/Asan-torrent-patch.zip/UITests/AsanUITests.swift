import XCTest

final class AsanUITests: XCTestCase {
    private var app: XCUIApplication!
    private let remote = XCUIRemote.shared
    private var capturedFailureState = false

    override func setUp() {
        super.setUp()
        continueAfterFailure = false
        app = XCUIApplication()
        capturedFailureState = false
    }

    private func launch(_ scene: String, reducedEffects: Bool = false) {
        app.launchArguments = ["--screenshot-scene", scene, "-AppleLanguages", "(ru)", "-AppleLocale", "ru_RU"]
        if ["local-details", "local-vlc-details", "recovery", "intro-settings", "catalog", "search"].contains(scene) {
            app.launchArguments.append("--qa-observe-native-focus")
        }
        if reducedEffects { app.launchArguments.append("--qa-reduce-effects") }
        app.launch()
        app.activate()
        XCTAssertTrue(app.wait(for: .runningForeground, timeout: 15))
        if ["catalog", "stress", "guest", "settings", "restoring", "downloads", "torrent-list"].contains(scene) { remote.press(.right) }
    }

    private var cards: XCUIElementQuery {
        app.descendants(matching: .button).matching(NSPredicate(format: "identifier BEGINSWITH %@", "media-card-"))
    }

    private func screenshot(_ name: String) {
        XCTAssertEqual(app.state, .runningForeground, "Refusing to capture SpringBoard as an app screen")
        // Element existence does not mean the tvOS focus/sidebar/sheet animation
        // has finished drawing. Capturing mid-transition hides native labels.
        Thread.sleep(forTimeInterval: 2.5)
        let attachment = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
        let tree = XCTAttachment(string: app.debugDescription)
        tree.name = name + "-accessibility"
        tree.lifetime = .keepAlways
        add(tree)
    }

    private func focusCard() -> XCUIElement? {
        for _ in 0..<3 { remote.press(.right) }
        for _ in 0..<10 {
            if let focused = cards.allElementsBoundByIndex.first(where: { $0.hasFocus }) {
                if app.launchArguments.contains("--qa-observe-native-focus") {
                    let agreement = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in
                        self.observedCatalogFocus()?.cardID == focused.identifier
                    }, object: nil)
                    guard XCTWaiter.wait(for: [agreement], timeout: 5) == .completed,
                          let observed = observedCatalogFocus(), catalogFocusAgreesWithAX(observed) else {
                        captureFailureState("The native focus observer did not agree with the actual AX poster")
                        XCTFail("Actual native focus and exposed AX focus must agree")
                        return nil
                    }
                }
                return focused
            }
            remote.press(.down)
        }
        return nil
    }

    func testCardShowsExactlyOneGenreAndRealRatingWithNativeSidebar() {
        launch("catalog")
        let first = app.buttons["media-card-/series/drama/900001-severnaya-liniya.html"]
        XCTAssertTrue(first.waitForExistence(timeout: 30))
        XCTAssertTrue(first.label.contains("Детектив"), first.label)
        XCTAssertTrue(first.label.contains("8.4") || first.label.contains("8,4"), first.label)
        XCTAssertFalse(first.label.contains("Приключения"), "All genres leaked into a poster card")
        // The system sidebar opens with Back/Menu; repeated left presses can
        // remain on the catalog's first control without ever opening it.
        remote.press(.menu)
        let searchTab = app.buttons["Поиск"]
        let expanded = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in
            searchTab.isEnabled && searchTab.isHittable
        }, object: nil)
        XCTAssertEqual(XCTWaiter.wait(for: [expanded], timeout: 10), .completed)
        screenshot("sidebar-expanded")
        remote.press(.right)
        let collapsed = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in
            !searchTab.isEnabled
        }, object: nil)
        XCTAssertEqual(XCTWaiter.wait(for: [collapsed], timeout: 10), .completed)
        screenshot("sidebar-collapsed")
        XCTAssertEqual(app.state, .runningForeground)
    }

    func testNativeFocusOpenDetailAndMenuBack() {
        launch("catalog")
        XCTAssertTrue(cards.firstMatch.waitForExistence(timeout: 30))
        XCTAssertNotNil(focusCard(), "Remote cannot focus any catalog card")
        screenshot("catalog-focused")
        remote.press(.select)
        XCTAssertTrue(app.buttons["Смотреть"].waitForExistence(timeout: 20))
        screenshot("detail")
        remote.press(.menu)
        XCTAssertTrue(cards.firstMatch.waitForExistence(timeout: 20))
        screenshot("catalog-after-back")
    }

    func testMenuExitsEmbeddedPlayer() {
        launch("player")
        let player = app.descendants(matching: .any).matching(identifier: "playback-screen").firstMatch
        XCTAssertTrue(player.waitForExistence(timeout: 30))
        remote.press(.menu)
        XCTAssertTrue(cards.firstMatch.waitForExistence(timeout: 20))
        XCTAssertFalse(player.exists, "Back did not dismiss the actual playback cover")
        screenshot("player-back-to-catalog")
    }

    func testCachedCatalogVisibleWhileAccountIsBeingChecked() {
        launch("restoring")
        let first = app.buttons["media-card-/series/drama/900001-severnaya-liniya.html"]
        XCTAssertTrue(first.waitForExistence(timeout: 30), "Cached posters must not wait behind account network validation")
        XCTAssertFalse(first.isEnabled, "Playback stays gated until the session is validated")
        screenshot("cached-catalog-restoring")
    }

    func testScrollRoundTripsWith240CardsAndMissingMetadata() {
        launch("stress")
        XCTAssertTrue(cards.firstMatch.waitForExistence(timeout: 30))
        XCTAssertNotNil(focusCard())
        let start = Date()
        for _ in 0..<2 {
            for _ in 0..<8 { remote.press(.down) }
            screenshot("stress-lower-cards")
            for _ in 0..<8 { remote.press(.up) }
        }
        let timing = XCTAttachment(string: "32 remote scroll commands, 240 offline cards: \(Date().timeIntervalSince(start)) seconds. Simulator wall time, not device FPS.")
        timing.name = "scroll-timing"
        timing.lifetime = .keepAlways
        add(timing)
        XCTAssertEqual(app.state, .runningForeground)
        screenshot("stress-after-roundtrip")
    }

    func testVoiceAndQualityScreensRemainReachable() {
        launch("voices")
        XCTAssertTrue(app.buttons.matching(NSPredicate(format: "label CONTAINS %@", "Профессиональная многоголосая")).firstMatch.waitForExistence(timeout: 30))
        screenshot("voices")
        app.terminate()
        launch("qualities")
        XCTAssertTrue(app.buttons.matching(NSPredicate(format: "label CONTAINS %@", "1080")).firstMatch.waitForExistence(timeout: 30))
        assertUniqueQualities()
        screenshot("qualities")
    }

    private func assertUniqueQualities() {
        let rows = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "quality-option-"))
        XCTAssertTrue(rows.firstMatch.waitForExistence(timeout: 20))
        XCTAssertEqual(rows.count, 4, "Eight stream aliases must become exactly four quality choices")
        for height in [1080, 720, 480, 360] {
            XCTAssertEqual(rows.matching(NSPredicate(format: "label CONTAINS %@", "\(height)p")).count, 1)
        }
    }

    private func choiceRowHasFocus() -> Bool {
        let predicate = NSPredicate(format: "identifier BEGINSWITH %@", "choice-row-")
        if app.buttons.matching(predicate).allElementsBoundByIndex.contains(where: { $0.hasFocus }) { return true }
        // In a native tvOS List the Cell owns focus, while its Button is the
        // accessible action. The captured failure hierarchy confirms this.
        return app.cells.allElementsBoundByIndex.contains { cell in
            cell.hasFocus && cell.descendants(matching: .button).matching(predicate).count > 0
        }
    }

    func testPlayerQualitySheetAlsoGroupsAliases() {
        launch("player-qualities")
        assertUniqueQualities()
        screenshot("player-qualities-no-duplicates")
        remote.press(.menu)
        let player = app.descendants(matching: .any).matching(identifier: "playback-screen").firstMatch
        XCTAssertTrue(player.waitForExistence(timeout: 10))
        remote.press(.menu)
        XCTAssertTrue(cards.firstMatch.waitForExistence(timeout: 20))
    }

    func testReducedEffectsStillShowsReadableUniqueQualities() {
        launch("qualities", reducedEffects: true)
        assertUniqueQualities()
        screenshot("qualities-reduced-effects")
    }

    func testScrollCollectsApplicationCPUAndMemoryMetrics() {
        launch("stress")
        XCTAssertTrue(cards.firstMatch.waitForExistence(timeout: 30))
        XCTAssertNotNil(focusCard())
        let options = XCTMeasureOptions()
        options.iterationCount = 1
        measure(metrics: [XCTClockMetric(), XCTCPUMetric(application: app), XCTMemoryMetric(application: app)], options: options) {
            for _ in 0..<8 { remote.press(.down) }
            for _ in 0..<8 { remote.press(.up) }
        }
        XCTAssertEqual(app.state, .runningForeground)
    }

    /// This tour is recorded by simctl, in addition to still XCTest attachments.
    func testAMotionTour() {
        launch("catalog")
        XCTAssertTrue(cards.firstMatch.waitForExistence(timeout: 30))
        remote.press(.menu)
        let search = app.buttons["Поиск"]
        let expanded = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in search.isEnabled && search.isHittable }, object: nil)
        XCTAssertEqual(XCTWaiter.wait(for: [expanded], timeout: 10), .completed)
        Thread.sleep(forTimeInterval: 0.6)
        remote.press(.right)
        XCTAssertNotNil(focusCard())
        remote.press(.select)
        XCTAssertTrue(app.buttons["Смотреть"].waitForExistence(timeout: 20))
        Thread.sleep(forTimeInterval: 0.6)
        let watch = app.buttons["Смотреть"]
        let focused = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in watch.hasFocus }, object: nil)
        XCTAssertEqual(XCTWaiter.wait(for: [focused], timeout: 10), .completed)
        remote.press(.select)
        XCTAssertTrue(app.buttons.matching(NSPredicate(format: "label CONTAINS %@", "Профессиональная многоголосая")).firstMatch.waitForExistence(timeout: 20))
        Thread.sleep(forTimeInterval: 0.6)
        for _ in 0..<3 {
            if app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "quality-option-")).firstMatch.waitForExistence(timeout: 3) { break }
            let row = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "choice-row-")).firstMatch
            XCTAssertTrue(row.waitForExistence(timeout: 20))
            for _ in 0..<8 { if choiceRowHasFocus() { break }; remote.press(.down) }
            if !choiceRowHasFocus() {
                let tree = XCTAttachment(string: app.debugDescription)
                tree.name = "motion-choice-focus-failure"
                tree.lifetime = .keepAlways
                add(tree)
            }
            XCTAssertTrue(choiceRowHasFocus())
            remote.press(.select)
        }
        assertUniqueQualities()
        Thread.sleep(forTimeInterval: 0.6)
        for _ in 0..<4 {
            if app.buttons["Смотреть"].exists && app.buttons["Смотреть"].isHittable { break }
            remote.press(.menu)
        }
        XCTAssertTrue(app.buttons["Смотреть"].waitForExistence(timeout: 10))
        remote.press(.menu)
        XCTAssertTrue(cards.firstMatch.waitForExistence(timeout: 15))
        screenshot("motion-tour-finished")
    }

    func testGuestSettingsAndLoginScreens() {
        launch("guest")
        XCTAssertTrue(app.staticTexts["Войти в Rezka"].waitForExistence(timeout: 20))
        screenshot("guest")
        app.terminate()
        launch("settings")
        XCTAssertTrue(app.buttons["Войти в Rezka"].waitForExistence(timeout: 20))
        screenshot("settings")
        app.terminate()
        launch("login")
        XCTAssertTrue(app.secureTextFields.firstMatch.waitForExistence(timeout: 20))
        screenshot("login")
    }

    private var torrentRows: XCUIElementQuery {
        app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "torrent-download-"))
    }

    private var searchResults: XCUIElementQuery {
        app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "torrent-search-result-"))
    }

    func testTorrentButtonSearchFileSelectionAndBack() {
        launch("details")
        let torrent = app.buttons["details-torrent"]
        XCTAssertTrue(torrent.waitForExistence(timeout: 20))
        for _ in 0..<4 { if torrent.hasFocus { break }; remote.press(.right) }
        XCTAssertTrue(torrent.hasFocus, "Torrent must be reachable beside Watch with the remote")
        screenshot("detail-torrent-button")
        remote.press(.select)
        XCTAssertTrue(searchResults.firstMatch.waitForExistence(timeout: 20))
        XCTAssertEqual(searchResults.count, 2)
        XCTAssertTrue(searchResults.firstMatch.label.contains("Northern Line"), searchResults.firstMatch.label)
        XCTAssertTrue(searchResults.firstMatch.label.contains("1080p"), searchResults.firstMatch.label)
        screenshot("film-torrent-results")
        XCTAssertTrue(focusTorrentButton(searchResults.firstMatch))
        remote.press(.select)
        let file = app.buttons["torrent-file-0"]
        XCTAssertTrue(file.waitForExistence(timeout: 20), "Selected release must enter the existing metadata/file chooser")
        XCTAssertFalse(app.buttons["torrent-file-1"].isEnabled, "Non-video file must remain unavailable")
        screenshot("film-torrent-files")
        remote.press(.menu)
        XCTAssertTrue(searchResults.firstMatch.waitForExistence(timeout: 15))
        XCTAssertEqual(searchResults.count, 2)
        // Re-enter after cancellation to catch stale preparation handles and
        // orphaned sheets. This fixture queues no payload and uses no network.
        let first = searchResults.firstMatch
        let ready = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in first.isEnabled }, object: nil)
        XCTAssertEqual(XCTWaiter.wait(for: [ready], timeout: 15), .completed)
        XCTAssertTrue(focusTorrentButton(first))
        remote.press(.select)
        XCTAssertTrue(file.waitForExistence(timeout: 15))
        XCTAssertTrue(focusTorrentButton(file))
        remote.press(.select)
        XCTAssertEqual(file.value as? String, "Выбрано")
        let confirmQueue = app.buttons["torrent-queue-confirm"]
        XCTAssertTrue(focusToward(confirmQueue), "Series selection needs an explicit queue confirmation")
        remote.press(.select)
        XCTAssertTrue(torrent.waitForExistence(timeout: 15))
        XCTAssertFalse(searchResults.firstMatch.exists, "Choosing a file must close the whole search flow")
        screenshot("film-torrent-queued-back-to-detail")
    }

    func testTorrentSearchEmptyAndErrorRetryAndExit() {
        for scene in ["torrent-search-empty", "torrent-search-error"] {
            launch(scene)
            let state = app.staticTexts[scene == "torrent-search-empty" ? "torrent-search-empty" : "torrent-search-error"]
            XCTAssertTrue(state.waitForExistence(timeout: 20))
            XCTAssertEqual(searchResults.count, 0)
            screenshot(scene)
            let retry = app.buttons["torrent-search-retry"]
            XCTAssertTrue(focusTorrentButton(retry))
            remote.press(.select)
            XCTAssertTrue(searchResults.firstMatch.waitForExistence(timeout: 15), "Retry must recover to actual results")
            XCTAssertEqual(searchResults.count, 2)
            XCTAssertFalse(state.exists)
            remote.press(.menu)
            XCTAssertTrue(app.buttons["details-torrent"].waitForExistence(timeout: 15))
            app.terminate()
        }
    }

    func testBIntroPlaysAndEnds() {
        launch("intro")
        let intro = app.descendants(matching: .any).matching(identifier: "asan-intro-overlay").firstMatch
        let proof = app.descendants(matching: .any).matching(identifier: "asan-intro-playback-proof").firstMatch
        // Automation startup can outlive the unmodified 4.8-second movie.
        // Observe durable actual callbacks, not a disappearing Skip control.
        waitUntil("Require a real first frame, playing clock and exact-item natural end", timeout: 20) {
            guard proof.exists, let value = proof.value as? String else { return false }
            return Set(value.split(separator: ";").map(String.init))
                .isSuperset(of: ["starts=1", "frame=1", "playing=1", "naturalEnd=1"])
        }
        XCTAssertTrue(cards.firstMatch.waitForExistence(timeout: 15), "The actual local movie must end without a remote command")
        XCTAssertFalse(intro.exists)
        guard proof.exists, let initialEvidence = proof.value as? String else { return XCTFail("Playback evidence disappeared") }
        captureReady("intro-playback-proof")
        // The recording intentionally includes this warm background round trip
        // after the actual intro has naturally reached the catalogue.
        remote.press(.home)
        waitUntil("Home must background the existing process") {
            self.app.state == .runningBackground || self.app.state == .runningBackgroundSuspended
        }
        app.activate()
        XCTAssertTrue(app.wait(for: .runningForeground, timeout: 15))
        waitUntil("Warm activation must retain the same process-local playback evidence") {
            guard proof.exists, let value = proof.value as? String else { return false }
            return value == initialEvidence
        }
        XCTAssertFalse(intro.exists, "Foreground activation must not replay the cold-launch intro")
        screenshot("intro-ended-catalog")
    }

    func testCIntroMenuSkipsToCatalog() {
        launch("intro")
        let intro = app.descendants(matching: .any).matching(identifier: "asan-intro-overlay").firstMatch
        XCTAssertTrue(intro.waitForExistence(timeout: 3))
        remote.press(.menu)
        XCTAssertTrue(cards.firstMatch.waitForExistence(timeout: 10))
        XCTAssertFalse(intro.exists, "Back must skip, not exit the app")
        screenshot("intro-skipped-catalog")
    }

    func testDReducedMotionIntroDoesNotDelayCatalogue() {
        launch("intro", reducedEffects: true)
        XCTAssertTrue(cards.firstMatch.waitForExistence(timeout: 10))
        XCTAssertFalse(app.descendants(matching: .any).matching(identifier: "asan-intro-overlay").firstMatch.exists)
        screenshot("intro-reduced-motion-catalog")
    }

    /// Native Form/List cells can own focus instead of their accessible Button.
    private func focusTorrentButton(_ button: XCUIElement, attempts: Int = 12) -> Bool {
        for _ in 0..<attempts {
            if button.hasFocus { return true }
            let identifier = button.identifier
            if app.cells.allElementsBoundByIndex.contains(where: { cell in
                cell.hasFocus && cell.descendants(matching: .button).matching(identifier: identifier).count > 0
            }) { return true }
            remote.press(.down)
        }
        return false
    }

    func testDownloadsEmptyStateAddInputAndRemoteBack() {
        launch("downloads")
        let add = app.buttons["torrent-add"]
        XCTAssertTrue(add.waitForExistence(timeout: 30))
        XCTAssertTrue(app.descendants(matching: .any).matching(identifier: "torrent-empty").firstMatch.exists)
        let freeSpace = app.staticTexts["torrent-free-space"]
        XCTAssertTrue(freeSpace.exists)
        XCTAssertTrue(freeSpace.label.contains("Свободно"), freeSpace.label)
        XCTAssertEqual(torrentRows.count, 0, "The empty scene must not show old or invented downloads")
        screenshot("torrent-downloads-empty")

        XCTAssertTrue(focusTorrentButton(add), "Remote cannot focus Add Torrent")
        remote.press(.select)
        let field = app.textFields["torrent-magnet"]
        XCTAssertTrue(field.waitForExistence(timeout: 20))
        XCTAssertTrue(app.buttons["torrent-submit"].exists)
        XCTAssertFalse(app.buttons["torrent-submit"].isEnabled, "An empty link must not start a download")
        screenshot("torrent-add-input")
        remote.press(.menu)
        let dismissed = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in
            !field.exists && add.isHittable
        }, object: nil)
        XCTAssertEqual(XCTWaiter.wait(for: [dismissed], timeout: 15), .completed)
        XCTAssertEqual(app.state, .runningForeground)
    }

    func testDownloadRowsDeleteConfirmationAndRemoteBackPreserveFiles() {
        launch("torrent-list")
        XCTAssertTrue(torrentRows.firstMatch.waitForExistence(timeout: 30))
        let count = torrentRows.count
        XCTAssertGreaterThanOrEqual(count, 2)
        XCTAssertTrue(torrentRows.matching(NSPredicate(format: "label CONTAINS %@", "Приостановлено")).firstMatch.exists)
        let completed = torrentRows.matching(NSPredicate(format: "label CONTAINS %@", "Готово к просмотру")).firstMatch
        XCTAssertTrue(completed.exists, "The fixture must include an unexpired completed download")
        screenshot("torrent-downloads-list")
        XCTAssertTrue(focusTorrentButton(completed), "Remote cannot focus a completed download")
        remote.press(.select)

        let remove = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "torrent-delete-")).firstMatch
        XCTAssertTrue(remove.waitForExistence(timeout: 20))
        XCTAssertTrue(app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "torrent-play-")).firstMatch.exists)
        XCTAssertTrue(focusTorrentButton(remove), "Remote cannot reach the Delete action")
        remote.press(.select)
        let confirm = app.buttons["Удалить"]
        XCTAssertTrue(confirm.waitForExistence(timeout: 10))
        screenshot("torrent-delete-confirmation")
        remote.press(.menu)
        let cancelled = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in
            !confirm.exists && remove.isHittable
        }, object: nil)
        XCTAssertEqual(XCTWaiter.wait(for: [cancelled], timeout: 15), .completed)
        remote.press(.menu)
        XCTAssertTrue(torrentRows.firstMatch.waitForExistence(timeout: 15))
        XCTAssertEqual(torrentRows.count, count, "Back must cancel deletion and preserve every download")
        XCTAssertTrue(torrentRows.matching(NSPredicate(format: "label CONTAINS %@", "Приостановлено")).firstMatch.exists)
        XCTAssertTrue(torrentRows.matching(NSPredicate(format: "label CONTAINS %@", "Готово к просмотру")).firstMatch.exists)
        screenshot("torrent-downloads-after-back")
    }

    private func waitUntil(_ message: String, timeout: TimeInterval = 15, _ condition: @escaping () -> Bool) {
        let expectation = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in condition() }, object: nil)
        let result = XCTWaiter.wait(for: [expectation], timeout: timeout)
        if result != .completed { captureFailureState(message) }
        XCTAssertEqual(result, .completed, message)
    }

    private func captureFailureState(_ message: String) {
        guard !capturedFailureState else { return }
        capturedFailureState = true
        let screen = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        screen.name = "failure-state"; screen.lifetime = .keepAlways; add(screen)
        let tree = XCTAttachment(string: "Failed route: \(message)\nApplication state: \(app.state.rawValue)\n\(app.debugDescription)")
        tree.name = "failure-state-accessibility"; tree.lifetime = .keepAlways; add(tree)
    }

    private func hasRemoteFocus(_ button: XCUIElement) -> Bool {
        let focused = NSPredicate(format: "hasFocus == true")
        if button.hasFocus || button.descendants(matching: .any).matching(focused).firstMatch.exists { return true }
        guard button.elementType == .button else { return false }
        let identifier = button.identifier
        let match = identifier.isEmpty ? NSPredicate(format: "label == %@", button.label)
            : NSPredicate(format: "identifier == %@", identifier)
        let cell = app.cells.matching(focused).firstMatch
        return cell.exists && cell.descendants(matching: .button).matching(match).firstMatch.exists
    }

    /// Navigate the actual native focus graph using observed frames. In a tvOS
    /// List the accessible Button and focused Cell may be different elements.
    private func focusToward(_ target: XCUIElement, attempts: Int = 18) -> Bool {
        guard target.exists || target.waitForExistence(timeout: 15) else {
            captureFailureState("The native focus target did not appear")
            return false
        }
        let identifier = target.identifier
        let targetLabel = target.label
        let targetMatch = identifier.isEmpty
            ? NSPredicate(format: "label == %@", targetLabel)
            : NSPredicate(format: "identifier == %@", identifier)
        // Prefer actionable focus owners to broad focused containers. The
        // recorded failed run reported the entire Keyboard as the first Any
        // match, so its centre could not describe an active key or tab item.
        let focusPredicate = NSPredicate(format: "hasFocus == true")
        let focusedQueries = [app.buttons.matching(focusPredicate), app.cells.matching(focusPredicate),
                              app.keys.matching(focusPredicate),
                              app.descendants(matching: .any).matching(focusPredicate)]
        for step in 0...max(0, attempts) {
            guard target.exists else {
                captureFailureState("Native focus target disappeared: \(identifier) \(targetLabel)")
                return false
            }
            if target.hasFocus || target.descendants(matching: .any)
                .matching(NSPredicate(format: "hasFocus == true")).firstMatch.exists { return true }
            let focused = focusedQueries.lazy.map(\.firstMatch).first(where: \.exists)
            if let focused, focused.elementType == .cell,
               focused.descendants(matching: .button).matching(targetMatch).firstMatch.exists { return true }
            guard step < attempts else {
                captureFailureState("Native focus did not reach \(identifier) \(targetLabel) after \(attempts) moves")
                return false
            }
            guard let focused else { remote.press(.down); continue }
            let targetFrame = target.frame, focusedFrame = focused.frame
            guard !targetFrame.isEmpty, !focusedFrame.isEmpty else { remote.press(.down); continue }
            let dx = targetFrame.midX - focusedFrame.midX
            let dy = targetFrame.midY - focusedFrame.midY
            // Focus scaling changes button bounds, not the row's centre. A
            // height-based 60% tolerance treated the adjacent Details row as
            // horizontal and oscillated Left/Right in the actual Simulator log.
            let rowTolerance = max(8, min(16, min(targetFrame.height, focusedFrame.height) * 0.2))
            if abs(dy) > rowTolerance {
                remote.press(dy > 0 ? .down : .up)
            } else if abs(dx) > 8 {
                remote.press(dx > 0 ? .right : .left)
            } else { remote.press(.down) }
        }
        captureFailureState("Native focus traversal ended without its target")
        return false
    }

    /// New scenarios capture only after explicit state/focus/position predicates.
    private func captureReady(_ name: String) {
        XCTAssertEqual(app.state, .runningForeground)
        let attachment = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        attachment.name = name; attachment.lifetime = .keepAlways; add(attachment)
        let tree = XCTAttachment(string: app.debugDescription)
        tree.name = name + "-accessibility"; tree.lifetime = .keepAlways; add(tree)
    }

    private func actualLocalPosition() -> Double? {
        let metric = app.staticTexts["torrent-local-position"]
        guard metric.exists else { return nil }
        return Double(((metric.value as? String) ?? metric.label).replacingOccurrences(of: ",", with: "."))
    }

    private func waitForLocalPlayback(vlc: Bool, minimum: Double, maximum: Double) {
        let player = app.descendants(matching: .any).matching(identifier: "torrent-local-player").firstMatch
        XCTAssertTrue(player.waitForExistence(timeout: 20))
        waitUntil("A real local player must be playing", timeout: 20) {
            vlc ? self.app.descendants(matching: .any).matching(identifier: "torrent-vlc-state").firstMatch.label == "Воспроизводится"
                : player.value as? String == "Воспроизводится"
        }
        // A real Pause keeps the short generated clip from naturally completing
        // while XCTest reads its clock, duration and screenshot accessibility.
        remote.press(.playPause)
        waitUntil("The real remote Pause must stop playback before inspecting its clock", timeout: 15) {
            vlc ? self.app.descendants(matching: .any).matching(identifier: "torrent-vlc-state").firstMatch.label == "Приостановлено"
                : player.value as? String == "Пауза"
        }
        let first = app.staticTexts["torrent-local-start-position"]
        waitUntil("Observe the first native Playing clock, not the requested seek target", timeout: 15) {
            guard first.exists,
                  let position = Double(((first.value as? String) ?? first.label).replacingOccurrences(of: ",", with: ".")) else { return false }
            return position >= minimum && position < maximum
        }
        let duration = app.staticTexts["torrent-local-duration"]
        waitUntil("Generated test movie must have its real duration") {
            guard let value = Double(((duration.value as? String) ?? duration.label).replacingOccurrences(of: ",", with: ".")) else { return false }
            return value >= 29 && value <= 31
        }
        waitUntil("The actual paused clock must follow its witnessed start and remain inside the real movie") {
            guard let current = self.actualLocalPosition(),
                  let started = Double(((first.value as? String) ?? first.label).replacingOccurrences(of: ",", with: ".")),
                  let length = Double(((duration.value as? String) ?? duration.label).replacingOccurrences(of: ",", with: ".")) else { return false }
            return current >= started && current < length
        }
    }

    private struct ObservedCatalogFocus {
        let session: String
        let revision: Int
        let grid: String
        let cardID: String
        let layoutFrame: CGRect
        let layouts: [String: CGRect]
    }

    private func observedCatalogFocus() -> ObservedCatalogFocus? {
        let proof = app.descendants(matching: .any).matching(identifier: "asan-catalog-focus-proof").firstMatch
        guard proof.exists, let value = proof.value as? String, let data = value.data(using: .utf8),
              let payload = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any],
              let session = payload["session"] as? String, !session.isEmpty,
              let revision = payload["revision"] as? Int, revision > 0,
              let focus = payload["focus"] as? [String: Any],
              let grid = focus["grid"] as? String, !grid.isEmpty,
              let cardID = focus["id"] as? String, cardID.hasPrefix("media-card-"),
              let layoutFrame = observedLayoutFrame(focus["layoutFrame"]),
              !layoutFrame.intersection(app.frame).isEmpty,
              let rawLayouts = payload["layouts"] as? [String: Any] else { return nil }
        var layouts: [String: CGRect] = [:]
        for (identifier, value) in rawLayouts {
            if let frame = observedLayoutFrame(value) { layouts[identifier] = frame }
        }
        return ObservedCatalogFocus(session: session, revision: revision, grid: grid,
            cardID: cardID, layoutFrame: layoutFrame, layouts: layouts)
    }

    private func observedLayoutFrame(_ value: Any?) -> CGRect? {
        guard let numbers = value as? [NSNumber], numbers.count == 4 else { return nil }
        let values = numbers.map(\.doubleValue)
        guard values.allSatisfy(\.isFinite), values[2] > 0, values[3] > 0 else { return nil }
        return CGRect(x: CGFloat(values[0]), y: CGFloat(values[1]),
                      width: CGFloat(values[2]), height: CGFloat(values[3]))
    }

    private func catalogFocusAgreesWithAX(_ observed: ObservedCatalogFocus) -> Bool {
        guard cards.firstMatch.exists else { return true }
        let card = app.buttons[observed.cardID]
        let focused = cards.matching(NSPredicate(format: "hasFocus == true")).firstMatch
        guard card.exists, hasRemoteFocus(card), card.isHittable,
              !focused.exists || focused.identifier == observed.cardID else {
            captureFailureState("Native label focus disagrees with available AX: \(observed.cardID), revision \(observed.revision)")
            XCTFail("Available AX and the actual native label must agree about the focused poster")
            return false
        }
        return true
    }

    private func pressCatalogRemote(_ button: XCUIRemote.Button, after revision: Int? = nil) {
        remote.press(button)
        let update = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in
            guard let observed = self.observedCatalogFocus() else { return false }
            return revision.map { observed.revision > $0 } ?? true
        }, object: nil)
        // A boundary can leave focus unchanged. The bounded traversal below
        // still requires actual focus on the exact ID before it may succeed.
        _ = XCTWaiter.wait(for: [update], timeout: 1)
    }

    /// Read actual focus inside the link label when the native TabView's AX
    /// subtree is stale. Every movement and selection still uses the remote.
    private func focusFirstFixtureCardWithRemote() -> Bool {
        let firstID = "media-card-/series/drama/900001-severnaya-liniya.html"
        let proof = app.descendants(matching: .any).matching(identifier: "asan-catalog-focus-proof").firstMatch
        guard proof.waitForExistence(timeout: 15) else {
            captureFailureState("The root native-focus observer did not appear")
            XCTFail("The actual native-focus observer must be observable before navigation")
            return false
        }
        for step in 0..<13 {
            if observedCatalogFocus() != nil { break }
            pressCatalogRemote(step < 3 ? .right : .down)
        }
        guard let acquired = observedCatalogFocus(), catalogFocusAgreesWithAX(acquired) else {
            captureFailureState("The remote did not acquire an actual native poster focus")
            XCTFail("The remote must focus an actual fixture poster before selecting its first item")
            return false
        }
        var previousRevision = acquired.revision
        for step in 0...18 {
            guard let observed = observedCatalogFocus(), observed.session == acquired.session,
                  observed.grid == acquired.grid, observed.revision >= previousRevision,
                  catalogFocusAgreesWithAX(observed) else { break }
            previousRevision = observed.revision
            if observed.cardID == firstID { return true }
            guard step < 18 else { break }
            // Only measured, instantiated labels supply geometry. Up can bring
            // an offscreen lazy row back; never invent a target frame or tap it.
            guard let targetFrame = observed.layouts[firstID] else {
                pressCatalogRemote(.up, after: observed.revision)
                continue
            }
            let focusedFrame = observed.layoutFrame
            let dx = targetFrame.midX - focusedFrame.midX
            let dy = targetFrame.midY - focusedFrame.midY
            let rowTolerance = max(8, min(16, min(targetFrame.height, focusedFrame.height) * 0.2))
            if abs(dy) > rowTolerance {
                pressCatalogRemote(dy > 0 ? .down : .up, after: observed.revision)
            } else if abs(dx) > 8 {
                pressCatalogRemote(dx > 0 ? .right : .left, after: observed.revision)
            } else { break }
        }
        captureFailureState("Actual native label focus did not reach the first fixture ID")
        XCTFail("The remote must focus the first actual fixture poster")
        return false
    }

    private func openLocalFixtureDetailsWithRemote() {
        remote.press(.right) // Leave the native sidebar for the catalogue.
        guard focusFirstFixtureCardWithRemote() else { return }
        assertNoKeyboardOutsideSearch("Catalogue")
        remote.press(.select)
        let title = app.staticTexts["details-title"]
        XCTAssertTrue(title.waitForExistence(timeout: 20))
        XCTAssertEqual(title.label, "Северная линия")
        XCTAssertTrue(title.isHittable)
        assertNoKeyboardOutsideSearch("Details")
    }

    private func assertNoKeyboardOutsideSearch(_ screen: String) {
        let hasKeyboard = app.keyboards.firstMatch.exists
        if hasKeyboard { captureFailureState("The system keyboard leaked into \(screen)") }
        XCTAssertFalse(hasKeyboard, "\(screen) must not present the system search keyboard")
    }

    func testCinematicDetailsAndExactLowerCardReturn() {
        launch("stress")
        XCTAssertTrue(cards.firstMatch.waitForExistence(timeout: 30))
        XCTAssertNotNil(focusCard())
        for _ in 0..<3 { remote.press(.down) }
        guard let card = cards.allElementsBoundByIndex.first(where: \.hasFocus) else { return XCTFail("No lower-row focused card") }
        let identifier = card.identifier, label = card.label, before = card.frame
        XCTAssertNotEqual(identifier, cards.firstMatch.identifier)
        remote.press(.select)
        let title = app.staticTexts["details-title"], watch = app.buttons["details-watch"]
        XCTAssertTrue(title.waitForExistence(timeout: 20))
        XCTAssertTrue(label.contains(title.label), "Details must belong to the selected poster")
        waitUntil("Readable hero and primary action must be visible") { title.isHittable && watch.isHittable && watch.isEnabled }
        captureReady("cinematic-details-background")
        remote.press(.menu)
        let restored = app.buttons[identifier]
        waitUntil("Back must restore the exact lower-row poster") { restored.exists && restored.hasFocus && restored.isHittable }
        XCTAssertLessThanOrEqual(abs(restored.frame.midY - before.midY), before.height * 0.25,
            "Returning from Details must retain the scroll position")
        captureReady("cinematic-exact-focus-return")
    }

    private func checkLocalResumeAndStart(vlc: Bool) {
        launch(vlc ? "local-vlc-details" : "local-details")
        openLocalFixtureDetailsWithRemote()
        let play = app.buttons["details-play-local"]
        XCTAssertTrue(play.waitForExistence(timeout: 20))
        XCTAssertTrue(play.label.contains("Продолжить"))
        XCTAssertTrue(focusToward(play)); remote.press(.select)
        // Canonical episode history is 18s, deliberately different from the
        // per-download 12s fallback. This catches wrong precedence as well.
        waitForLocalPlayback(vlc: vlc, minimum: 18, maximum: 28)
        captureReady(vlc ? "local-vlc-canonical-resume" : "local-avkit-canonical-resume")
        remote.press(.menu)
        let start = app.buttons["details-from-start"]
        XCTAssertTrue(start.waitForExistence(timeout: 20))
        waitUntil("Back must dismiss the local player before editing playback position") {
            !self.app.descendants(matching: .any).matching(identifier: "torrent-local-player").firstMatch.exists
                && start.isHittable
        }
        XCTAssertTrue(focusToward(start)); remote.press(.select)
        waitForLocalPlayback(vlc: vlc, minimum: 0, maximum: 5)
        captureReady(vlc ? "local-vlc-explicit-start" : "local-avkit-explicit-start")
        remote.press(.menu)
        XCTAssertTrue(play.waitForExistence(timeout: 15))
    }

    func testLocalAVKitResumesHistoryAndStartsFromZero() { checkLocalResumeAndStart(vlc: false) }
    func testLocalVLCResumesHistoryAndStartsFromZero() { checkLocalResumeAndStart(vlc: true) }

    func testSeriesIntroSettingSavesAndReopens() {
        launch("intro-settings")
        openLocalFixtureDetailsWithRemote()
        let reopen = app.buttons["details-intro-settings"]
        XCTAssertTrue(reopen.waitForExistence(timeout: 15))
        waitUntil("The details action must load the saved per-series duration") { reopen.label.contains("15") }
        XCTAssertTrue(focusToward(reopen)); remote.press(.select)
        let value = app.staticTexts["intro-duration-value"]
        XCTAssertTrue(value.waitForExistence(timeout: 20))
        waitUntil("The saved per-series duration must load before editing") { value.label.contains("15") }
        XCTAssertTrue(focusToward(app.buttons["intro-duration-30"])); remote.press(.select)
        waitUntil("Selection must show the chosen duration") { value.label.contains("30") }
        let save = app.buttons["intro-duration-save"]
        XCTAssertTrue(focusToward(save)); remote.press(.select)
        waitUntil("Saving must dismiss the settings sheet") { !save.exists }
        XCTAssertTrue(reopen.waitForExistence(timeout: 15))
        XCTAssertTrue(reopen.label.contains("30"))
        XCTAssertTrue(focusToward(reopen)); remote.press(.select)
        XCTAssertTrue(value.waitForExistence(timeout: 15))
        waitUntil("Reopening must read the saved per-series preference") { value.label.contains("30") }
        captureReady("intro-setting-saved-and-reopened")
        remote.press(.menu)
        XCTAssertTrue(reopen.waitForExistence(timeout: 15))
    }

    func testLocalVLCConfiguredIntroSkipSeeksActualClock() {
        launch("local-vlc-details")
        openLocalFixtureDetailsWithRemote()
        let start = app.buttons["details-from-start"]
        XCTAssertTrue(start.waitForExistence(timeout: 20))
        XCTAssertTrue(focusToward(start)); remote.press(.select)
        let player = app.descendants(matching: .any).matching(identifier: "torrent-local-player").firstMatch
        let state = app.descendants(matching: .any).matching(identifier: "torrent-vlc-state").firstMatch
        XCTAssertTrue(player.waitForExistence(timeout: 20))
        waitUntil("VLC must actually start the local movie before pausing", timeout: 20) {
            state.exists && state.label == "Воспроизводится"
        }
        // Real remote pause keeps the short test clip before its 15s intro mark
        // while slower accessibility snapshots navigate the normal video UI.
        remote.press(.playPause)
        waitUntil("The real VLC player must acknowledge the remote pause") {
            state.exists && state.label == "Приостановлено"
        }
        let loading = app.descendants(matching: .any).matching(identifier: "torrent-vlc-loading").firstMatch
        XCTAssertFalse(loading.exists, "An intentionally paused movie must not show a loading overlay")
        waitUntil("The actual paused clock must remain before the configured intro mark") {
            guard let position = self.actualLocalPosition() else { return false }
            return position >= 0 && position < 15
        }
        let duration = app.staticTexts["torrent-local-duration"]
        waitUntil("Generated test movie must have its real duration") {
            guard duration.exists,
                  let value = Double(((duration.value as? String) ?? duration.label).replacingOccurrences(of: ",", with: ".")) else { return false }
            return value >= 29 && value <= 31
        }
        remote.press(.up) // Reveal native video controls if the overlay hid.
        let skip = app.buttons["torrent-vlc-skip-intro"]
        XCTAssertTrue(skip.waitForExistence(timeout: 10))
        XCTAssertTrue(focusToward(skip)); remote.press(.select)
        waitUntil("Seeking while paused must preserve the intentional pause without a loading overlay") {
            state.label == "Приостановлено" && !loading.exists
        }
        // VLCKit's time getter is event-cached: resume real playback before
        // requiring a decoded-clock acknowledgement of the paused seek.
        remote.press(.playPause)
        waitUntil("VLC must really resume after the paused intro seek", timeout: 20) {
            state.label == "Воспроизводится"
        }
        waitUntil("Skip must move the real VLC clock to the configured 15s mark", timeout: 10) {
            guard let position = self.actualLocalPosition() else { return false }
            return position >= 15 && position < 25
        }
        remote.press(.playPause)
        waitUntil("VLC must pause again after acknowledging the real intro seek") {
            state.label == "Приостановлено" && !loading.exists
        }
        captureReady("local-vlc-intro-skipped")
        remote.press(.menu)
        XCTAssertTrue(app.buttons["details-play-local"].waitForExistence(timeout: 15))
    }

    func testRecoveryOffersTorrentForSameFilm() {
        launch("recovery")
        let offer = app.alerts["Видео часто останавливается"]
        XCTAssertTrue(offer.waitForExistence(timeout: 20))
        captureReady("playback-recovery-offer")
        // The actual tvOS alert exposes both a wrapper Button and its child
        // with this label. Resolve candidates by index, and accept focus on
        // either native representation before sending the real remote Select.
        let findCandidates = offer.buttons.matching(NSPredicate(format: "label == %@", "Найти торрент"))
        let find = findCandidates.firstMatch
        XCTAssertTrue(find.waitForExistence(timeout: 10))
        for _ in 0..<8 {
            if findCandidates.allElementsBoundByIndex.contains(where: \.hasFocus) { break }
            guard let focused = offer.buttons.allElementsBoundByIndex.first(where: \.hasFocus),
                  !find.frame.isEmpty else { remote.press(.down); continue }
            let dx = find.frame.midX - focused.frame.midX
            let dy = find.frame.midY - focused.frame.midY
            if abs(dy) > max(25, min(find.frame.height, focused.frame.height) * 0.6) {
                remote.press(dy > 0 ? .down : .up)
            } else { remote.press(dx > 0 ? .right : .left) }
        }
        XCTAssertTrue(findCandidates.allElementsBoundByIndex.contains(where: \.hasFocus),
            "Remote must focus the native Find Torrent action, on its wrapper or leaf")
        remote.press(.select)
        let title = app.staticTexts["torrent-search-title"]
        XCTAssertTrue(title.waitForExistence(timeout: 20))
        XCTAssertEqual(title.label, "Северная линия")
        XCTAssertTrue(searchResults.firstMatch.waitForExistence(timeout: 15))
        XCTAssertTrue(searchResults.firstMatch.label.contains("Northern Line"))
        XCTAssertFalse(app.descendants(matching: .any).matching(identifier: "playback-screen").firstMatch.exists,
            "Discovery must open after dismissing the existing player")
        captureReady("playback-recovery-same-film-search")
        XCTAssertTrue(focusToward(searchResults.firstMatch)); remote.press(.select)
        let firstEpisode = app.buttons["torrent-file-0"], secondEpisode = app.buttons["torrent-file-2"]
        XCTAssertTrue(firstEpisode.waitForExistence(timeout: 20))
        XCTAssertTrue(secondEpisode.waitForExistence(timeout: 10))
        XCTAssertTrue(firstEpisode.label.contains("S01E01"), firstEpisode.label)
        XCTAssertTrue(firstEpisode.label.contains("Нужная серия по каталогу"),
            "Recovery must preserve the current canonical episode through metadata selection")
        XCTAssertTrue(secondEpisode.label.contains("S01E02"), secondEpisode.label)
        XCTAssertFalse(secondEpisode.label.contains("Нужная серия по каталогу"),
            "The next episode must not be marked as the current one")
        remote.press(.menu)
        waitUntil("Back must finish closing the file chooser before leaving search") {
            !self.app.descendants(matching: .any).matching(identifier: "torrent-files").firstMatch.exists
                && self.searchResults.firstMatch.exists && self.searchResults.firstMatch.isHittable
        }
        XCTAssertEqual(title.label, "Северная линия")
        remote.press(.menu)
        waitUntil("Back must dismiss the actual torrent search sheet") {
            !self.app.descendants(matching: .any).matching(identifier: "torrent-search-screen").firstMatch.exists
        }
        XCTAssertTrue(focusFirstFixtureCardWithRemote())
    }

    func testSeriesMultiselectQueuesBothEpisodesViaUp() {
        launch("catalog")
        guard focusFirstFixtureCardWithRemote() else { return }
        remote.press(.select)
        let torrent = app.buttons["details-torrent"]
        XCTAssertTrue(torrent.waitForExistence(timeout: 20))
        XCTAssertTrue(focusToward(torrent)); remote.press(.select)
        XCTAssertTrue(searchResults.firstMatch.waitForExistence(timeout: 20))
        XCTAssertTrue(focusToward(searchResults.firstMatch)); remote.press(.select)
        let first = app.buttons["torrent-file-0"], second = app.buttons["torrent-file-2"]
        let confirm = app.buttons["torrent-queue-confirm"]
        XCTAssertTrue(first.waitForExistence(timeout: 15))
        XCTAssertFalse(confirm.isEnabled)
        XCTAssertFalse(app.buttons["torrent-file-1"].isEnabled)
        XCTAssertTrue(focusToward(first)); remote.press(.select)
        waitUntil("First file must toggle without starting payload") { first.value as? String == "Выбрано" }
        XCTAssertTrue(focusToward(second)); remote.press(.select)
        waitUntil("Both files must be selected") { second.value as? String == "Выбрано" && confirm.label.contains("2") }
        for _ in 0..<8 { if hasRemoteFocus(confirm) { break }; remote.press(.up) }
        XCTAssertTrue(hasRemoteFocus(confirm), "UP from file rows must reach the explicit confirm action")
        XCTAssertTrue(confirm.isEnabled)
        captureReady("torrent-series-multiselect-confirm-up")
        remote.press(.select)
        let detailsTorrent = app.buttons["details-torrent"]
        waitUntil("Queue confirmation must fully dismiss the file/search flow") {
            !self.app.descendants(matching: .any).matching(identifier: "torrent-files").firstMatch.exists
                && !self.app.descendants(matching: .any).matching(identifier: "torrent-search-screen").firstMatch.exists
                && detailsTorrent.exists && detailsTorrent.isHittable
        }
        remote.press(.menu)
        waitUntil("Details must close before opening the native sidebar") {
            !self.app.descendants(matching: .any).matching(identifier: "media-details").firstMatch.exists
        }
        guard focusFirstFixtureCardWithRemote() else { return }
        remote.press(.menu)
        let downloads = app.buttons["Загрузки"]
        waitUntil("Downloads tab must open in the native sidebar") { downloads.isEnabled && downloads.isHittable }
        XCTAssertTrue(focusToward(downloads)); remote.press(.select)
        XCTAssertTrue(torrentRows.firstMatch.waitForExistence(timeout: 15))
        XCTAssertEqual(torrentRows.count, 2)
        let rows = torrentRows.allElementsBoundByIndex
        XCTAssertTrue(rows[0].label.contains("S01E01"), rows[0].label)
        XCTAssertTrue(rows[1].label.contains("S01E02"), rows[1].label)
        XCTAssertTrue(rows.allSatisfy { $0.label.contains("В очереди") })
        captureReady("torrent-series-ordered-queue")
    }

    func testLibraryStateBadgesKeepRealMetadata() {
        launch("library-states")
        let series = app.buttons["media-card-/series/drama/900001-severnaya-liniya.html"]
        let watched = app.buttons["media-card-/films/drama/900002-gorod-posle-polunochi.html"]
        XCTAssertTrue(series.waitForExistence(timeout: 20))
        waitUntil("Known next episode must appear as a factual badge") { series.label.contains("Новая серия") }
        XCTAssertTrue(series.label.contains("Детектив"))
        XCTAssertTrue(series.label.contains("8.4") || series.label.contains("8,4"))
        XCTAssertTrue(watched.label.contains("Просмотрено"), watched.label)
        XCTAssertFalse(watched.label.contains("Новая серия"))
        captureReady("library-states-and-progress")
    }

    func testDownloadedLocalPlayerBack() {
        launch("torrent-player")
        let player = app.descendants(matching: .any).matching(identifier: "torrent-local-player").firstMatch
        XCTAssertTrue(player.waitForExistence(timeout: 30))
        let playing = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in
            (player.value as? String) == "Воспроизводится"
        }, object: nil)
        XCTAssertEqual(XCTWaiter.wait(for: [playing], timeout: 20), .completed,
            "The generated local H264 clip must actually start, not just show an AVKit container")
        screenshot("torrent-local-player")
        remote.press(.menu)
        let returned = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in !player.exists }, object: nil)
        XCTAssertEqual(XCTWaiter.wait(for: [returned], timeout: 15), .completed)
        XCTAssertTrue(app.buttons["torrent-add"].waitForExistence(timeout: 15))
        XCTAssertEqual(app.state, .runningForeground)
    }

    func testSearchUsesNativeKeyboardWithoutOverlappingHeading() {
        launch("search")
        // Open Search through the native tab action. Automatic DEBUG routing
        // can show a controller visually before automation owns its AX subtree.
        remote.press(.right)
        remote.press(.menu)
        let searchTab = app.buttons["Поиск"]
        waitUntil("The native Search tab must be reachable") { searchTab.exists && searchTab.isEnabled && searchTab.isHittable }
        XCTAssertTrue(focusToward(searchTab))
        remote.press(.select)
        let field = app.searchFields.firstMatch
        XCTAssertTrue(field.waitForExistence(timeout: 20), "Search must expose the system search field")
        // Leave the native sidebar and enter the real search controller. The
        // keyboard must be present before typing; no QA text field replaces it.
        remote.press(.right)
        let keyboard = app.keyboards.firstMatch
        XCTAssertTrue(keyboard.waitForExistence(timeout: 15), "The real tvOS search keyboard must be visible")
        waitUntil("The native search field or keyboard must own focus") {
            self.hasRemoteFocus(field) || self.hasRemoteFocus(keyboard)
        }
        XCTAssertFalse(app.staticTexts["Поиск Rezka"].exists, "A navigation heading must not cover the system keyboard")
        XCTAssertFalse(keyboard.frame.isEmpty)
        XCTAssertTrue(field.isHittable)
        screenshot("search-native-keyboard")

        // Apple's tvOS XCTest typeText API sends native keyboard input to the
        // focused field. This avoids depending on the system keyboard's internal
        // leaf structure; it never assigns the query or any application state.
        field.typeText("х")
        waitUntil("The actual system search field must contain the entered query") {
            (field.value as? String)?.lowercased() == "х"
        }
        let result = app.buttons["media-card-/films/adventures/900005-karta-tihogo-morya.html"]
        XCTAssertTrue(result.waitForExistence(timeout: 15), "The bound query must update the real result grid")
        XCTAssertEqual(cards.count, 1, "The fixture search must filter rather than show the entire catalogue")
        XCTAssertTrue(keyboard.exists)
        XCTAssertFalse(app.staticTexts["Поиск Rezka"].exists)
        screenshot("search-native-keyboard-results")

        // Use the remote to leave keyboard input and open the real result.
        // This checks that removing the heading preserves native navigation.
        XCTAssertTrue(focusToward(result), "DOWN must reach the result below the native keyboard")
        remote.press(.select)
        XCTAssertTrue(app.buttons["details-torrent"].waitForExistence(timeout: 15))
        XCTAssertFalse(keyboard.exists, "Opening a result must leave the native search keyboard")
        remote.press(.menu)
        XCTAssertTrue(result.waitForExistence(timeout: 15))
        XCTAssertEqual(app.state, .runningForeground)
    }

    func testVLCLocalPlayerBack() {
        // This runs the same generated MP4 through VLC to verify the actual
        // widget/delegate/Back path. It is not presented as an MKV codec test.
        launch("torrent-vlc-player")
        let player = app.descendants(matching: .any).matching(identifier: "torrent-local-player").firstMatch
        XCTAssertTrue(player.waitForExistence(timeout: 30))
        let state = app.descendants(matching: .any).matching(identifier: "torrent-vlc-state").firstMatch
        XCTAssertTrue(state.waitForExistence(timeout: 10))
        let playing = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in
            state.label == "Воспроизводится"
        }, object: nil)
        XCTAssertEqual(XCTWaiter.wait(for: [playing], timeout: 20), .completed,
            "VLC must report real playback of the generated local clip")
        remote.press(.playPause)
        let paused = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in
            state.label == "Приостановлено"
        }, object: nil)
        XCTAssertEqual(XCTWaiter.wait(for: [paused], timeout: 10), .completed,
            "The remote Play/Pause button must pause the actual VLC player")
        remote.press(.playPause)
        let resumed = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in
            state.label == "Воспроизводится"
        }, object: nil)
        XCTAssertEqual(XCTWaiter.wait(for: [resumed], timeout: 10), .completed,
            "The second remote Play/Pause press must resume the actual VLC player")
        screenshot("torrent-vlc-local-player")
        remote.press(.menu)
        let returned = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in !player.exists }, object: nil)
        XCTAssertEqual(XCTWaiter.wait(for: [returned], timeout: 15), .completed)
        XCTAssertTrue(app.buttons["torrent-add"].waitForExistence(timeout: 15))
        XCTAssertEqual(app.state, .runningForeground)
    }
}
