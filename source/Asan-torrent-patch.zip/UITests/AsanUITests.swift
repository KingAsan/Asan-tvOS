import XCTest

final class AsanUITests: XCTestCase {
    private var app: XCUIApplication!
    private let remote = XCUIRemote.shared

    override func setUp() {
        super.setUp()
        continueAfterFailure = false
        app = XCUIApplication()
    }

    private func launch(_ scene: String, reducedEffects: Bool = false) {
        app.launchArguments = ["--screenshot-scene", scene, "-AppleLanguages", "(ru)", "-AppleLocale", "ru_RU"]
        if reducedEffects { app.launchArguments.append("--qa-reduce-effects") }
        app.launch()
        app.activate()
        XCTAssertTrue(app.wait(for: .runningForeground, timeout: 15))
        if ["catalog", "stress", "guest", "settings", "restoring", "downloads", "torrent-list"].contains(scene) { remote.press(.right) }
    }

    private var cards: XCUIElementQuery {
        app.descendants(matching: .button).matching(NSPredicate(format: "identifier BEGINSWITH %@", "media-card-"))
    }

    private func screenshot(_ name: String) {
        XCTAssertEqual(app.state, .runningForeground, "Refusing to capture SpringBoard as an app screen")
        // Element existence does not mean the tvOS focus/sidebar/sheet animation
        // has finished drawing. Capturing mid-transition hides native labels.
        Thread.sleep(forTimeInterval: 2.5)
        let attachment = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
        let tree = XCTAttachment(string: app.debugDescription)
        tree.name = name + "-accessibility"
        tree.lifetime = .keepAlways
        add(tree)
    }

    private func focusCard() -> XCUIElement? {
        for _ in 0..<3 { remote.press(.right) }
        for _ in 0..<10 {
            if let focused = cards.allElementsBoundByIndex.first(where: { $0.hasFocus }) { return focused }
            remote.press(.down)
        }
        return nil
    }

    func testCardShowsExactlyOneGenreAndRealRatingWithNativeSidebar() {
        launch("catalog")
        let first = app.buttons["media-card-/series/drama/900001-severnaya-liniya.html"]
        XCTAssertTrue(first.waitForExistence(timeout: 30))
        XCTAssertTrue(first.label.contains("Детектив"), first.label)
        XCTAssertTrue(first.label.contains("8.4") || first.label.contains("8,4"), first.label)
        XCTAssertFalse(first.label.contains("Приключения"), "All genres leaked into a poster card")
        // The system sidebar opens with Back/Menu; repeated left presses can
        // remain on the catalog's first control without ever opening it.
        remote.press(.menu)
        let searchTab = app.buttons["Поиск"]
        let expanded = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in
            searchTab.isEnabled && searchTab.isHittable
        }, object: nil)
        XCTAssertEqual(XCTWaiter.wait(for: [expanded], timeout: 10), .completed)
        screenshot("sidebar-expanded")
        remote.press(.right)
        let collapsed = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in
            !searchTab.isEnabled
        }, object: nil)
        XCTAssertEqual(XCTWaiter.wait(for: [collapsed], timeout: 10), .completed)
        screenshot("sidebar-collapsed")
        XCTAssertEqual(app.state, .runningForeground)
    }

    func testNativeFocusOpenDetailAndMenuBack() {
        launch("catalog")
        XCTAssertTrue(cards.firstMatch.waitForExistence(timeout: 30))
        XCTAssertNotNil(focusCard(), "Remote cannot focus any catalog card")
        screenshot("catalog-focused")
        remote.press(.select)
        XCTAssertTrue(app.buttons["Смотреть"].waitForExistence(timeout: 20))
        screenshot("detail")
        remote.press(.menu)
        XCTAssertTrue(cards.firstMatch.waitForExistence(timeout: 20))
        screenshot("catalog-after-back")
    }

    func testMenuExitsEmbeddedPlayer() {
        launch("player")
        let player = app.descendants(matching: .any).matching(identifier: "playback-screen").firstMatch
        XCTAssertTrue(player.waitForExistence(timeout: 30))
        remote.press(.menu)
        XCTAssertTrue(cards.firstMatch.waitForExistence(timeout: 20))
        XCTAssertFalse(player.exists, "Back did not dismiss the actual playback cover")
        screenshot("player-back-to-catalog")
    }

    func testCachedCatalogVisibleWhileAccountIsBeingChecked() {
        launch("restoring")
        let first = app.buttons["media-card-/series/drama/900001-severnaya-liniya.html"]
        XCTAssertTrue(first.waitForExistence(timeout: 30), "Cached posters must not wait behind account network validation")
        XCTAssertFalse(first.isEnabled, "Playback stays gated until the session is validated")
        screenshot("cached-catalog-restoring")
    }

    func testScrollRoundTripsWith240CardsAndMissingMetadata() {
        launch("stress")
        XCTAssertTrue(cards.firstMatch.waitForExistence(timeout: 30))
        XCTAssertNotNil(focusCard())
        let start = Date()
        for _ in 0..<2 {
            for _ in 0..<8 { remote.press(.down) }
            screenshot("stress-lower-cards")
            for _ in 0..<8 { remote.press(.up) }
        }
        let timing = XCTAttachment(string: "32 remote scroll commands, 240 offline cards: \(Date().timeIntervalSince(start)) seconds. Simulator wall time, not device FPS.")
        timing.name = "scroll-timing"
        timing.lifetime = .keepAlways
        add(timing)
        XCTAssertEqual(app.state, .runningForeground)
        screenshot("stress-after-roundtrip")
    }

    func testVoiceAndQualityScreensRemainReachable() {
        launch("voices")
        XCTAssertTrue(app.buttons.matching(NSPredicate(format: "label CONTAINS %@", "Профессиональная многоголосая")).firstMatch.waitForExistence(timeout: 30))
        screenshot("voices")
        app.terminate()
        launch("qualities")
        XCTAssertTrue(app.buttons.matching(NSPredicate(format: "label CONTAINS %@", "1080")).firstMatch.waitForExistence(timeout: 30))
        assertUniqueQualities()
        screenshot("qualities")
    }

    private func assertUniqueQualities() {
        let rows = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "quality-option-"))
        XCTAssertTrue(rows.firstMatch.waitForExistence(timeout: 20))
        XCTAssertEqual(rows.count, 4, "Eight stream aliases must become exactly four quality choices")
        for height in [1080, 720, 480, 360] {
            XCTAssertEqual(rows.matching(NSPredicate(format: "label CONTAINS %@", "\(height)p")).count, 1)
        }
    }

    private func choiceRowHasFocus() -> Bool {
        let predicate = NSPredicate(format: "identifier BEGINSWITH %@", "choice-row-")
        if app.buttons.matching(predicate).allElementsBoundByIndex.contains(where: { $0.hasFocus }) { return true }
        // In a native tvOS List the Cell owns focus, while its Button is the
        // accessible action. The captured failure hierarchy confirms this.
        return app.cells.allElementsBoundByIndex.contains { cell in
            cell.hasFocus && cell.descendants(matching: .button).matching(predicate).count > 0
        }
    }

    func testPlayerQualitySheetAlsoGroupsAliases() {
        launch("player-qualities")
        assertUniqueQualities()
        screenshot("player-qualities-no-duplicates")
        remote.press(.menu)
        let player = app.descendants(matching: .any).matching(identifier: "playback-screen").firstMatch
        XCTAssertTrue(player.waitForExistence(timeout: 10))
        remote.press(.menu)
        XCTAssertTrue(cards.firstMatch.waitForExistence(timeout: 20))
    }

    func testReducedEffectsStillShowsReadableUniqueQualities() {
        launch("qualities", reducedEffects: true)
        assertUniqueQualities()
        screenshot("qualities-reduced-effects")
    }

    func testScrollCollectsApplicationCPUAndMemoryMetrics() {
        launch("stress")
        XCTAssertTrue(cards.firstMatch.waitForExistence(timeout: 30))
        XCTAssertNotNil(focusCard())
        let options = XCTMeasureOptions()
        options.iterationCount = 1
        measure(metrics: [XCTClockMetric(), XCTCPUMetric(application: app), XCTMemoryMetric(application: app)], options: options) {
            for _ in 0..<8 { remote.press(.down) }
            for _ in 0..<8 { remote.press(.up) }
        }
        XCTAssertEqual(app.state, .runningForeground)
    }

    /// This tour is recorded by simctl, in addition to still XCTest attachments.
    func testAMotionTour() {
        launch("catalog")
        XCTAssertTrue(cards.firstMatch.waitForExistence(timeout: 30))
        remote.press(.menu)
        let search = app.buttons["Поиск"]
        let expanded = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in search.isEnabled && search.isHittable }, object: nil)
        XCTAssertEqual(XCTWaiter.wait(for: [expanded], timeout: 10), .completed)
        Thread.sleep(forTimeInterval: 0.6)
        remote.press(.right)
        XCTAssertNotNil(focusCard())
        remote.press(.select)
        XCTAssertTrue(app.buttons["Смотреть"].waitForExistence(timeout: 20))
        Thread.sleep(forTimeInterval: 0.6)
        let watch = app.buttons["Смотреть"]
        let focused = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in watch.hasFocus }, object: nil)
        XCTAssertEqual(XCTWaiter.wait(for: [focused], timeout: 10), .completed)
        remote.press(.select)
        XCTAssertTrue(app.buttons.matching(NSPredicate(format: "label CONTAINS %@", "Профессиональная многоголосая")).firstMatch.waitForExistence(timeout: 20))
        Thread.sleep(forTimeInterval: 0.6)
        for _ in 0..<3 {
            if app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "quality-option-")).firstMatch.waitForExistence(timeout: 3) { break }
            let row = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "choice-row-")).firstMatch
            XCTAssertTrue(row.waitForExistence(timeout: 20))
            for _ in 0..<8 { if choiceRowHasFocus() { break }; remote.press(.down) }
            if !choiceRowHasFocus() {
                let tree = XCTAttachment(string: app.debugDescription)
                tree.name = "motion-choice-focus-failure"
                tree.lifetime = .keepAlways
                add(tree)
            }
            XCTAssertTrue(choiceRowHasFocus())
            remote.press(.select)
        }
        assertUniqueQualities()
        Thread.sleep(forTimeInterval: 0.6)
        for _ in 0..<4 {
            if app.buttons["Смотреть"].exists && app.buttons["Смотреть"].isHittable { break }
            remote.press(.menu)
        }
        XCTAssertTrue(app.buttons["Смотреть"].waitForExistence(timeout: 10))
        remote.press(.menu)
        XCTAssertTrue(cards.firstMatch.waitForExistence(timeout: 15))
        screenshot("motion-tour-finished")
    }

    func testGuestSettingsAndLoginScreens() {
        launch("guest")
        XCTAssertTrue(app.staticTexts["Войти в Rezka"].waitForExistence(timeout: 20))
        screenshot("guest")
        app.terminate()
        launch("settings")
        XCTAssertTrue(app.buttons["Войти в Rezka"].waitForExistence(timeout: 20))
        screenshot("settings")
        app.terminate()
        launch("login")
        XCTAssertTrue(app.secureTextFields.firstMatch.waitForExistence(timeout: 20))
        screenshot("login")
    }

    private var torrentRows: XCUIElementQuery {
        app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "torrent-download-"))
    }

    private var searchResults: XCUIElementQuery {
        app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "torrent-search-result-"))
    }

    func testTorrentButtonSearchFileSelectionAndBack() {
        launch("details")
        let torrent = app.buttons["details-torrent"]
        XCTAssertTrue(torrent.waitForExistence(timeout: 20))
        for _ in 0..<4 { if torrent.hasFocus { break }; remote.press(.right) }
        XCTAssertTrue(torrent.hasFocus, "Torrent must be reachable beside Watch with the remote")
        screenshot("detail-torrent-button")
        remote.press(.select)
        XCTAssertTrue(searchResults.firstMatch.waitForExistence(timeout: 20))
        XCTAssertEqual(searchResults.count, 2)
        XCTAssertTrue(searchResults.firstMatch.label.contains("Northern Line"), searchResults.firstMatch.label)
        XCTAssertTrue(searchResults.firstMatch.label.contains("1080p"), searchResults.firstMatch.label)
        screenshot("film-torrent-results")
        XCTAssertTrue(focusTorrentButton(searchResults.firstMatch))
        remote.press(.select)
        let file = app.buttons["torrent-file-0"]
        XCTAssertTrue(file.waitForExistence(timeout: 20), "Selected release must enter the existing metadata/file chooser")
        XCTAssertFalse(app.buttons["torrent-file-1"].isEnabled, "Non-video file must remain unavailable")
        screenshot("film-torrent-files")
        remote.press(.menu)
        XCTAssertTrue(searchResults.firstMatch.waitForExistence(timeout: 15))
        XCTAssertEqual(searchResults.count, 2)
        // Re-enter after cancellation to catch stale preparation handles and
        // orphaned sheets. This fixture queues no payload and uses no network.
        let first = searchResults.firstMatch
        let ready = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in first.isEnabled }, object: nil)
        XCTAssertEqual(XCTWaiter.wait(for: [ready], timeout: 15), .completed)
        XCTAssertTrue(focusTorrentButton(first))
        remote.press(.select)
        XCTAssertTrue(file.waitForExistence(timeout: 15))
        XCTAssertTrue(focusTorrentButton(file))
        remote.press(.select)
        XCTAssertTrue(torrent.waitForExistence(timeout: 15))
        XCTAssertFalse(searchResults.firstMatch.exists, "Choosing a file must close the whole search flow")
        screenshot("film-torrent-queued-back-to-detail")
    }

    func testTorrentSearchEmptyAndErrorRetryAndExit() {
        for scene in ["torrent-search-empty", "torrent-search-error"] {
            launch(scene)
            let state = app.staticTexts[scene == "torrent-search-empty" ? "torrent-search-empty" : "torrent-search-error"]
            XCTAssertTrue(state.waitForExistence(timeout: 20))
            XCTAssertEqual(searchResults.count, 0)
            screenshot(scene)
            let retry = app.buttons["torrent-search-retry"]
            XCTAssertTrue(focusTorrentButton(retry))
            remote.press(.select)
            XCTAssertTrue(searchResults.firstMatch.waitForExistence(timeout: 15), "Retry must recover to actual results")
            XCTAssertEqual(searchResults.count, 2)
            XCTAssertFalse(state.exists)
            remote.press(.menu)
            XCTAssertTrue(app.buttons["details-torrent"].waitForExistence(timeout: 15))
            app.terminate()
        }
    }

    func testBIntroPlaysAndEnds() {
        launch("intro")
        let intro = app.descendants(matching: .any).matching(identifier: "asan-intro-overlay").firstMatch
        XCTAssertTrue(intro.waitForExistence(timeout: 3), "Cold launch must show the supplied adapted intro")
        let skip = app.buttons["asan-intro-skip"]
        let playing = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in
            skip.value as? String == "playing"
        }, object: nil)
        XCTAssertEqual(XCTWaiter.wait(for: [playing], timeout: 3), .completed,
                       "A placeholder or timeout fallback must not count as actual intro playback")
        let frame = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        frame.name = "intro-native-frame"
        frame.lifetime = .keepAlways
        add(frame)
        XCTAssertTrue(cards.firstMatch.waitForExistence(timeout: 15), "The actual local movie must end without a remote command")
        XCTAssertFalse(intro.exists)
        app.activate()
        XCTAssertFalse(intro.exists, "Foreground activation must not replay the cold-launch intro")
        screenshot("intro-ended-catalog")
    }

    func testCIntroMenuSkipsToCatalog() {
        launch("intro")
        let intro = app.descendants(matching: .any).matching(identifier: "asan-intro-overlay").firstMatch
        XCTAssertTrue(intro.waitForExistence(timeout: 3))
        remote.press(.menu)
        XCTAssertTrue(cards.firstMatch.waitForExistence(timeout: 10))
        XCTAssertFalse(intro.exists, "Back must skip, not exit the app")
        screenshot("intro-skipped-catalog")
    }

    func testDReducedMotionIntroDoesNotDelayCatalogue() {
        launch("intro", reducedEffects: true)
        XCTAssertTrue(cards.firstMatch.waitForExistence(timeout: 10))
        XCTAssertFalse(app.descendants(matching: .any).matching(identifier: "asan-intro-overlay").firstMatch.exists)
        screenshot("intro-reduced-motion-catalog")
    }

    /// Native Form/List cells can own focus instead of their accessible Button.
    private func focusTorrentButton(_ button: XCUIElement, attempts: Int = 12) -> Bool {
        for _ in 0..<attempts {
            if button.hasFocus { return true }
            let identifier = button.identifier
            if app.cells.allElementsBoundByIndex.contains(where: { cell in
                cell.hasFocus && cell.descendants(matching: .button).matching(identifier: identifier).count > 0
            }) { return true }
            remote.press(.down)
        }
        return false
    }

    func testDownloadsEmptyStateAddInputAndRemoteBack() {
        launch("downloads")
        let add = app.buttons["torrent-add"]
        XCTAssertTrue(add.waitForExistence(timeout: 30))
        XCTAssertTrue(app.descendants(matching: .any).matching(identifier: "torrent-empty").firstMatch.exists)
        let freeSpace = app.staticTexts["torrent-free-space"]
        XCTAssertTrue(freeSpace.exists)
        XCTAssertTrue(freeSpace.label.contains("Свободно"), freeSpace.label)
        XCTAssertEqual(torrentRows.count, 0, "The empty scene must not show old or invented downloads")
        screenshot("torrent-downloads-empty")

        XCTAssertTrue(focusTorrentButton(add), "Remote cannot focus Add Torrent")
        remote.press(.select)
        let field = app.textFields["torrent-magnet"]
        XCTAssertTrue(field.waitForExistence(timeout: 20))
        XCTAssertTrue(app.buttons["torrent-submit"].exists)
        XCTAssertFalse(app.buttons["torrent-submit"].isEnabled, "An empty link must not start a download")
        screenshot("torrent-add-input")
        remote.press(.menu)
        let dismissed = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in
            !field.exists && add.isHittable
        }, object: nil)
        XCTAssertEqual(XCTWaiter.wait(for: [dismissed], timeout: 15), .completed)
        XCTAssertEqual(app.state, .runningForeground)
    }

    func testDownloadRowsDeleteConfirmationAndRemoteBackPreserveFiles() {
        launch("torrent-list")
        XCTAssertTrue(torrentRows.firstMatch.waitForExistence(timeout: 30))
        let count = torrentRows.count
        XCTAssertGreaterThanOrEqual(count, 2)
        XCTAssertTrue(torrentRows.matching(NSPredicate(format: "label CONTAINS %@", "Приостановлено")).firstMatch.exists)
        let completed = torrentRows.matching(NSPredicate(format: "label CONTAINS %@", "Готово к просмотру")).firstMatch
        XCTAssertTrue(completed.exists, "The fixture must include an unexpired completed download")
        screenshot("torrent-downloads-list")
        XCTAssertTrue(focusTorrentButton(completed), "Remote cannot focus a completed download")
        remote.press(.select)

        let remove = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "torrent-delete-")).firstMatch
        XCTAssertTrue(remove.waitForExistence(timeout: 20))
        XCTAssertTrue(app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "torrent-play-")).firstMatch.exists)
        XCTAssertTrue(focusTorrentButton(remove), "Remote cannot reach the Delete action")
        remote.press(.select)
        let confirm = app.buttons["Удалить"]
        XCTAssertTrue(confirm.waitForExistence(timeout: 10))
        screenshot("torrent-delete-confirmation")
        remote.press(.menu)
        let cancelled = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in
            !confirm.exists && remove.isHittable
        }, object: nil)
        XCTAssertEqual(XCTWaiter.wait(for: [cancelled], timeout: 15), .completed)
        remote.press(.menu)
        XCTAssertTrue(torrentRows.firstMatch.waitForExistence(timeout: 15))
        XCTAssertEqual(torrentRows.count, count, "Back must cancel deletion and preserve every download")
        XCTAssertTrue(torrentRows.matching(NSPredicate(format: "label CONTAINS %@", "Приостановлено")).firstMatch.exists)
        XCTAssertTrue(torrentRows.matching(NSPredicate(format: "label CONTAINS %@", "Готово к просмотру")).firstMatch.exists)
        screenshot("torrent-downloads-after-back")
    }

    func testDownloadedLocalPlayerBack() {
        launch("torrent-player")
        let player = app.descendants(matching: .any).matching(identifier: "torrent-local-player").firstMatch
        XCTAssertTrue(player.waitForExistence(timeout: 30))
        let playing = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in
            (player.value as? String) == "Воспроизводится"
        }, object: nil)
        XCTAssertEqual(XCTWaiter.wait(for: [playing], timeout: 20), .completed,
            "The generated local H264 clip must actually start, not just show an AVKit container")
        screenshot("torrent-local-player")
        remote.press(.menu)
        let returned = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in !player.exists }, object: nil)
        XCTAssertEqual(XCTWaiter.wait(for: [returned], timeout: 15), .completed)
        XCTAssertTrue(app.buttons["torrent-add"].waitForExistence(timeout: 15))
        XCTAssertEqual(app.state, .runningForeground)
    }

    func testVLCLocalPlayerBack() {
        // This runs the same generated MP4 through VLC to verify the actual
        // widget/delegate/Back path. It is not presented as an MKV codec test.
        launch("torrent-vlc-player")
        let player = app.descendants(matching: .any).matching(identifier: "torrent-local-player").firstMatch
        XCTAssertTrue(player.waitForExistence(timeout: 30))
        let state = app.descendants(matching: .any).matching(identifier: "torrent-vlc-state").firstMatch
        XCTAssertTrue(state.waitForExistence(timeout: 10))
        let playing = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in
            state.label == "Воспроизводится"
        }, object: nil)
        XCTAssertEqual(XCTWaiter.wait(for: [playing], timeout: 20), .completed,
            "VLC must report real playback of the generated local clip")
        remote.press(.playPause)
        let paused = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in
            state.label == "Приостановлено"
        }, object: nil)
        XCTAssertEqual(XCTWaiter.wait(for: [paused], timeout: 10), .completed,
            "The remote Play/Pause button must pause the actual VLC player")
        remote.press(.playPause)
        let resumed = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in
            state.label == "Воспроизводится"
        }, object: nil)
        XCTAssertEqual(XCTWaiter.wait(for: [resumed], timeout: 10), .completed,
            "The second remote Play/Pause press must resume the actual VLC player")
        screenshot("torrent-vlc-local-player")
        remote.press(.menu)
        let returned = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in !player.exists }, object: nil)
        XCTAssertEqual(XCTWaiter.wait(for: [returned], timeout: 15), .completed)
        XCTAssertTrue(app.buttons["torrent-add"].waitForExistence(timeout: 15))
        XCTAssertEqual(app.state, .runningForeground)
    }
}
