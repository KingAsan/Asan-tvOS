import Foundation
import KinoCore

/// Hints explicitly printed in a release name, never a probe of its actual tracks.
/// A known codec/resolution in the name does not establish profile, bitrate or
/// decoder compatibility on a particular Apple TV.
public struct TorrentReleasePresentation: Equatable, Sendable {
    public let quality: String?
    public let codec: String?
    public let voice: String?
    public let prefersAppleTVHD: Bool

    public init(title: String) {
        let title = String(title.prefix(2_048))
        let resolutions = ["2160p", "1080p", "1080i", "720p", "576p", "480p", "360p"]
            .filter { Self.contains(#"(?i)(?<![\p{L}\p{N}])"# + $0 + #"(?![\p{L}\p{N}])"#, in: title) }
        let is4K = Self.contains(#"(?i)(?<![\p{L}\p{N}])4k(?![\p{L}\p{N}])"#, in: title)
        quality = resolutions.isEmpty ? (is4K ? "4K" : nil) : resolutions.joined(separator: " / ")
        let formats: [(String, String)] = [
            ("H.264", #"(?i)(?<![\p{L}\p{N}])(?:h[ .-]?264|x264|avc)(?![\p{L}\p{N}])"#),
            ("HEVC", #"(?i)(?<![\p{L}\p{N}])(?:h[ .-]?265|x265|hevc)(?![\p{L}\p{N}])"#),
            ("AV1", #"(?i)(?<![\p{L}\p{N}])av1(?![\p{L}\p{N}])"#),
            ("VP9", #"(?i)(?<![\p{L}\p{N}])vp9(?![\p{L}\p{N}])"#),
        ]
        let found = formats.filter { Self.contains($0.1, in: title) }.map(\.0)
        codec = found.isEmpty ? nil : found.joined(separator: " / ")
        // Only named studios or explicit translation markers. Language, year,
        // source WEB-DL and the film title cannot imply an audio track.
        let studios = ["HDRezka Studio", "LostFilm", "NewStudio", "TVShows", "Jaskier", "Кубик в Кубе", "AlexFilm", "Red Head Sound"]
        let statedStudios = studios.filter { studio in
            Self.contains(#"(?i)(?<![\p{L}\p{N}])"# + NSRegularExpression.escapedPattern(for: studio) + #"(?![\p{L}\p{N}])"#, in: title)
        }
        if !statedStudios.isEmpty { voice = statedStudios.joined(separator: " / ") }
        else {
            let translations: [(String, String)] = [
                ("Дублированный", #"(?i)(?<![\p{L}\p{N}])(?:DUB|дубляж|дублированный)(?![\p{L}\p{N}])"#),
                ("Многоголосый", #"(?i)(?<![\p{L}\p{N}])(?:MVO|многоголосый)(?![\p{L}\p{N}])"#),
                ("Двухголосый", #"(?i)(?<![\p{L}\p{N}])(?:DVO|двухголосый)(?![\p{L}\p{N}])"#),
                ("Авторский", #"(?i)(?<![\p{L}\p{N}])(?:AVO|авторский)(?![\p{L}\p{N}])"#),
            ]
            let found = translations.filter { Self.contains($0.1, in: title) }.map(\.0)
            voice = found.isEmpty ? nil : found.joined(separator: " / ")
        }
        prefersAppleTVHD = found == ["H.264"] && !is4K && !resolutions.isEmpty &&
            resolutions.allSatisfy { ["1080p", "720p", "576p", "480p", "360p"].contains($0) }
    }

    private static func contains(_ pattern: String, in text: String) -> Bool {
        text.range(of: pattern, options: .regularExpression) != nil
    }

    /// Rank hints only. Native metadata, per-file size/path validation and actual
    /// player readiness remain mandatory after a person chooses a release.
    public static func ranked(_ results: [TorrentSearchResult]) -> [TorrentSearchResult] {
        var unique: [String: TorrentSearchResult] = [:]
        for result in results {
            let key = result.infoHash.lowercased()
            if let old = unique[key], old.seeders >= result.seeders { continue }
            unique[key] = result
        }
        return unique.values.sorted { lhs, rhs in
            let left = score(lhs), right = score(rhs)
            return left == right ? lhs.infoHash < rhs.infoHash : left > right
        }
    }

    public static func recommendedResultID(in results: [TorrentSearchResult]) -> String? {
        ranked(results).first { result in
            guard result.seeders > 0, let bytes = result.sizeBytes,
                  bytes > 0, bytes <= TorrentDownloadPolicy.defaultBudgetBytes else { return false }
            return TorrentReleasePresentation(title: result.title).prefersAppleTVHD
        }?.id
    }

    private static func score(_ result: TorrentSearchResult) -> Double {
        let hints = TorrentReleasePresentation(title: result.title)
        var score = hints.prefersAppleTVHD ? 70.0 : 0
        score += min(30, log2(Double(max(0, result.seeders)) + 1) * 4)
        if result.seeders <= 0 { score -= 60 }
        if let bytes = result.sizeBytes, bytes > 0 {
            if bytes > TorrentDownloadPolicy.defaultBudgetBytes { score -= 160 }
            else { score += bytes <= 2 * 1_024 * 1_024 * 1_024 ? 30 : 15 }
        }
        if hints.quality?.contains("2160") == true || hints.quality == "4K" { score -= 60 }
        if hints.codec == "AV1" || hints.codec == "VP9" { score -= 40 }
        return score
    }
}
