import Foundation
import KinoCore
import SwiftSoup

public enum RutorSearchParser {
    public static func parse(_ html: String, origin: URL, query: TorrentSearchQuery) throws -> [TorrentSearchResult] {
        guard html.utf8.count <= 2 * 1024 * 1024 else { throw TorrentSearchError.responseTooLarge }
        guard RutorURL.accepts(origin) else { throw TorrentSearchError.invalidResponse }
        _ = try TorrentTitleMatch.titles(query)
        let lower = html.lowercased()
        if ["cf-chl-", "challenge-platform", "g-recaptcha", "id=\"challenge-form\"", "<title>just a moment"].contains(where: lower.contains) {
            throw TorrentSearchError.challengeRequired
        }
        let document = try SwiftSoup.parse(html, origin.absoluteString)
        let rows = try document.select("#index tr.gai, #index tr.tum")
        if rows.isEmpty() {
            let text = try document.text().lowercased()
            guard text.contains("результатов поиска 0") || text.contains("ничего не найдено")
                    || text.contains("по вашему запросу ничего") else { throw TorrentSearchError.invalidResponse }
            return []
        }
        var results: [TorrentSearchResult] = []
        for row in rows.array().prefix(200) {
            let cells = try row.select("td").array()
            guard (4...6).contains(cells.count),
                  let magnetLink = try cells[1].select("a[href^=magnet:]").first(),
                  let torrent = try? TorrentMagnet(magnetLink.attr("href")),
                  let topic = try cells[1].select("a[href^=/torrent/]").first(),
                  let source = URL(string: try topic.attr("href"), relativeTo: origin)?.absoluteURL,
                  RutorURL.accepts(source), source.path.hasPrefix("/torrent/"),
                  source.query == nil else { continue }
            let title = try topic.text().trimmingCharacters(in: .whitespacesAndNewlines)
            guard !title.isEmpty, title.utf8.count <= 1024,
                  let match = TorrentTitleMatch.confidence(title: title, query: query) else { continue }
            let size = try parseSize(cells[cells.count - 2].text())
            let seedText = try cells[cells.count - 1].select("span.green").text()
            let digits = seedText.filter { $0.isASCII && $0.isNumber }
            let seeds = digits.count <= 9 ? (Int(digits) ?? 0) : 0
            results.append(TorrentSearchResult(title: title, magnet: torrent.uri, infoHash: torrent.infoHash,
                sizeBytes: size, seeders: seeds, sourceURL: source, matchConfidence: match.score, year: match.year))
        }
        return results
    }

    static func parseSize(_ text: String) -> Int64? {
        let clean = text.replacingOccurrences(of: "\u{00a0}", with: " ").trimmingCharacters(in: .whitespacesAndNewlines)
        let parts = clean.split(whereSeparator: { $0.isWhitespace })
        guard parts.count == 2, let amount = Double(parts[0].replacingOccurrences(of: ",", with: ".")),
              amount.isFinite, amount > 0 else { return nil }
        let unit = parts[1].uppercased()
        let factors: [String: Double] = ["B": 1, "KB": 1024, "MB": 1_048_576, "GB": 1_073_741_824,
            "TB": 1_099_511_627_776, "KIB": 1024, "MIB": 1_048_576, "GIB": 1_073_741_824,
            "КБ": 1024, "МБ": 1_048_576, "ГБ": 1_073_741_824, "ТБ": 1_099_511_627_776]
        guard let multiplier = factors[unit] else { return nil }
        let bytes = amount * multiplier
        guard bytes.isFinite, bytes >= 1, bytes < Double(Int64.max) else { return nil }
        return Int64(bytes.rounded())
    }
}
