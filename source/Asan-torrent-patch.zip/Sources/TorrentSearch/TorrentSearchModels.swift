import Foundation
import KinoCore

public struct TorrentSearchQuery: Hashable, Sendable {
    public let title: String
    public let originalTitle: String?
    public let year: Int?
    public let isSeries: Bool
    public init(title: String, originalTitle: String? = nil, year: Int? = nil, isSeries: Bool = false) {
        self.title = title
        self.originalTitle = originalTitle
        self.year = year
        self.isSeries = isSeries
    }
    public init(media: MediaItem) {
        self.init(title: media.title, originalTitle: media.originalTitle, year: media.year, isSeries: media.kind == .series)
    }
}

public struct TorrentSearchResult: Identifiable, Hashable, Sendable {
    public var id: String { infoHash }
    public let title: String
    public let magnet: String
    public let infoHash: String
    public let sizeBytes: Int64?
    public let seeders: Int
    public let sourceName: String
    public let sourceURL: URL
    public let matchConfidence: Double
    public let year: Int?
    public init(title: String, magnet: String, infoHash: String, sizeBytes: Int64?, seeders: Int,
                sourceName: String = "RuTor", sourceURL: URL, matchConfidence: Double, year: Int?) {
        self.title = title
        self.magnet = magnet
        self.infoHash = infoHash
        self.sizeBytes = sizeBytes
        self.seeders = seeders
        self.sourceName = sourceName
        self.sourceURL = sourceURL
        self.matchConfidence = matchConfidence
        self.year = year
    }
}

public enum TorrentSearchError: Error, LocalizedError, Equatable, Sendable {
    case invalidQuery, providerUnavailable, challengeRequired, invalidResponse
    case responseTooLarge, unsupportedEncoding, timedOut, httpStatus(Int)
    public var errorDescription: String? {
        switch self {
        case .invalidQuery: return "Не удалось составить название для поиска торрентов."
        case .providerUnavailable: return "RuTor сейчас недоступен. Попробуй позже или добавь magnet-ссылку вручную."
        case .challengeRequired: return "RuTor требует проверку в браузере. Автоматический поиск сейчас недоступен."
        case .invalidResponse: return "RuTor вернул страницу неизвестного формата."
        case .responseTooLarge: return "Ответ поиска слишком большой. Уточни название."
        case .unsupportedEncoding: return "Не удалось прочитать ответ поиска."
        case .timedOut: return "Поиск занял слишком много времени. Попробуй ещё раз."
        case .httpStatus(let code): return "RuTor вернул ошибку HTTP \(code)."
        }
    }
}

public protocol TorrentSearching: Sendable {
    func search(_ query: TorrentSearchQuery) async throws -> [TorrentSearchResult]
}

enum RutorURL {
    static let origins = [URL(string: "https://rutor.info")!, URL(string: "https://rutor.is")!]
    static func accepts(_ url: URL) -> Bool {
        guard CatalogClient.isSecureURL(url), let parts = URLComponents(url: url, resolvingAgainstBaseURL: false),
              parts.user == nil, parts.password == nil, parts.fragment == nil,
              parts.port == nil || parts.port == 443 else { return false }
        return ["rutor.info", "rutor.is"].contains(parts.host?.lowercased() ?? "")
    }
    static func searchURL(origin: URL, term: String) throws -> URL {
        let allowed = CharacterSet(charactersIn: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~")
        guard accepts(origin), let encoded = term.addingPercentEncoding(withAllowedCharacters: allowed),
              // RuTor's own form: method=1 (all words), scope=0 (title),
              // trailing method flag=0; sort=2 + direction=0 (seeds, descending).
              let url = URL(string: origin.absoluteString + "/search/0/0/100/2/" + encoded), accepts(url) else {
            throw TorrentSearchError.invalidQuery
        }
        return url
    }
}

enum TorrentTitleMatch {
    static func normalized(_ value: String) -> String {
        let folded = value.folding(options: [.caseInsensitive, .diacriticInsensitive], locale: Locale(identifier: "ru_RU"))
            .replacingOccurrences(of: "ё", with: "е")
        return folded.unicodeScalars.map { CharacterSet.alphanumerics.contains($0) ? String($0) : " " }
            .joined().split(whereSeparator: { $0.isWhitespace }).joined(separator: " ")
    }
    static func titles(_ query: TorrentSearchQuery) throws -> [String] {
        guard query.year.map({ (1888...2100).contains($0) }) ?? true else { throw TorrentSearchError.invalidQuery }
        var result: [String] = []
        for raw in [query.title, query.originalTitle ?? ""] {
            let title = raw.trimmingCharacters(in: .whitespacesAndNewlines)
            guard title.utf8.count <= 512,
                  !title.unicodeScalars.contains(where: { CharacterSet.controlCharacters.contains($0) }) else {
                throw TorrentSearchError.invalidQuery
            }
            if !normalized(title).isEmpty, !result.contains(where: { normalized($0) == normalized(title) }) {
                result.append(title)
            }
        }
        guard !result.isEmpty else { throw TorrentSearchError.invalidQuery }
        return Array(result.prefix(2))
    }
    static func confidence(title: String, query: TorrentSearchQuery) -> (score: Double, year: Int?)? {
        let expression = try! NSRegularExpression(pattern: #"\((18[89]\d|19\d{2}|20\d{2})(?:\s*[-–]\s*\d{4})?\)"#)
        let range = NSRange(title.startIndex..., in: title)
        let match = expression.firstMatch(in: title, range: range)
        var year: Int?
        var prefix = title
        if let match, let yearRange = Range(match.range(at: 1), in: title), let fullRange = Range(match.range, in: title) {
            year = Int(title[yearRange])
            prefix = String(title[..<fullRange.lowerBound])
        }
        if let expected = query.year, let year {
            if query.isSeries ? year < expected : year != expected { return nil }
        }
        prefix = prefix.replacingOccurrences(of: #"\[[^\]]*\]"#, with: " ", options: .regularExpression)
        // Match each bilingual alias independently: a season label on the
        // Russian alias must not discard a usable original-title alias.
        let alternatives = (prefix.components(separatedBy: "/") + [prefix]).map {
            normalized(query.isSeries ? removingSeasonSuffix($0) : $0)
        }
        guard let wanted = try? titles(query), wanted.contains(where: { alternatives.contains(normalized($0)) }) else { return nil }
        let confidence: Double = query.year != nil && year == query.year ? 1
            : (query.isSeries && query.year != nil && year != nil ? 0.95 : 0.85)
        return (confidence, year)
    }

    private static func removingSeasonSuffix(_ value: String) -> String {
        // Numeric season/episode ornaments only, not arbitrary fuzzy suffixes
        // or a word such as "Season" that may belong to the actual title.
        let pattern = #"(?i)(?:^|[\s(.,:;])(?:(?:сезон(?:ы|ов)?|season(?:s)?|серии|серия|episodes?)\s*[:#]?\s*\d+|\d+(?:\s*[-–]\s*\d+)?\s*сезон(?:ы|ов)?\b|s\d{1,2}(?:e\d{1,3})?\b).*"#
        return value.replacingOccurrences(of: pattern, with: " ", options: .regularExpression)
    }
}
