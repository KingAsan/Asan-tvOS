import Foundation

/// Search only: this module cannot create an engine handle or start a download.
public actor TorrentSearchService: TorrentSearching {
    private let transport: any TorrentSearchTransport
    private let maximumBytes = 2 * 1024 * 1024
    public init(transport: any TorrentSearchTransport = URLSessionTorrentSearchTransport()) { self.transport = transport }

    public func search(_ query: TorrentSearchQuery) async throws -> [TorrentSearchResult] {
        _ = try TorrentTitleMatch.titles(query)
        try Task.checkCancellation()
        return try await withThrowingTaskGroup(of: [TorrentSearchResult].self) { group in
            group.addTask { try await self.perform(query) }
            group.addTask {
                try await Task.sleep(nanoseconds: 20_000_000_000)
                throw TorrentSearchError.timedOut
            }
            defer { group.cancelAll() }
            guard let result = try await group.next() else { throw CancellationError() }
            try Task.checkCancellation()
            return result
        }
    }

    private func perform(_ query: TorrentSearchQuery) async throws -> [TorrentSearchResult] {
        let titles = try TorrentTitleMatch.titles(query)
        var byHash: [String: TorrentSearchResult] = [:]
        var successfulResponse = false
        var lastError: Error = TorrentSearchError.providerUnavailable
        for title in titles {
            try Task.checkCancellation()
            // A later season is often indexed under its own release year.
            // Keep the premiere year for matching, not in a series search term.
            let term = title + (query.isSeries ? "" : (query.year.map { " \($0)" } ?? ""))
            for origin in RutorURL.origins {
                do {
                    let url = try RutorURL.searchURL(origin: origin, term: term)
                    var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 10)
                    request.setValue("text/html", forHTTPHeaderField: "Accept")
                    request.setValue("Asan/0.6 (tvOS; public torrent search)", forHTTPHeaderField: "User-Agent")
                    let response = try await transport.fetch(request, maximumBytes: maximumBytes)
                    try Task.checkCancellation()
                    guard let finalURL = response.finalURL, RutorURL.accepts(finalURL) else { throw TorrentSearchError.invalidResponse }
                    guard response.data.count <= maximumBytes else { throw TorrentSearchError.responseTooLarge }
                    guard response.statusCode == 200 else { throw TorrentSearchError.httpStatus(response.statusCode) }
                    if let type = response.mimeType?.lowercased(), !["text/html", "application/xhtml+xml"].contains(type) {
                        throw TorrentSearchError.invalidResponse
                    }
                    guard let html = String(data: response.data, encoding: .utf8) else { throw TorrentSearchError.unsupportedEncoding }
                    let values = try RutorSearchParser.parse(html, origin: finalURL, query: query)
                    successfulResponse = true
                    for result in values {
                        if let previous = byHash[result.infoHash], previous.seeders >= result.seeders { continue }
                        byHash[result.infoHash] = result
                    }
                    break
                } catch {
                    if Task.isCancelled || error is CancellationError || (error as? URLError)?.code == .cancelled { throw CancellationError() }
                    lastError = error
                }
            }
            // The original title is a fallback, not an extra request that can
            // discard already useful matches if another alias/mirror is slow.
            if !byHash.isEmpty { break }
        }
        try Task.checkCancellation()
        guard successfulResponse else { throw lastError }
        return Array(byHash.values.sorted {
            if $0.seeders != $1.seeders { return $0.seeders > $1.seeders }
            if $0.matchConfidence != $1.matchConfidence { return $0.matchConfidence > $1.matchConfidence }
            return $0.infoHash < $1.infoHash
        }.prefix(60))
    }
}
