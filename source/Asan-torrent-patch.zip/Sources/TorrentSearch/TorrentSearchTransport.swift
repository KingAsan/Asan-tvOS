import Foundation

public struct TorrentSearchHTTPResponse: Sendable {
    public let data: Data
    public let statusCode: Int
    public let finalURL: URL?
    public let mimeType: String?
    public init(data: Data, statusCode: Int, finalURL: URL?, mimeType: String? = "text/html") {
        self.data = data; self.statusCode = statusCode; self.finalURL = finalURL; self.mimeType = mimeType
    }
}

public protocol TorrentSearchTransport: Sendable {
    func fetch(_ request: URLRequest, maximumBytes: Int) async throws -> TorrentSearchHTTPResponse
}

private final class TorrentSearchRedirectDelegate: NSObject, URLSessionTaskDelegate, @unchecked Sendable {
    private var redirects = 0
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) {
        redirects += 1
        guard redirects <= 4, request.url.map(RutorURL.accepts) == true else { completionHandler(nil); return }
        completionHandler(request)
    }
}

/// Ordinary public HTTPS requests only. No account cookies, proxy or browser-challenge workaround.
public final class URLSessionTorrentSearchTransport: TorrentSearchTransport, @unchecked Sendable {
    private let session: URLSession
    public init() {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = 10
        configuration.timeoutIntervalForResource = 18
        configuration.httpShouldSetCookies = false
        configuration.httpCookieStorage = nil
        configuration.urlCache = nil
        configuration.httpMaximumConnectionsPerHost = 2
        session = URLSession(configuration: configuration)
    }
    deinit { session.invalidateAndCancel() }
    public func fetch(_ request: URLRequest, maximumBytes: Int) async throws -> TorrentSearchHTTPResponse {
        guard maximumBytes > 0, maximumBytes <= 2 * 1024 * 1024,
              request.url.map(RutorURL.accepts) == true else { throw TorrentSearchError.invalidResponse }
        let (bytes, response) = try await session.bytes(for: request, delegate: TorrentSearchRedirectDelegate())
        defer { bytes.task.cancel() }
        guard let response = response as? HTTPURLResponse, let finalURL = response.url,
              RutorURL.accepts(finalURL) else { throw TorrentSearchError.invalidResponse }
        guard response.expectedContentLength <= Int64(maximumBytes) else { throw TorrentSearchError.responseTooLarge }
        var data = Data()
        if response.expectedContentLength > 0 { data.reserveCapacity(Int(response.expectedContentLength)) }
        for try await byte in bytes {
            guard data.count < maximumBytes else { throw TorrentSearchError.responseTooLarge }
            data.append(byte)
            if data.count % 16_384 == 0 { try Task.checkCancellation() }
        }
        try Task.checkCancellation()
        return TorrentSearchHTTPResponse(data: data, statusCode: response.statusCode, finalURL: finalURL, mimeType: response.mimeType)
    }
}
