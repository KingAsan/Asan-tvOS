import Foundation

/// Counts distinct sustained waits after playback has really begun. A seek,
/// initial connection or user pause is not a network-recovery recommendation.
public struct PlaybackRecoveryPolicy: Sendable {
    private var waits: [Double] = []
    private var waitingSince: Double?
    private var countedCurrentWait = false
    private var suppressUntil = 0.0
    public private(set) var hasOffered = false

    public init() {}

    public mutating func suppressForSeek(at now: Double) {
        guard now.isFinite else { return }
        suppressUntil = now + 5
        waits.removeAll(keepingCapacity: true)
        waitingSince = nil
        countedCurrentWait = false
    }

    public mutating func observe(isWaiting: Bool, hasStarted: Bool, at now: Double) -> Bool {
        guard now.isFinite, now >= 0 else { return false }
        guard isWaiting, hasStarted else {
            waitingSince = nil
            countedCurrentWait = false
            return false
        }
        guard !hasOffered, now >= suppressUntil else { return false }
        guard let start = waitingSince else { waitingSince = now; return false }
        guard now >= start else { waitingSince = now; countedCurrentWait = false; return false }
        guard !countedCurrentWait, now - start >= 3 else { return false }
        countedCurrentWait = true
        waits = waits.filter { now - $0 <= 60 && now >= $0 }
        waits.append(now)
        guard waits.count >= 2 else { return false }
        hasOffered = true
        return true
    }
}

public enum IntroPlaybackPolicy {
    /// Absolute end of the configured opening, never a relative jump or rewind.
    public static func target(position: Double, duration: Double, introSeconds: Double) -> Double? {
        guard position.isFinite, duration.isFinite, introSeconds.isFinite,
              position >= 0, introSeconds > 0, introSeconds <= 600,
              duration > introSeconds + 5, position + 0.5 < introSeconds else { return nil }
        return introSeconds
    }

    public static func resume(position: Double, duration: Double) -> Double {
        guard position.isFinite, position > 0, duration.isFinite, duration > 0,
              position / duration < 0.95 else { return 0 }
        return min(position, max(0, duration - 2))
    }
}
