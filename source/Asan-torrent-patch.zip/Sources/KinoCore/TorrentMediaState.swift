import Foundation

/// Display/history metadata only; never stores expiring playback URLs.
public struct TorrentMediaAssociation: Codable, Hashable, Sendable {
    public let reference: MediaReference
    public let media: MediaItem
    public let episodeID: String?
    public var resolvedEpisode: Episode? { media.seasons.flatMap(\.episodes).first { $0.id == episodeID } }
    public var seasonNumber: Int? { media.seasons.first { $0.episodes.contains { $0.id == episodeID } }?.number }
    public var episodeNumber: Int? { resolvedEpisode?.number }
    public var canRecordProgress: Bool { media.kind == .movie ? episodeID == nil : resolvedEpisode != nil }
    public var progressID: String { WatchProgress.key(reference: reference, episodeID: episodeID) }

    public init(media: MediaItem, providerID: String, episodeID: String? = nil) throws {
        try self.init(reference: MediaReference(providerID: providerID, itemID: media.id), media: media, episodeID: episodeID)
    }
    public init(reference: MediaReference, media: MediaItem, episodeID: String? = nil) throws {
        guard Self.valid(reference), reference.itemID == media.id else { throw LibraryError.invalidReference }
        let matches = media.seasons.flatMap(\.episodes).filter { $0.id == episodeID }
        if let episodeID {
            guard media.kind == .series, !episodeID.isEmpty, episodeID.utf8.count <= 2048,
                  matches.count == 1 else { throw LibraryError.invalidReference }
        }
        self.reference = reference
        self.episodeID = episodeID
        let seasons = media.seasons.compactMap { season -> Season? in
            guard let episodeID, let episode = season.episodes.first(where: { $0.id == episodeID }) else { return nil }
            return Season(id: season.id, title: season.title, number: season.number, episodes: [
                Episode(id: episode.id, title: episode.title, number: episode.number, durationMinutes: episode.durationMinutes)
            ])
        }
        self.media = MediaItem(id: media.id, title: media.title, kind: media.kind, originalTitle: media.originalTitle,
            year: media.year, posterURL: media.posterURL, genres: media.genres, rating: media.rating,
            durationMinutes: media.durationMinutes, seasons: seasons)
    }
    private enum CodingKeys: String, CodingKey { case reference, media, episodeID }
    public init(from decoder: Decoder) throws {
        let fields = try decoder.container(keyedBy: CodingKeys.self)
        try self.init(reference: fields.decode(MediaReference.self, forKey: .reference),
            media: fields.decode(MediaItem.self, forKey: .media), episodeID: fields.decodeIfPresent(String.self, forKey: .episodeID))
    }

    static func valid(_ reference: MediaReference) -> Bool {
        [reference.providerID, reference.itemID].allSatisfy {
            !$0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && $0.utf8.count <= 2048
                && !$0.unicodeScalars.contains(where: { CharacterSet.controlCharacters.contains($0) })
        }
    }

    /// Conservative mapping to real catalog IDs. Ranges, concatenated episodes,
    /// unnumbered files and unknown catalog episodes remain local-only instead
    /// of inventing an online episode identity. Pass the full catalog snapshot.
    public static func resolvingFile(name: String, media: MediaItem, providerID: String) -> TorrentMediaAssociation? {
        guard TorrentDownloadPolicy.isSafeRelativePath(name) else { return nil }
        if media.kind == .movie { return try? Self(media: media, providerID: providerID) }
        let expression = try! NSRegularExpression(pattern: #"(?i)(?<![a-z0-9])s(\d{1,2})e(\d{1,3})(?![a-z0-9])"#)
        let matches = expression.matches(in: name, range: NSRange(name.startIndex..., in: name))
        guard matches.count == 1, let match = matches.first,
              let seasonRange = Range(match.range(at: 1), in: name), let episodeRange = Range(match.range(at: 2), in: name),
              let fullRange = Range(match.range, in: name),
              let seasonNumber = Int(name[seasonRange]), let episodeNumber = Int(name[episodeRange]) else { return nil }
        let suffix = String(name[fullRange.upperBound...])
        guard suffix.range(of: #"(?i)^\s*(?:e\d|[-–+]\s*(?:s\d{1,2})?e?\d{1,3}(?!\d|[pi]))"#,
                           options: .regularExpression) == nil else { return nil }
        let episodes = media.seasons.filter { $0.number == seasonNumber }.flatMap(\.episodes).filter { $0.number == episodeNumber }
        guard episodes.count == 1, let episode = episodes.first else { return nil }
        return try? Self(media: media, providerID: providerID, episodeID: episode.id)
    }
}

public struct SeriesIntroSkipPreference: Codable, Equatable, Sendable {
    public let reference: MediaReference
    public let duration: Double
    public init(reference: MediaReference, duration: Double) { self.reference = reference; self.duration = duration }
}

public enum TorrentQueueError: Error, Equatable, LocalizedError, Sendable {
    case tooManyRecords, invalidEntry
    public var errorDescription: String? {
        switch self {
        case .tooManyRecords: return "В загрузках может быть не более восьми файлов."
        case .invalidEntry: return "Некорректная запись очереди загрузок. Выбери файл заново."
        }
    }
}

public enum TorrentQueuePolicy {
    private static func pending(_ value: TorrentDownload) -> Bool {
        value.state == .queued && value.queueOrder != nil && value.downloadedBytes == 0 && value.completedAt == nil
    }
    public static func ordered(_ downloads: [TorrentDownload]) -> [TorrentDownload] {
        downloads.filter(pending).sorted {
            if $0.queueOrder != $1.queueOrder { return ($0.queueOrder ?? Int.max) < ($1.queueOrder ?? Int.max) }
            if $0.addedAt != $1.addedAt { return $0.addedAt < $1.addedAt }
            return $0.id.uuidString < $1.id.uuidString
        }
    }
    /// Used only for a newly selected same-series batch, not for rewriting a
    /// user's persisted order. Unmapped/mixed batches retain the caller's order.
    public static func orderedEpisodeBatch(_ downloads: [TorrentDownload]) -> [TorrentDownload] {
        guard let first = downloads.first?.mediaAssociation, first.media.kind == .series,
              downloads.allSatisfy({ $0.mediaAssociation?.reference == first.reference && $0.mediaAssociation?.resolvedEpisode != nil }) else { return downloads }
        return downloads.enumerated().sorted {
            let left = $0.element.mediaAssociation!, right = $1.element.mediaAssociation!
            if left.seasonNumber != right.seasonNumber { return (left.seasonNumber ?? Int.max) < (right.seasonNumber ?? Int.max) }
            if left.episodeNumber != right.episodeNumber { return (left.episodeNumber ?? Int.max) < (right.episodeNumber ?? Int.max) }
            return $0.offset < $1.offset
        }.map(\.element)
    }
    /// Pending queue entries have not reserved payload. All other records keep
    /// their full reservation until actual deletion, even if their TTL expired.
    public static func reservedBytes(in downloads: [TorrentDownload], excluding id: UUID? = nil) -> Int64 {
        downloads.filter { $0.id != id && !pending($0) }.reduce(Int64(0)) { total, item in
            let (sum, overflow) = total.addingReportingOverflow(max(0, item.totalBytes))
            return overflow ? Int64.max : sum
        }
    }
    public static func nextAdmission(in downloads: [TorrentDownload], availableBytes: Int64,
        budgetBytes: Int64 = TorrentDownloadPolicy.defaultBudgetBytes, maximumRecords: Int = 8) throws -> TorrentDownload? {
        guard maximumRecords > 0 else { throw TorrentQueueError.invalidEntry }
        guard downloads.count <= maximumRecords else { throw TorrentQueueError.tooManyRecords }
        guard Set(downloads.map(\.id)).count == downloads.count else { throw TorrentQueueError.invalidEntry }
        guard !downloads.contains(where: { $0.state == .downloading }) else { return nil }
        guard let next = ordered(downloads).first else { return nil }
        guard let order = next.queueOrder, order >= 0, let index = next.fileIndex, index >= 0,
              let name = next.fileName, TorrentDownloadPolicy.isSafeRelativePath(name), next.addedAt.timeIntervalSince1970.isFinite else {
            throw TorrentQueueError.invalidEntry
        }
        try TorrentDownloadPolicy.validateAdmission(fileBytes: next.totalBytes,
            usedBytes: reservedBytes(in: downloads, excluding: next.id), availableBytes: availableBytes, budgetBytes: budgetBytes)
        return next
    }
}

public extension TorrentDownloadPolicy {
    /// A manifest candidate only. tvOS can purge payload; the app must validate
    /// its owned regular file on disk before playback and never renew its TTL.
    static func cachedDownload(in downloads: [TorrentDownload], reference: MediaReference,
        episodeID: String? = nil, at now: Date = Date()) -> TorrentDownload? {
        guard now.timeIntervalSince1970.isFinite else { return nil }
        return downloads.filter {
            guard let association = $0.mediaAssociation, association.canRecordProgress,
                  association.reference == reference, association.episodeID == episodeID,
                  $0.state == .completed, let finished = $0.completedAt, finished.timeIntervalSince1970.isFinite,
                  !$0.isExpired(at: now), let index = $0.fileIndex, index >= 0,
                  let name = $0.fileName, isSafeRelativePath(name), $0.totalBytes > 0,
                  $0.downloadedBytes >= $0.totalBytes else { return false }
            return true
        }.sorted {
            if $0.completedAt != $1.completedAt { return ($0.completedAt ?? .distantPast) > ($1.completedAt ?? .distantPast) }
            return $0.id.uuidString < $1.id.uuidString
        }.first
    }
}
