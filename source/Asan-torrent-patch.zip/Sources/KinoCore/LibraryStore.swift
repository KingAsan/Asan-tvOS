import Foundation

public enum LibraryError: Error, LocalizedError, Equatable, Sendable {
    case invalidLocation
    case unreadableStore
    case corruptStore
    case unsupportedSchema(Int)
    case invalidProgress
    case invalidReference
    case writeFailed
    case storageFull
    case invalidIntroDuration

    public var errorDescription: String? {
        switch self {
        case .invalidLocation: return "Для библиотеки нужен локальный путь к файлу."
        case .unreadableStore: return "Не удалось прочитать сохранённую библиотеку."
        case .corruptStore: return "Файл библиотеки повреждён. Данные сохранены; можно создать резервную копию и начать заново."
        case .unsupportedSchema(let version): return "Версия библиотеки \(version) не поддерживается."
        case .invalidProgress: return "Некорректная позиция воспроизведения."
        case .invalidReference: return "Некорректный идентификатор фильма или эпизода."
        case .writeFailed: return "Не удалось сохранить библиотеку. Изменения не применены."
        case .storageFull: return "Библиотека заполнена. Удалите ненужные записи и повторите сохранение."
        case .invalidIntroDuration: return "Длительность заставки должна быть от 0 до 600 секунд."
        }
    }
}

/// A local, single-process store. Mutations are accepted by the storage adapter
/// before becoming visible in memory. Storage errors are propagated to the caller.
public actor LibraryStore {
    private let persistence: any LibraryPersistence
    private var loaded: LibrarySnapshot?
    private let maximumHistoryCount = 250
    private let maximumStoreBytes: Int

    public init(fileURL: URL) {
        self.persistence = FileLibraryPersistence(fileURL: fileURL)
        self.maximumStoreBytes = 20 * 1024 * 1024
    }

    public init(persistence: any LibraryPersistence, maximumStoreBytes: Int = 256 * 1024) {
        self.persistence = persistence
        self.maximumStoreBytes = max(1, maximumStoreBytes)
    }

    public func snapshot() throws -> LibrarySnapshot {
        if let loaded { return loaded }
        guard let data = try persistence.load() else {
            let empty = LibrarySnapshot()
            loaded = empty
            return empty
        }
        guard data.count <= maximumStoreBytes else { throw LibraryError.corruptStore }
        let snapshot: LibrarySnapshot
        do {
            let decoder = JSONDecoder()
            decoder.dateDecodingStrategy = .iso8601
            snapshot = try decoder.decode(LibrarySnapshot.self, from: data)
        } catch {
            throw LibraryError.corruptStore
        }
        guard snapshot.schemaVersion == 1 else { throw LibraryError.unsupportedSchema(snapshot.schemaVersion) }
        try validate(snapshot)
        loaded = snapshot
        return snapshot
    }

    public func setFavorite(_ enabled: Bool, media: MediaItem, providerID: String) throws {
        var candidate = try snapshot()
        let reference = try self.reference(for: media, providerID: providerID)
        update(&candidate.favorites, enabled: enabled, media: media, reference: reference)
        try commit(candidate)
    }

    public func setWatchlisted(_ enabled: Bool, media: MediaItem, providerID: String) throws {
        var candidate = try snapshot()
        let reference = try self.reference(for: media, providerID: providerID)
        update(&candidate.watchlist, enabled: enabled, media: media, reference: reference)
        try commit(candidate)
    }

    public func recordProgress(media: MediaItem, providerID: String, episodeID: String? = nil,
                               position: Double, duration: Double) throws {
        guard position.isFinite, duration.isFinite, position >= 0, duration >= 0 else {
            throw LibraryError.invalidProgress
        }
        let reference = try self.reference(for: media, providerID: providerID)
        if let episodeID, !media.seasons.flatMap(\.episodes).contains(where: { $0.id == episodeID }) {
            throw LibraryError.invalidReference
        }
        var candidate = try snapshot()
        let clamped = duration > 0 ? min(position, duration) : position
        let progress = WatchProgress(reference: reference, media: compact(media, episodeID: episodeID), episodeID: episodeID,
                                     position: clamped, duration: duration)
        candidate.history.removeAll { $0.id == progress.id }
        candidate.history.insert(progress, at: 0)
        if candidate.history.count > maximumHistoryCount {
            candidate.history = Array(candidate.history.prefix(maximumHistoryCount))
        }
        try commit(candidate)
    }

    public func removeHistory(reference: MediaReference, episodeID: String? = nil) throws {
        var candidate = try snapshot()
        let id = WatchProgress.key(reference: reference, episodeID: episodeID)
        candidate.history.removeAll { $0.id == id }
        try commit(candidate)
    }

    public func progress(for reference: MediaReference, episodeID: String? = nil) throws -> WatchProgress? {
        let key = WatchProgress.key(reference: reference, episodeID: episodeID)
        return try snapshot().history.first { $0.id == key }
    }

    public func introSkipDuration(for reference: MediaReference) throws -> Double {
        try snapshot().introSkips.first { $0.reference == reference }?.duration ?? 0
    }

    /// A manual per-series duration. This neither detects intros nor changes
    /// existing autoplay/quality settings. Zero removes the preference.
    public func setIntroSkipDuration(_ seconds: Double, for reference: MediaReference) throws {
        guard TorrentMediaAssociation.valid(reference) else { throw LibraryError.invalidReference }
        guard seconds.isFinite, (0...600).contains(seconds) else { throw LibraryError.invalidIntroDuration }
        var candidate = try snapshot()
        candidate.introSkips.removeAll { $0.reference == reference }
        if seconds > 0 { candidate.introSkips.append(SeriesIntroSkipPreference(reference: reference, duration: seconds)) }
        guard candidate.introSkips.count <= 128 else { throw LibraryError.storageFull }
        try commit(candidate)
    }

    /// Explicitly clears local data. A read error never triggers this automatically.
    public func reset() throws { try commit(LibrarySnapshot()) }

    /// Preserves the original bytes even when the file is malformed. The returned
    /// backup can be exported/repaired; no recovery occurs without an explicit call.
    @discardableResult
    public func recoverCorruptStore() throws -> URL? {
        let backupURL = try persistence.backupCorruptData()
        try commit(LibrarySnapshot())
        return backupURL
    }

    private func reference(for media: MediaItem, providerID: String) throws -> MediaReference {
        guard !providerID.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
              !media.id.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            throw LibraryError.invalidReference
        }
        return MediaReference(providerID: providerID, itemID: media.id)
    }

    private func update(_ entries: inout [SavedMedia], enabled: Bool,
                        media: MediaItem, reference: MediaReference) {
        let oldDate = entries.first(where: { $0.reference == reference })?.addedAt
        entries.removeAll { $0.reference == reference }
        if enabled {
            entries.insert(SavedMedia(reference: reference, media: compact(media), addedAt: oldDate ?? Date()), at: 0)
        }
    }

    private func commit(_ candidate: LibrarySnapshot) throws {
        do {
            let encoder = JSONEncoder()
            encoder.dateEncodingStrategy = .iso8601
            encoder.outputFormatting = [.sortedKeys]
            let data = try encoder.encode(candidate)
            guard data.count <= maximumStoreBytes else { throw LibraryError.storageFull }
            try persistence.save(data)
        } catch let error as LibraryError {
            throw error
        } catch {
            throw LibraryError.writeFailed
        }
        loaded = candidate
    }

    /// Playback URLs are often short-lived. Keep small display snapshots only;
    /// resolve the current MediaItem by reference from its catalog before playback.
    private func compact(_ media: MediaItem, episodeID: String? = nil) -> MediaItem {
        let seasons: [Season] = media.seasons.compactMap { season in
            guard let episodeID,
                  let episode = season.episodes.first(where: { $0.id == episodeID }) else { return nil }
            return Season(id: season.id, title: season.title, number: season.number, episodes: [
                Episode(id: episode.id, title: episode.title, number: episode.number,
                        durationMinutes: episode.durationMinutes)
            ])
        }
        return MediaItem(id: media.id, title: media.title, kind: media.kind,
                  originalTitle: media.originalTitle, year: media.year, posterURL: media.posterURL,
                  genres: media.genres, rating: media.rating, durationMinutes: media.durationMinutes,
                  seasons: seasons)
    }

    private func validate(_ snapshot: LibrarySnapshot) throws {
        let saved = snapshot.favorites + snapshot.watchlist
        guard Set(snapshot.favorites.map(\.id)).count == snapshot.favorites.count,
              Set(snapshot.watchlist.map(\.id)).count == snapshot.watchlist.count,
              Set(snapshot.history.map(\.id)).count == snapshot.history.count,
              snapshot.history.count <= maximumHistoryCount,
              snapshot.introSkips.count <= 128,
              Set(snapshot.introSkips.map { $0.reference.stableKey }).count == snapshot.introSkips.count else { throw LibraryError.corruptStore }
        for preference in snapshot.introSkips {
            guard TorrentMediaAssociation.valid(preference.reference), preference.duration.isFinite,
                  preference.duration > 0, preference.duration <= 600 else { throw LibraryError.corruptStore }
        }
        for entry in saved {
            guard entry.reference.itemID == entry.media.id,
                  !entry.reference.providerID.isEmpty,
                  !entry.reference.itemID.isEmpty else { throw LibraryError.corruptStore }
        }
        for entry in snapshot.history {
            guard entry.reference.itemID == entry.media.id,
                  !entry.reference.providerID.isEmpty,
                  !entry.reference.itemID.isEmpty,
                  entry.position.isFinite, entry.duration.isFinite,
                  entry.position >= 0, entry.duration >= 0,
                  entry.duration == 0 || entry.position <= entry.duration else {
                throw LibraryError.corruptStore
            }
        }
    }
}
