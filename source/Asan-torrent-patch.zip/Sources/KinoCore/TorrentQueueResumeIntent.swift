import Foundation

public extension TorrentQueuePolicy {
    /// An automatic foreground pause retains explicit queue membership. A user
    /// pause removes that membership. Old paused records without it stay paused.
    static func shouldResumeAfterLaunch(_ download: TorrentDownload) -> Bool {
        guard download.completedAt == nil, download.totalBytes > 0,
              let index = download.fileIndex, index >= 0,
              let name = download.fileName, TorrentDownloadPolicy.isSafeRelativePath(name) else { return false }
        return download.state == .downloading || (download.state == .paused && (download.queueOrder.map { $0 >= 0 } ?? false))
    }

    /// Includes a background-paused head before later, not-yet-started files.
    /// A failed automatic head blocks advancement until explicit retry/removal.
    /// User-paused entries have no queueOrder and are outside this ordering.
    static func automaticHead(in downloads: [TorrentDownload]) -> TorrentDownload? {
        guard !downloads.contains(where: { $0.state == .downloading }) else { return nil }
        return downloads.filter { item in
            guard let order = item.queueOrder, order >= 0, item.completedAt == nil else { return false }
            return item.state == .queued || item.state == .failed ||
                (item.state == .paused && shouldResumeAfterLaunch(item))
        }.sorted {
            if $0.queueOrder != $1.queueOrder { return ($0.queueOrder ?? Int.max) < ($1.queueOrder ?? Int.max) }
            if $0.addedAt != $1.addedAt { return $0.addedAt < $1.addedAt }
            return $0.id.uuidString < $1.id.uuidString
        }.first
    }

    /// The caller supplies actual allocated bytes for THIS owned selected file,
    /// never a manifest progress counter. Credit is capped by its full size.
    /// The unchanged admission policy still enforces retained cache reservations
    /// and the free-space reserve; later smaller files cannot bypass this head.
    static func automaticAdmission(in downloads: [TorrentDownload], availableBytes: Int64,
        headAllocatedBytes: Int64, budgetBytes: Int64 = TorrentDownloadPolicy.defaultBudgetBytes) throws -> TorrentDownload? {
        guard let head = automaticHead(in: downloads) else { return nil }
        guard head.state != .failed else { return nil }
        guard availableBytes >= 0, headAllocatedBytes >= 0 else { throw TorrentDownloadError.invalidSize }
        let credit = min(headAllocatedBytes, max(0, head.totalBytes))
        let (capacity, overflow) = availableBytes.addingReportingOverflow(credit)
        var normalized = downloads
        guard let index = normalized.firstIndex(where: { $0.id == head.id }) else { throw TorrentQueueError.invalidEntry }
        if head.state == .paused {
            normalized[index].state = .queued
            normalized[index].downloadedBytes = 0
        }
        let admitted = try nextAdmission(in: normalized, availableBytes: overflow ? Int64.max : capacity, budgetBytes: budgetBytes)
        guard admitted?.id == head.id else { throw TorrentQueueError.invalidEntry }
        return head
    }
}
