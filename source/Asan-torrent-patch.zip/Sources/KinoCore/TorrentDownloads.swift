import Foundation

public enum TorrentDownloadState: String, Codable, Sendable {
    case queued, downloading, paused, completed, failed, missing
}

/// Persistent metadata, not a promise that tvOS still retains the cached file.
/// `completedAt` is written only after the engine verifies the selected file.
public struct TorrentDownload: Codable, Identifiable, Equatable, Sendable {
    public var id: UUID
    public var infoHash: String
    public var title: String
    public var fileIndex: Int?
    public var fileName: String?
    public var totalBytes: Int64
    public var downloadedBytes: Int64
    public var state: TorrentDownloadState
    public var addedAt: Date
    public var completedAt: Date?

    public init(id: UUID = UUID(), infoHash: String, title: String, fileIndex: Int? = nil,
                fileName: String? = nil, totalBytes: Int64 = 0, downloadedBytes: Int64 = 0,
                state: TorrentDownloadState = .queued, addedAt: Date = Date(), completedAt: Date? = nil) {
        self.id = id
        self.infoHash = infoHash
        self.title = title
        self.fileIndex = fileIndex
        self.fileName = fileName
        self.totalBytes = totalBytes
        self.downloadedBytes = downloadedBytes
        self.state = state
        self.addedAt = addedAt
        self.completedAt = completedAt
    }

    public var progress: Double {
        guard totalBytes > 0, downloadedBytes > 0 else { return 0 }
        return min(Double(downloadedBytes) / Double(totalBytes), 1)
    }

    public var expiresAt: Date? {
        guard let completedAt, completedAt.timeIntervalSince1970.isFinite else { return nil }
        return completedAt.addingTimeInterval(TorrentDownloadPolicy.retentionInterval)
    }

    public func isExpired(at now: Date = Date()) -> Bool {
        guard now.timeIntervalSince1970.isFinite, let expiresAt else { return false }
        return now >= expiresAt
    }

    /// Call for an engine-verified completion event, never for a rounded UI percentage.
    /// A restart, repeated callback or pause must not renew a finished film's lifetime.
    public mutating func markVerifiedComplete(at now: Date = Date()) {
        guard now.timeIntervalSince1970.isFinite else { return }
        if completedAt == nil { completedAt = now }
        state = .completed
    }
}

public enum TorrentDownloadError: Error, Equatable, LocalizedError, Sendable {
    case invalidMagnet
    case unsupportedHash
    case conflictingHashes
    case unknownFileSize
    case invalidSize
    case invalidBudget
    case budgetExceeded
    case insufficientSpace

    public var errorDescription: String? {
        switch self {
        case .invalidMagnet: return "Некорректная magnet-ссылка."
        case .unsupportedHash: return "Нужна magnet-ссылка с хешем BitTorrent v1 (btih)."
        case .conflictingHashes: return "В magnet-ссылке указаны разные хеши одного торрента."
        case .unknownFileSize: return "Сначала нужно получить размер выбранного файла."
        case .invalidSize: return "Некорректный размер файла или хранилища."
        case .invalidBudget: return "Некорректный лимит хранилища загрузок."
        case .budgetExceeded: return "Файл не помещается в лимит загрузок. Удали другую загрузку."
        case .insufficientSpace: return "На Apple TV недостаточно свободного места для этого файла."
        }
    }
}

/// A BEP 9 magnet with a canonical 40-character lower-case v1 hash.
/// Only xt, dn and validated tr values are forwarded to the engine. Web seeds,
/// source-file URLs and direct peer parameters are deliberately not imported.
public struct TorrentMagnet: Equatable, Sendable {
    public let infoHash: String
    public let displayName: String?
    public let uri: String

    public init(_ text: String) throws {
        let input = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !input.isEmpty, input.utf8.count <= 16_384,
              !input.unicodeScalars.contains(where: { CharacterSet.controlCharacters.contains($0) }),
              Self.hasValidPercentEscapes(input),
              let components = URLComponents(string: input), components.scheme?.lowercased() == "magnet",
              components.host == nil, components.user == nil, components.password == nil,
              components.port == nil, components.path.isEmpty, components.fragment == nil,
              let items = components.queryItems, items.count <= 128 else {
            throw TorrentDownloadError.invalidMagnet
        }
        var hash: String?
        var name: String?
        var trackers: [String] = []
        for item in items {
            guard let value = item.value else { continue }
            switch item.name.lowercased() {
            case "xt":
                guard value.lowercased().hasPrefix("urn:btih:") else { continue }
                let candidate = try Self.normalizeHash(String(value.dropFirst(9)))
                if let hash, hash != candidate { throw TorrentDownloadError.conflictingHashes }
                hash = candidate
            case "dn":
                if name == nil {
                    let candidate = value.trimmingCharacters(in: .whitespacesAndNewlines)
                    if !candidate.isEmpty, candidate.utf8.count <= 512,
                       !candidate.unicodeScalars.contains(where: { CharacterSet.controlCharacters.contains($0) }) {
                        name = candidate
                    }
                }
            case "tr":
                if trackers.count < 32, Self.isValidTracker(value), !trackers.contains(value) {
                    trackers.append(value)
                }
            default: break
            }
        }
        guard let hash else { throw TorrentDownloadError.unsupportedHash }
        var canonical = URLComponents()
        canonical.scheme = "magnet"
        canonical.queryItems = [URLQueryItem(name: "xt", value: "urn:btih:" + hash)]
            + (name.map { [URLQueryItem(name: "dn", value: $0)] } ?? [])
            + trackers.map { URLQueryItem(name: "tr", value: $0) }
        guard let uri = canonical.string else { throw TorrentDownloadError.invalidMagnet }
        self.infoHash = hash
        self.displayName = name
        self.uri = uri
    }

    private static func normalizeHash(_ value: String) throws -> String {
        guard value.utf8.allSatisfy({ $0 < 128 }) else { throw TorrentDownloadError.invalidMagnet }
        let ascii = Array(value.uppercased().utf8)
        if ascii.count == 40, ascii.allSatisfy({ (48...57).contains($0) || (65...70).contains($0) }) {
            return value.lowercased()
        }
        guard ascii.count == 32 else { throw TorrentDownloadError.invalidMagnet }
        let alphabet = Array("ABCDEFGHIJKLMNOPQRSTUVWXYZ234567".utf8)
        var buffer: UInt32 = 0
        var bits = 0
        var bytes: [UInt8] = []
        for character in ascii {
            guard let index = alphabet.firstIndex(of: character) else { throw TorrentDownloadError.invalidMagnet }
            buffer = (buffer << 5) | UInt32(index)
            bits += 5
            if bits >= 8 {
                bits -= 8
                bytes.append(UInt8((buffer >> bits) & 255))
                buffer &= bits == 0 ? 0 : (1 << bits) - 1
            }
        }
        guard bytes.count == 20, bits == 0 else { throw TorrentDownloadError.invalidMagnet }
        return bytes.map { String(format: "%02x", $0) }.joined()
    }

    private static func hasValidPercentEscapes(_ value: String) -> Bool {
        let bytes = Array(value.utf8)
        var index = 0
        func isHex(_ byte: UInt8) -> Bool {
            (48...57).contains(byte) || (65...70).contains(byte) || (97...102).contains(byte)
        }
        while index < bytes.count {
            if bytes[index] == 37 {
                guard index + 2 < bytes.count, isHex(bytes[index + 1]), isHex(bytes[index + 2]) else { return false }
                index += 3
            } else { index += 1 }
        }
        return true
    }

    private static func isValidTracker(_ value: String) -> Bool {
        guard value.utf8.count <= 2_048,
              !value.unicodeScalars.contains(where: { CharacterSet.controlCharacters.contains($0) }),
              let components = URLComponents(string: value),
              ["https", "http", "udp"].contains(components.scheme?.lowercased() ?? ""),
              let host = components.host, !host.isEmpty,
              components.user == nil, components.password == nil, components.fragment == nil,
              components.port.map({ (1...65_535).contains($0) }) ?? true else { return false }
        return components.url != nil
    }
}

public enum TorrentDownloadPolicy {
    public static let retentionInterval: TimeInterval = 10 * 60 * 60
    public static let defaultBudgetBytes: Int64 = 4 * 1_024 * 1_024 * 1_024
    public static let maximumBudgetBytes: Int64 = 8 * 1_024 * 1_024 * 1_024
    public static let reserveBytes: Int64 = 1_024 * 1_024 * 1_024

    /// Uses subtraction to avoid overflow for corrupt or implausibly large metadata.
    /// `usedBytes` reserves the complete selected sizes of all other admitted jobs.
    public static func validateAdmission(fileBytes: Int64, usedBytes: Int64, availableBytes: Int64,
                                         budgetBytes: Int64 = defaultBudgetBytes) throws {
        guard fileBytes != 0 else { throw TorrentDownloadError.unknownFileSize }
        guard fileBytes > 0, usedBytes >= 0, availableBytes >= 0 else { throw TorrentDownloadError.invalidSize }
        guard budgetBytes > 0, budgetBytes <= maximumBudgetBytes else { throw TorrentDownloadError.invalidBudget }
        guard usedBytes <= budgetBytes, fileBytes <= budgetBytes - usedBytes else {
            throw TorrentDownloadError.budgetExceeded
        }
        guard availableBytes >= reserveBytes, fileBytes <= availableBytes - reserveBytes else {
            throw TorrentDownloadError.insufficientSpace
        }
    }

    /// Structural check only. The storage layer must also reject symbolic links
    /// and verify that a resolved URL stays inside its own per-download directory.
    public static func isSafeRelativePath(_ value: String) -> Bool {
        guard !value.isEmpty, value.utf8.count <= 1_024 else { return false }
        func safe(_ path: String) -> Bool {
            guard !path.hasPrefix("/"), !path.hasPrefix("~"), !path.contains("\\"), !path.contains(":"),
                  !path.unicodeScalars.contains(where: { CharacterSet.controlCharacters.contains($0) }) else { return false }
            return path.split(separator: "/", omittingEmptySubsequences: false).allSatisfy {
                !$0.isEmpty && $0 != "." && $0 != ".." && $0.utf8.count <= 255
            }
        }
        guard safe(value) else { return false }
        var decoded = value
        for _ in 0..<4 {
            guard let next = decoded.removingPercentEncoding, next != decoded else { return true }
            guard safe(next) else { return false }
            decoded = next
        }
        // Do not accept ambiguous repeatedly encoded path syntax.
        return decoded.removingPercentEncoding == decoded || decoded.removingPercentEncoding == nil
    }
}
