import Foundation

public enum MediaKind: String, Codable, CaseIterable, Sendable {
    case movie
    case series
}

/// An owned HTTPS resource. Audio/subtitle selection is supplied by the HLS asset.
/// The model intentionally does not accept arbitrary AVURLAsset HTTP-header keys.
public struct StreamVariant: Codable, Identifiable, Hashable, Sendable {
    public var id: String
    public var title: String
    public var url: URL
    public var quality: String?
    public var language: String?

    public init(id: String, title: String, url: URL, quality: String? = nil, language: String? = nil) {
        self.id = id
        self.title = title
        self.url = url
        self.quality = quality
        self.language = language
    }
}

public struct Episode: Codable, Identifiable, Hashable, Sendable {
    public var id: String
    public var title: String
    public var number: Int
    public var overview: String?
    public var durationMinutes: Int?
    public var streams: [StreamVariant]

    public init(id: String, title: String, number: Int, overview: String? = nil,
                durationMinutes: Int? = nil, streams: [StreamVariant] = []) {
        self.id = id
        self.title = title
        self.number = number
        self.overview = overview
        self.durationMinutes = durationMinutes
        self.streams = streams
    }
}

public struct Season: Codable, Identifiable, Hashable, Sendable {
    public var id: String
    public var title: String
    public var number: Int
    public var episodes: [Episode]

    public init(id: String, title: String, number: Int, episodes: [Episode] = []) {
        self.id = id
        self.title = title
        self.number = number
        self.episodes = episodes
    }
}

public struct MediaItem: Codable, Identifiable, Hashable, Sendable {
    public var id: String
    public var title: String
    public var kind: MediaKind
    public var originalTitle: String?
    public var year: Int?
    public var overview: String?
    public var posterURL: URL?
    public var backdropURL: URL?
    public var genres: [String]
    public var rating: Double?
    public var durationMinutes: Int?
    public var streams: [StreamVariant]
    public var seasons: [Season]

    public var primaryGenre: String? {
        genres.lazy.map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }.first { !$0.isEmpty }
    }

    public var displayRating: Double? {
        guard let rating, rating.isFinite, (0...10).contains(rating) else { return nil }
        return rating
    }

    public init(id: String, title: String, kind: MediaKind, originalTitle: String? = nil,
                year: Int? = nil, overview: String? = nil, posterURL: URL? = nil,
                backdropURL: URL? = nil, genres: [String] = [], rating: Double? = nil,
                durationMinutes: Int? = nil, streams: [StreamVariant] = [], seasons: [Season] = []) {
        self.id = id
        self.title = title
        self.kind = kind
        self.originalTitle = originalTitle
        self.year = year
        self.overview = overview
        self.posterURL = posterURL
        self.backdropURL = backdropURL
        self.genres = genres
        self.rating = rating
        self.durationMinutes = durationMinutes
        self.streams = streams
        self.seasons = seasons
    }

    private enum CodingKeys: String, CodingKey {
        case id, title, kind, originalTitle, year, overview, posterURL, backdropURL
        case genres, rating, durationMinutes, streams, seasons
    }

    public init(from decoder: Decoder) throws {
        let fields = try decoder.container(keyedBy: CodingKeys.self)
        id = try fields.decode(String.self, forKey: .id)
        title = try fields.decode(String.self, forKey: .title)
        kind = try fields.decode(MediaKind.self, forKey: .kind)
        originalTitle = try fields.decodeIfPresent(String.self, forKey: .originalTitle)
        year = try fields.decodeIfPresent(Int.self, forKey: .year)
        overview = try fields.decodeIfPresent(String.self, forKey: .overview)
        posterURL = try fields.decodeIfPresent(URL.self, forKey: .posterURL)
        backdropURL = try fields.decodeIfPresent(URL.self, forKey: .backdropURL)
        genres = try fields.decodeIfPresent([String].self, forKey: .genres) ?? []
        rating = try fields.decodeIfPresent(Double.self, forKey: .rating)
        durationMinutes = try fields.decodeIfPresent(Int.self, forKey: .durationMinutes)
        streams = try fields.decodeIfPresent([StreamVariant].self, forKey: .streams) ?? []
        seasons = try fields.decodeIfPresent([Season].self, forKey: .seasons) ?? []
    }
}

public struct CatalogDocument: Codable, Hashable, Sendable {
    public var schemaVersion: Int
    public var providerID: String
    public var providerName: String
    public var items: [MediaItem]

    public init(schemaVersion: Int = 1, providerID: String, providerName: String, items: [MediaItem]) {
        self.schemaVersion = schemaVersion
        self.providerID = providerID
        self.providerName = providerName
        self.items = items
    }
}

/// Never concatenate provider/item identifiers with an unescaped delimiter.
public struct MediaReference: Codable, Hashable, Sendable, Identifiable {
    public var providerID: String
    public var itemID: String
    public var stableKey: String { Self.part(providerID) + Self.part(itemID) }
    public var id: String { stableKey }

    public init(providerID: String, itemID: String) {
        self.providerID = providerID
        self.itemID = itemID
    }

    static func part(_ value: String) -> String { "\(value.utf8.count):\(value)" }
}

public struct SavedMedia: Codable, Hashable, Sendable, Identifiable {
    public var reference: MediaReference
    public var media: MediaItem
    public var addedAt: Date
    public var id: String { reference.stableKey }

    public init(reference: MediaReference, media: MediaItem, addedAt: Date = Date()) {
        self.reference = reference
        self.media = media
        self.addedAt = addedAt
    }
}

public struct WatchProgress: Codable, Hashable, Sendable, Identifiable {
    public var reference: MediaReference
    public var media: MediaItem
    public var episodeID: String?
    public var position: Double
    public var duration: Double
    public var updatedAt: Date
    public var id: String { Self.key(reference: reference, episodeID: episodeID) }
    public var fraction: Double { duration > 0 ? min(max(position / duration, 0), 1) : 0 }
    public var isCompleted: Bool { duration > 0 && fraction >= 0.95 }

    public init(reference: MediaReference, media: MediaItem, episodeID: String? = nil,
                position: Double, duration: Double, updatedAt: Date = Date()) {
        self.reference = reference
        self.media = media
        self.episodeID = episodeID
        self.position = position
        self.duration = duration
        self.updatedAt = updatedAt
    }

    static func key(reference: MediaReference, episodeID: String?) -> String {
        reference.stableKey + (episodeID.map { "E" + MediaReference.part($0) } ?? "M")
    }
}

public struct LibrarySnapshot: Codable, Equatable, Sendable {
    public var schemaVersion: Int
    public var favorites: [SavedMedia]
    public var watchlist: [SavedMedia]
    public var history: [WatchProgress]
    public var introSkips: [SeriesIntroSkipPreference]

    public init(schemaVersion: Int = 1, favorites: [SavedMedia] = [],
                watchlist: [SavedMedia] = [], history: [WatchProgress] = [], introSkips: [SeriesIntroSkipPreference] = []) {
        self.schemaVersion = schemaVersion
        self.favorites = favorites
        self.watchlist = watchlist
        self.history = history
        self.introSkips = introSkips
    }
    private enum CodingKeys: String, CodingKey { case schemaVersion, favorites, watchlist, history, introSkips }
    public init(from decoder: Decoder) throws {
        let fields = try decoder.container(keyedBy: CodingKeys.self)
        schemaVersion = try fields.decode(Int.self, forKey: .schemaVersion)
        favorites = try fields.decode([SavedMedia].self, forKey: .favorites)
        watchlist = try fields.decode([SavedMedia].self, forKey: .watchlist)
        history = try fields.decode([WatchProgress].self, forKey: .history)
        introSkips = try fields.decodeIfPresent([SeriesIntroSkipPreference].self, forKey: .introSkips) ?? []
    }
}
