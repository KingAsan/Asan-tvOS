// Native runtime built from pinned source by scripts/build-torrent-engine.sh.
// SwiftPM propagates these static-library and system-framework dependencies.
@_exported import AsanTorrent
