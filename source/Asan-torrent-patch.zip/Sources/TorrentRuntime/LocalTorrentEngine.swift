import Foundation
import KinoCore
import AsanTorrent

public struct StoredTorrent: Codable, Equatable, Sendable {
    public var download: TorrentDownload
    public let magnet: String

    public init(download: TorrentDownload, magnet: String) { self.download = download; self.magnet = magnet }
}

public struct NativeTorrentSnapshot: Decodable, Sendable {
    public struct File: Decodable, Sendable {
        public let index: Int; public let name: String; public let size: Int64
        public init(index: Int, name: String, size: Int64) { self.index = index; self.name = name; self.size = size }
    }
    public var error: String?
    public var name: String?
    public var hasMetadata: Bool?
    public var files: [File]?
    public var selectedIndex: Int?
    public var downloadedBytes: Int64?
    public var totalBytes: Int64?
    public var isVerifiedComplete: Bool?
    public var isPaused: Bool?
    public var peers: Int?
    public var downloadRate: Int64?
}

private enum TorrentEngineFailure: LocalizedError {
    case message(String)
    var errorDescription: String? { if case let .message(text) = self { return text }; return nil }
}

/// All libtorrent calls and filesystem operations execute on this actor, never
/// in SwiftUI's main actor. Native input/output is a small, owned C ABI.
public actor LocalTorrentEngine {
    private var root: URL
    private var preparedRoot = false
    private var context: UnsafeMutableRawPointer?
    private var handles = Set<UUID>()
    private let fm = FileManager.default
    public init(root: URL) { self.root = root }

    private func prepareRoot() {
        guard !preparedRoot else { return }
        root = root.standardizedFileURL.resolvingSymlinksInPath()
        preparedRoot = true
    }

    private func ownedDirectory(id: UUID) throws -> URL {
        prepareRoot()
        let directory = root.appendingPathComponent(id.uuidString.lowercased(), isDirectory: true).standardizedFileURL
        guard root.resolvingSymlinksInPath() == root,
              directory.deletingLastPathComponent() == root,
              directory.resolvingSymlinksInPath() == directory else {
            throw TorrentEngineFailure.message("Небезопасный путь загрузки.")
        }
        return directory
    }

    private func session() throws -> UnsafeMutableRawPointer {
        if let context { return context }
        prepareRoot()
        try fm.createDirectory(at: root, withIntermediateDirectories: true)
        guard root.resolvingSymlinksInPath() == root else { throw TorrentEngineFailure.message("Небезопасный путь загрузок.") }
        guard let value = asan_torrent_create(root.path) else {
            throw TorrentEngineFailure.message("Не удалось запустить торрент-движок.")
        }
        context = value
        return value
    }

    private func decode(_ value: UnsafeMutablePointer<CChar>?) throws -> NativeTorrentSnapshot {
        guard let value else { throw TorrentEngineFailure.message("Торрент-движок не ответил.") }
        defer { asan_torrent_free_string(value) }
        let data = Data(String(cString: value).utf8)
        let snapshot = try JSONDecoder().decode(NativeTorrentSnapshot.self, from: data)
        if snapshot.error != nil {
            // Peer/tracker errors can contain private URLs or filesystem paths.
            throw TorrentEngineFailure.message("Раздача недоступна или её файлы не удалось прочитать. Проверь ссылку и свободное место.")
        }
        return snapshot
    }

    public func add(id: UUID, magnet: String) throws -> NativeTorrentSnapshot {
        if handles.contains(id) { return try snapshot(id: id) }
        let context = try session()
        // The C entry may already exist when snapshot serialization fails.
        // Track the attempt before decoding so cancellation/error still removes it.
        handles.insert(id)
        return try decode(asan_torrent_add(context, id.uuidString, magnet))
    }

    public func snapshot(id: UUID) throws -> NativeTorrentSnapshot {
        guard handles.contains(id), let context else { throw CancellationError() }
        return try decode(asan_torrent_snapshot(context, id.uuidString))
    }

    public func command(id: UUID, _ command: String, index: Int = -1) throws -> NativeTorrentSnapshot {
        guard handles.contains(id), let context else { throw CancellationError() }
        let result = try decode(asan_torrent_command(context, id.uuidString, command, Int32(index)))
        if command == "remove" { handles.remove(id) }
        return result
    }

    public func pauseAll() {
        guard let context else { return }
        for id in handles { _ = try? decode(asan_torrent_command(context, id.uuidString, "pause", -1)) }
    }

    public func load() throws -> [StoredTorrent] {
        prepareRoot()
        guard fm.fileExists(atPath: root.appendingPathComponent("manifest.json").path) else { return [] }
        let manifest = root.appendingPathComponent("manifest.json")
        guard root.resolvingSymlinksInPath() == root, manifest.resolvingSymlinksInPath() == manifest,
              let size = try? manifest.resourceValues(forKeys: [.fileSizeKey]).fileSize,
              size <= 512_000 else { throw TorrentEngineFailure.message("Список загрузок повреждён.") }
        let data = try Data(contentsOf: manifest)
        let records = try JSONDecoder().decode([StoredTorrent].self, from: data)
        guard records.count <= 8, Set(records.map { $0.download.id }).count == records.count else {
            throw TorrentEngineFailure.message("Список загрузок повреждён.")
        }
        return try records.map { record in
            let magnet = try TorrentMagnet(record.magnet)
            guard magnet.infoHash == record.download.infoHash,
                  record.download.totalBytes >= 0, record.download.totalBytes <= TorrentDownloadPolicy.maximumBudgetBytes,
                  record.download.downloadedBytes >= 0, record.download.downloadedBytes <= record.download.totalBytes,
                  record.download.fileIndex.map({ $0 >= 0 && $0 <= Int(Int32.max) }) ?? true,
                  record.download.title.utf8.count <= 1_024,
                  record.download.addedAt.timeIntervalSince1970.isFinite,
                  record.download.completedAt.map({ $0.timeIntervalSince1970.isFinite }) ?? true,
                  record.download.state != .completed || (record.download.completedAt != nil && record.download.totalBytes > 0),
                  record.download.fileName.map(TorrentDownloadPolicy.isSafeRelativePath) ?? true else {
                throw TorrentEngineFailure.message("Список загрузок повреждён.")
            }
            return record
        }
    }

    public func save(_ records: [StoredTorrent]) throws {
        prepareRoot()
        try fm.createDirectory(at: root, withIntermediateDirectories: true)
        guard root.resolvingSymlinksInPath() == root,
              root.appendingPathComponent("manifest.json").resolvingSymlinksInPath() == root.appendingPathComponent("manifest.json") else {
            throw TorrentEngineFailure.message("Небезопасный путь загрузок.")
        }
        let data = try JSONEncoder().encode(records)
        try data.write(to: root.appendingPathComponent("manifest.json"), options: .atomic)
    }

    public func availableBytes() -> Int64 {
        prepareRoot()
        var base = root
        while !fm.fileExists(atPath: base.path), base.deletingLastPathComponent() != base {
            base = base.deletingLastPathComponent()
        }
        if let values = try? base.resourceValues(forKeys: [.volumeAvailableCapacityForImportantUsageKey]),
           let bytes = values.volumeAvailableCapacityForImportantUsage { return max(0, bytes) }
        if let attrs = try? fm.attributesOfFileSystem(forPath: base.path), let bytes = attrs[.systemFreeSize] as? NSNumber {
            return max(0, bytes.int64Value)
        }
        return 0 // Unknown capacity must not authorize a multi-gigabyte download.
    }

    public func localFile(for record: TorrentDownload) throws -> URL? {
        guard let name = record.fileName, TorrentDownloadPolicy.isSafeRelativePath(name) else { return nil }
        let directory = try ownedDirectory(id: record.id)
        let url = directory.appendingPathComponent(name).standardizedFileURL
        guard url.path.hasPrefix(directory.path + "/") else { return nil }
        // Resolving every path component prevents a symlink escaping the owned directory.
        guard directory.resolvingSymlinksInPath().path == directory.path,
              url.resolvingSymlinksInPath().path == url.path,
              let values = try? url.resourceValues(forKeys: [.isRegularFileKey, .fileSizeKey]),
              values.isRegularFile == true, Int64(values.fileSize ?? -1) == record.totalBytes else { return nil }
        return url
    }

    public func selectedFileExists(for record: TorrentDownload) throws -> Bool {
        guard let name = record.fileName, TorrentDownloadPolicy.isSafeRelativePath(name) else { return false }
        let directory = try ownedDirectory(id: record.id)
        let file = directory.appendingPathComponent(name).standardizedFileURL
        guard file.path.hasPrefix(directory.path + "/"), file.resolvingSymlinksInPath() == file else {
            throw TorrentEngineFailure.message("Небезопасный путь загрузки.")
        }
        guard let values = try? file.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey]) else { return false }
        return values.isRegularFile == true && values.isSymbolicLink != true
    }

    /// Credit only disk space already allocated to the selected regular file,
    /// never the persisted progress counter or a sparse file's logical size.
    public func allocatedBytes(for record: TorrentDownload) throws -> Int64 {
        guard let name = record.fileName, TorrentDownloadPolicy.isSafeRelativePath(name) else { return 0 }
        let directory = try ownedDirectory(id: record.id)
        let file = directory.appendingPathComponent(name).standardizedFileURL
        guard file.path.hasPrefix(directory.path + "/"), file.resolvingSymlinksInPath() == file,
              let values = try? file.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey, .fileAllocatedSizeKey]),
              values.isRegularFile == true, values.isSymbolicLink != true,
              let allocated = values.fileAllocatedSize, allocated >= 0 else { return 0 }
        return min(record.totalBytes, Int64(allocated))
    }

    public func remove(id: UUID) throws {
        if handles.contains(id) { _ = try command(id: id, "remove") }
        let directory = try ownedDirectory(id: id)
        if fm.fileExists(atPath: directory.path) { try fm.removeItem(at: directory) }
    }
}

