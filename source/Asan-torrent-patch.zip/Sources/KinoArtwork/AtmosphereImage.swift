import Foundation
import SwiftUI
import Nuke
import NukeUI

/// A small, processed-once derivative of actual artwork. Nuke 13's blur uses
/// Accelerate on its background processing queue, never a live SwiftUI blur.
public enum AtmospherePipeline {
    public static func request(backdropURL: URL?, posterURL: URL?) -> ImageRequest? {
        guard let request = PosterPipeline.request(url: backdropURL) ?? PosterPipeline.request(url: posterURL) else {
            return nil
        }
        return thumbnail(request)
    }

    public static func thumbnail(_ request: ImageRequest) -> ImageRequest {
        var request = request
        request.thumbnail = .init(maxPixelSize: 480)
        request.processors = [ImageProcessors.GaussianBlur(radius: 12)]
        request.priority = .low
        return request
    }
}

@MainActor
public struct AtmosphereImage: View {
    private let backdropURL: URL?
    private let posterURL: URL?
    private let injectedRequest: ImageRequest?

    public init(backdropURL: URL?, posterURL: URL?) {
        self.backdropURL = backdropURL
        self.posterURL = posterURL
        injectedRequest = nil
    }

    #if DEBUG
    /// Offline QA uses bytes rendered from the existing marked preview poster.
    /// This initializer is absent from Release; production keeps HTTPS checks.
    public init(previewData: Data, cacheID: String) {
        backdropURL = nil
        posterURL = nil
        let data = previewData
        injectedRequest = data.count <= 2 * 1024 * 1024
            ? AtmospherePipeline.thumbnail(ImageRequest(id: "asan-qa-atmosphere-" + cacheID, data: { data }))
            : nil
    }
    #endif

    public var body: some View {
        let request = injectedRequest ?? AtmospherePipeline.request(backdropURL: backdropURL, posterURL: posterURL)
        LazyImage(request: request) { state in
            if let image = state.image { image.resizable().scaledToFill() }
            else if state.error != nil,
                    let fallback = AtmospherePipeline.request(backdropURL: nil, posterURL: posterURL),
                    fallback.url != request?.url {
                LazyImage(request: fallback) { fallbackState in
                    if let image = fallbackState.image { image.resizable().scaledToFill() }
                    else { Color.clear }
                }
                .pipeline(PosterPipeline.shared)
                .onDisappear(.cancel)
            }
            else { Color.clear }
        }
        .pipeline(PosterPipeline.shared)
        .onDisappear(.cancel)
        .transaction { $0.animation = nil }
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }
}
