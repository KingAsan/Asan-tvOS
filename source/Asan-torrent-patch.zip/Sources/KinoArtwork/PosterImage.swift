import Foundation
import SwiftUI
import Nuke
import NukeUI

/// Shared, bounded pipeline. Thumbnail decoding happens on Nuke's background
/// queue; a grid never decodes the full poster just to draw a small tile.
public enum PosterPipeline {
    public static let shared = ImagePipeline(configuration: configuration())

    public static func configuration() -> ImagePipeline.Configuration {
        var config = ImagePipeline.Configuration.withDataCache(
            name: "dev.local.KinoHD.posters", sizeLimit: 64 * 1024 * 1024)
        config.imageCache = ImageCache(costLimit: 32 * 1024 * 1024, countLimit: 80)
        config.maximumResponseDataSize = 8 * 1024 * 1024
        config.dataLoadingQueue.maxConcurrentOperationCount = 4
        config.imageDecodingQueue.maxConcurrentOperationCount = 1
        config.imageProcessingQueue.maxConcurrentOperationCount = 1
        config.imageDecompressingQueue.maxConcurrentOperationCount = 1
        return config
    }

    public static func request(url: URL?) -> ImageRequest? {
        guard let url, url.scheme?.lowercased() == "https", url.host != nil,
              url.user == nil, url.password == nil else { return nil }
        return thumbnail(ImageRequest(url: url))
    }

    public static func thumbnail(_ request: ImageRequest) -> ImageRequest {
        var request = request
        request.thumbnail = .init(maxPixelSize: 600)
        return request
    }
}

@MainActor
public struct PosterImage<Placeholder: View>: View {
    private let url: URL?
    private let placeholder: () -> Placeholder
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    public init(url: URL?, @ViewBuilder placeholder: @escaping () -> Placeholder) {
        self.url = url
        self.placeholder = placeholder
    }

    public var body: some View {
        LazyImage(request: PosterPipeline.request(url: url)) { state in
            if let image = state.image { image.resizable().scaledToFill() }
            else { placeholder() }
        }
        .pipeline(PosterPipeline.shared)
        .onDisappear(.cancel)
        .transaction { if !reduceMotion { $0.animation = .easeOut(duration: 0.16) } }
        .accessibilityHidden(true)
    }
}
